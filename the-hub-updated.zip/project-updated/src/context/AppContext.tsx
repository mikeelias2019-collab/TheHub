import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { Property } from '../types';

export interface PriceAlert {
  id: string;
  propertyId: string;
  propertyTitle: string;
  propertyAddress: string;
  originalPrice: number;
  targetPrice: number;
  alertType: 'drop' | 'any_change';
  email: string;
  createdAt: string;
  triggered?: boolean;
  newPrice?: number;
}

export interface ShowingRequest {
  id: string;
  propertyId: string;
  propertyTitle: string;
  propertyAddress: string;
  date: string;
  time: string;
  name: string;
  email: string;
  phone: string;
  message: string;
  status: 'pending' | 'confirmed' | 'cancelled';
  createdAt: string;
}

interface AppContextType {
  savedProperties: string[];
  toggleSaved: (propertyId: string) => void;
  isSaved: (propertyId: string) => boolean;
  priceAlerts: PriceAlert[];
  addPriceAlert: (alert: Omit<PriceAlert, 'id' | 'createdAt'>) => void;
  removePriceAlert: (alertId: string) => void;
  showings: ShowingRequest[];
  addShowing: (showing: Omit<ShowingRequest, 'id' | 'createdAt' | 'status'>) => void;
  cancelShowing: (showingId: string) => void;
  notifications: Notification[];
  dismissNotification: (id: string) => void;
}

interface Notification {
  id: string;
  type: 'saved' | 'alert' | 'showing';
  message: string;
  timestamp: string;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [savedProperties, setSavedProperties] = useState<string[]>([]);
  const [priceAlerts, setPriceAlerts] = useState<PriceAlert[]>([]);
  const [showings, setShowings] = useState<ShowingRequest[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const addNotification = (type: Notification['type'], message: string) => {
    const n: Notification = { id: Date.now().toString(), type, message, timestamp: new Date().toISOString() };
    setNotifications(prev => [n, ...prev.slice(0, 4)]);
    setTimeout(() => setNotifications(prev => prev.filter(x => x.id !== n.id)), 4000);
  };

  const toggleSaved = useCallback((propertyId: string) => {
    setSavedProperties(prev => {
      if (prev.includes(propertyId)) {
        addNotification('saved', 'Property removed from favorites');
        return prev.filter(id => id !== propertyId);
      } else {
        addNotification('saved', 'Property saved to favorites ❤️');
        return [...prev, propertyId];
      }
    });
  }, []);

  const isSaved = useCallback((propertyId: string) => savedProperties.includes(propertyId), [savedProperties]);

  const addPriceAlert = useCallback((alert: Omit<PriceAlert, 'id' | 'createdAt'>) => {
    const newAlert: PriceAlert = { ...alert, id: Date.now().toString(), createdAt: new Date().toISOString() };
    setPriceAlerts(prev => [...prev, newAlert]);
    addNotification('alert', `Price alert set for ${alert.propertyTitle}`);
  }, []);

  const removePriceAlert = useCallback((alertId: string) => {
    setPriceAlerts(prev => prev.filter(a => a.id !== alertId));
  }, []);

  const addShowing = useCallback((showing: Omit<ShowingRequest, 'id' | 'createdAt' | 'status'>) => {
    const newShowing: ShowingRequest = {
      ...showing, id: Date.now().toString(),
      createdAt: new Date().toISOString(), status: 'confirmed'
    };
    setShowings(prev => [...prev, newShowing]);
    addNotification('showing', `Showing confirmed for ${showing.date} at ${showing.time}`);
  }, []);

  const cancelShowing = useCallback((showingId: string) => {
    setShowings(prev => prev.map(s => s.id === showingId ? { ...s, status: 'cancelled' } : s));
  }, []);

  const dismissNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  return (
    <AppContext.Provider value={{
      savedProperties, toggleSaved, isSaved,
      priceAlerts, addPriceAlert, removePriceAlert,
      showings, addShowing, cancelShowing,
      notifications, dismissNotification,
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
};
