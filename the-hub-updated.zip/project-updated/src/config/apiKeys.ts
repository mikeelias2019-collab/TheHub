// API Keys Configuration for The Hub
// This file manages all API keys and configuration

export interface ApiConfig {
  maps: {
    google?: string;
    mapbox?: string;
  };
  mls: {
    crmls?: {
      apiKey: string;
      baseUrl: string;
    };
    bear?: {
      apiKey: string;
      baseUrl: string;
    };
    har?: {
      apiKey: string;
      baseUrl: string;
    };
  };
  additional: {
    zillow?: string;
    walkScore?: string;
    schools?: string;
  };
  database: {
    supabaseUrl?: string;
    supabaseKey?: string;
  };
}

// Get API configuration from environment variables
export const getApiConfig = (): ApiConfig => {
  return {
    maps: {
      google: import.meta.env.VITE_GOOGLE_MAPS_API_KEY,
      mapbox: import.meta.env.VITE_MAPBOX_ACCESS_TOKEN,
    },
    mls: {
      crmls: import.meta.env.VITE_CRMLS_API_KEY ? {
        apiKey: import.meta.env.VITE_CRMLS_API_KEY,
        baseUrl: import.meta.env.VITE_CRMLS_BASE_URL || 'https://api.crmls.org'
      } : undefined,
      bear: import.meta.env.VITE_BEAR_API_KEY ? {
        apiKey: import.meta.env.VITE_BEAR_API_KEY,
        baseUrl: import.meta.env.VITE_BEAR_BASE_URL || 'https://api.bayeast.org'
      } : undefined,
      har: import.meta.env.VITE_HAR_API_KEY ? {
        apiKey: import.meta.env.VITE_HAR_API_KEY,
        baseUrl: import.meta.env.VITE_HAR_BASE_URL || 'https://api.har.com'
      } : undefined,
    },
    additional: {
      zillow: import.meta.env.VITE_ZILLOW_API_KEY,
      walkScore: import.meta.env.VITE_WALK_SCORE_API_KEY,
      schools: import.meta.env.VITE_SCHOOL_API_KEY,
    },
    database: {
      supabaseUrl: import.meta.env.VITE_SUPABASE_URL,
      supabaseKey: import.meta.env.VITE_SUPABASE_ANON_KEY,
    }
  };
};

// Check which services are available
export const getAvailableServices = () => {
  const config = getApiConfig();
  
  return {
    maps: {
      google: !!config.maps.google,
      mapbox: !!config.maps.mapbox,
      hasAnyMap: !!(config.maps.google || config.maps.mapbox)
    },
    mls: {
      crmls: !!config.mls.crmls,
      bear: !!config.mls.bear,
      har: !!config.mls.har,
      hasAnyMLS: !!(config.mls.crmls || config.mls.bear || config.mls.har)
    },
    additional: {
      zillow: !!config.additional.zillow,
      walkScore: !!config.additional.walkScore,
      schools: !!config.additional.schools,
    },
    database: {
      supabase: !!(config.database.supabaseUrl && config.database.supabaseKey)
    }
  };
};

// Development mode check
export const isDevelopment = import.meta.env.DEV;

// Show helpful messages in development
if (isDevelopment) {
  const services = getAvailableServices();
  
  console.log('🏠 The Hub - API Services Status:');
  console.log('📍 Maps:', services.maps.hasAnyMap ? '✅ Configured' : '❌ No API keys');
  console.log('🏘️ MLS:', services.mls.hasAnyMLS ? '✅ Configured' : '❌ No API keys');
  console.log('💾 Database:', services.database.supabase ? '✅ Configured' : '❌ No API keys');
  
  if (!services.maps.hasAnyMap) {
    console.log('💡 Add VITE_GOOGLE_MAPS_API_KEY or VITE_MAPBOX_ACCESS_TOKEN to enable maps');
  }
  
  if (!services.mls.hasAnyMLS) {
    console.log('💡 Add MLS API keys (VITE_CRMLS_API_KEY, etc.) to enable live property data');
  }
}