export interface Property {
  id: string;
  title: string;
  price: number;
  priceHistory: PriceHistoryEntry[];
  estimatedValue: {
    low: number;
    high: number;
    lastUpdated: string;
  };
  address: string;
  city: string;
  state: string;
  zipCode: string;
  bedrooms: number;
  bathrooms: number;
  squareFeet: number;
  propertyType: 'house' | 'condo' | 'townhouse' | 'apartment';
  listingType: 'sale' | 'rent';
  images: string[];
  description: string;
  yearBuilt: number;
  lotSize?: number;
  features: string[];
  listingDate: string;
  daysOnMarket: number;
  status: 'active' | 'pending' | 'sold' | 'off-market';
  virtualTour?: string;
  floorPlan?: string;
  walkScore?: number;
  schoolRatings?: SchoolRating[];
  nearbyAmenities: NearbyAmenity[];
  marketTrends: MarketTrend;
  propertyTax: number;
  hoaFees?: number;
  parkingSpaces?: number;
  heating: string;
  cooling: string;
  appliances: string[];
  agent: {
    name: string;
    phone: string;
    email: string;
    brokerage: string;
    licenseNumber: string;
    photo: string;
    rating: number;
    reviewCount: number;
  };
  coordinates: {
    lat: number;
    lng: number;
  };
  savedByUsers?: number;
  viewCount: number;
  lastViewed?: string;
}

export interface PriceHistoryEntry {
  date: string;
  price: number;
  event: 'listed' | 'price_change' | 'sold' | 'off_market';
}

export interface SchoolRating {
  name: string;
  type: 'elementary' | 'middle' | 'high';
  rating: number;
  distance: number;
}

export interface NearbyAmenity {
  name: string;
  type: 'restaurant' | 'shopping' | 'park' | 'hospital' | 'transit' | 'gym' | 'school';
  distance: number;
  rating?: number;
}

export interface MarketTrend {
  medianPrice: number;
  priceChange: number;
  daysOnMarket: number;
  inventory: number;
}

export interface SavedSearch {
  id: string;
  name: string;
  filters: SearchFilters;
  alertFrequency: 'instant' | 'daily' | 'weekly';
  createdAt: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  savedProperties: string[];
  savedSearches: SavedSearch[];
  recentlyViewed: string[];
  preferences: {
    priceRange: { min: number; max: number };
    locations: string[];
    propertyTypes: string[];
  };
}

export interface SearchFilters {
  location: string;
  minPrice: number;
  maxPrice: number;
  bedrooms: number;
  bathrooms: number;
  propertyType: string;
  listingType: 'sale' | 'rent';
  keywords: string;
  openHouse: boolean;
  newListings: boolean;
  priceReduced: boolean;
  hasVirtualTour: boolean;
  hasPhotos: boolean;
  sortBy: 'newest' | 'price_low' | 'price_high' | 'beds' | 'baths' | 'sqft' | 'lot_size';
}

export interface ListingFormData {
  title: string;
  price: number;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  bedrooms: number;
  bathrooms: number;
  squareFeet: number;
  propertyType: 'house' | 'condo' | 'townhouse' | 'apartment';
  listingType: 'sale' | 'rent';
  description: string;
  yearBuilt: number;
  lotSize?: number;
  features: string[];
  images: File[];
  contactName: string;
  contactPhone: string;
  contactEmail: string;
  coOwnerName?: string;
  coOwnerPhone?: string;
  coOwnerEmail?: string;
  hasCoOwner?: boolean;
  bestTimeToCall?: string;
  photoSessionTime?: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: 'seller' | 'buyer' | 'agent' | 'coordinator' | 'lender' | 'inspector' | 'attorney';
  message: string;
  timestamp: string;
  attachments?: string[];
}

export interface ChatParticipant {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'seller' | 'buyer' | 'agent' | 'coordinator' | 'lender' | 'inspector' | 'attorney';
  avatar?: string;
  isOnline: boolean;
}

export interface TransactionChat {
  id: string;
  propertyAddress: string;
  transactionType: 'sale' | 'purchase';
  status: 'active' | 'pending' | 'closed';
  participants: ChatParticipant[];
  messages: ChatMessage[];
  createdAt: string;
  closingDate?: string;
}