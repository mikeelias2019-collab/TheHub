import { Property } from '../types';

export const mockProperties: Property[] = [
  {
    id: '1',
    title: 'Modern Family Home in Suburbia',
    price: 750000,
    priceHistory: [
      { date: '2024-01-15', price: 750000, event: 'listed' },
      { date: '2023-12-01', price: 780000, event: 'price_change' },
      { date: '2023-11-15', price: 800000, event: 'listed' }
    ],
    estimatedValue: {
      low: 720000,
      high: 780000,
      lastUpdated: '2024-01-20'
    },
    address: '123 Oak Street',
    city: 'Pleasant Valley',
    state: 'CA',
    zipCode: '94102',
    bedrooms: 4,
    bathrooms: 3,
    squareFeet: 2800,
    propertyType: 'house',
    listingType: 'sale',
    images: [
      'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg',
      'https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg',
      'https://images.pexels.com/photos/1457842/pexels-photo-1457842.jpeg'
    ],
    description: 'Beautiful modern home with spacious rooms, updated kitchen, and large backyard perfect for entertaining.',
    yearBuilt: 2018,
    lotSize: 8500,
    features: ['Hardwood Floors', 'Updated Kitchen', 'Large Backyard', 'Garage', 'Central AC'],
    listingDate: '2024-01-15',
    daysOnMarket: 5,
    status: 'active',
    virtualTour: 'https://example.com/virtual-tour-1',
    walkScore: 85,
    schoolRatings: [
      { name: 'Pleasant Valley Elementary', type: 'elementary', rating: 9, distance: 0.3 },
      { name: 'Oak Middle School', type: 'middle', rating: 8, distance: 0.7 },
      { name: 'Valley High School', type: 'high', rating: 9, distance: 1.2 }
    ],
    nearbyAmenities: [
      { name: 'Whole Foods', type: 'shopping', distance: 0.5, rating: 4.5 },
      { name: 'Central Park', type: 'park', distance: 0.2, rating: 4.8 },
      { name: 'Valley Medical Center', type: 'hospital', distance: 2.1, rating: 4.2 }
    ],
    marketTrends: {
      medianPrice: 725000,
      priceChange: 5.2,
      daysOnMarket: 18,
      inventory: 45
    },
    propertyTax: 9375,
    parkingSpaces: 2,
    heating: 'Central Gas',
    cooling: 'Central Air',
    appliances: ['Dishwasher', 'Refrigerator', 'Washer/Dryer', 'Microwave'],
    agent: {
      name: 'Sarah Johnson',
      phone: '(555) 123-4567',
      email: 'sarah@hubapp.com',
      brokerage: 'The Hub Realty',
      licenseNumber: 'CA-DRE-01234567',
      photo: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg',
      rating: 4.9,
      reviewCount: 127
    },
    coordinates: { lat: 37.7749, lng: -122.4194 },
    savedByUsers: 23,
    viewCount: 156
  },
  {
    id: '2',
    title: 'Luxury Downtown Condo',
    price: 1200000,
    address: '456 High Street',
    city: 'Metro City',
    state: 'NY',
    zipCode: '10001',
    bedrooms: 2,
    bathrooms: 2,
    squareFeet: 1500,
    propertyType: 'condo',
    listingType: 'sale',
    images: [
      'https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg',
      'https://images.pexels.com/photos/2121121/pexels-photo-2121121.jpeg'
    ],
    description: 'Stunning luxury condo with panoramic city views, premium finishes, and world-class amenities.',
    yearBuilt: 2020,
    features: ['City Views', 'Luxury Finishes', 'Concierge', 'Gym', 'Rooftop Deck'],
    listingDate: '2024-01-10',
    agent: {
      name: 'Michael Chen',
      phone: '(555) 987-6543',
      email: 'michael@hubapp.com'
    },
    coordinates: { lat: 40.7589, lng: -73.9851 }
  },
  {
    id: '3',
    title: 'Charming Townhouse',
    price: 545000,
    address: '789 Maple Avenue',
    city: 'Green Hills',
    state: 'TX',
    zipCode: '75201',
    bedrooms: 3,
    bathrooms: 2,
    squareFeet: 1850,
    propertyType: 'townhouse',
    listingType: 'sale',
    images: [
      'https://images.pexels.com/photos/1396132/pexels-photo-1396132.jpeg',
      'https://images.pexels.com/photos/1438832/pexels-photo-1438832.jpeg'
    ],
    description: 'Charming townhouse in quiet neighborhood with modern updates and private patio.',
    yearBuilt: 2015,
    features: ['Private Patio', 'Modern Updates', 'Quiet Neighborhood', 'Storage'],
    listingDate: '2024-01-08',
    agent: {
      name: 'Emily Rodriguez',
      phone: '(555) 456-7890',
      email: 'emily@hubapp.com'
    },
    coordinates: { lat: 32.7767, lng: -96.7970 }
  },
  {
    id: '4',
    title: 'Spacious Ranch Home',
    price: 425000,
    address: '321 Pine Road',
    city: 'Sunset Valley',
    state: 'FL',
    zipCode: '33101',
    bedrooms: 3,
    bathrooms: 2,
    squareFeet: 2200,
    propertyType: 'house',
    listingType: 'sale',
    images: [
      'https://images.pexels.com/photos/1396129/pexels-photo-1396129.jpeg',
      'https://images.pexels.com/photos/1438834/pexels-photo-1438834.jpeg'
    ],
    description: 'Single-story ranch home with open floor plan, large kitchen, and screened-in porch.',
    yearBuilt: 2012,
    lotSize: 7200,
    features: ['Open Floor Plan', 'Screened Porch', 'Large Kitchen', 'Single Story'],
    listingDate: '2024-01-05',
    agent: {
      name: 'David Wilson',
      phone: '(555) 234-5678',
      email: 'david@hubapp.com'
    },
    coordinates: { lat: 25.7617, lng: -80.1918 }
  }
];