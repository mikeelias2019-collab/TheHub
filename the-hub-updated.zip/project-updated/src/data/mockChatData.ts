import { TransactionChat, ChatMessage, ChatParticipant } from '../types';

export const mockParticipants: ChatParticipant[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    email: 'sarah@example.com',
    phone: '(555) 123-4567',
    role: 'seller',
    isOnline: true
  },
  {
    id: '2',
    name: 'Mike Chen',
    email: 'mike@hubapp.com',
    phone: '(555) 234-5678',
    role: 'agent',
    isOnline: true
  },
  {
    id: '3',
    name: 'Emily Rodriguez',
    email: 'emily@hubapp.com',
    phone: '(555) 345-6789',
    role: 'coordinator',
    isOnline: false
  },
  {
    id: '4',
    name: 'David Wilson',
    email: 'david@buyer.com',
    phone: '(555) 456-7890',
    role: 'buyer',
    isOnline: true
  },
  {
    id: '5',
    name: 'Lisa Thompson',
    email: 'lisa@mortgage.com',
    phone: '(555) 567-8901',
    role: 'lender',
    isOnline: false
  }
];

export const mockMessages: ChatMessage[] = [
  {
    id: '1',
    senderId: '2',
    senderName: 'Mike Chen',
    senderRole: 'agent',
    message: 'Welcome everyone to the transaction chat for 123 Oak Street! I\'ll be coordinating the sale process. Let\'s keep all communication here so everyone stays updated.',
    timestamp: '2024-01-15T09:00:00Z'
  },
  {
    id: '2',
    senderId: '1',
    senderName: 'Sarah Johnson',
    senderRole: 'seller',
    message: 'Thanks Mike! Excited to get this process started. When do we expect the inspection?',
    timestamp: '2024-01-15T09:15:00Z'
  },
  {
    id: '3',
    senderId: '4',
    senderName: 'David Wilson',
    senderRole: 'buyer',
    message: 'Hi everyone! Looking forward to working with you all. I\'ve scheduled the inspection for this Friday at 2 PM.',
    timestamp: '2024-01-15T10:30:00Z'
  },
  {
    id: '4',
    senderId: '3',
    senderName: 'Emily Rodriguez',
    senderRole: 'coordinator',
    message: 'Perfect! I\'ll coordinate with the inspector and make sure all parties have access. Sarah, please ensure the property is accessible.',
    timestamp: '2024-01-15T11:00:00Z'
  },
  {
    id: '5',
    senderId: '5',
    senderName: 'Lisa Thompson',
    senderRole: 'lender',
    message: 'Loan pre-approval is complete. David, I\'ll send you the final documents by end of day. Closing is on track for the 30th.',
    timestamp: '2024-01-15T14:20:00Z'
  }
];

export const mockTransactionChat: TransactionChat = {
  id: '1',
  propertyAddress: '123 Oak Street, Pleasant Valley, CA 94102',
  transactionType: 'sale',
  status: 'active',
  participants: mockParticipants,
  messages: mockMessages,
  createdAt: '2024-01-15T08:00:00Z',
  closingDate: '2024-01-30'
};