// Map Integration Service
// Supports Google Maps, Mapbox, and other mapping providers

export interface MapConfig {
  provider: 'google' | 'mapbox' | 'leaflet';
  apiKey: string;
  style?: string;
}

export interface MapBounds {
  north: number;
  south: number;
  east: number;
  west: number;
}

export interface MapMarker {
  id: string;
  position: { lat: number; lng: number };
  title: string;
  price: number;
  propertyType: string;
  bedrooms: number;
  bathrooms: number;
  squareFeet: number;
  image: string;
  status: 'active' | 'pending' | 'sold';
}

class MapService {
  private config: MapConfig | null = null;
  private mapInstance: any = null;

  // Initialize map service
  initialize(config: MapConfig) {
    this.config = config;
    
    // Load the appropriate map library
    switch (config.provider) {
      case 'google':
        return this.initializeGoogleMaps(config.apiKey);
      case 'mapbox':
        return this.initializeMapbox(config.apiKey, config.style);
      case 'leaflet':
        return this.initializeLeaflet();
      default:
        throw new Error(`Unsupported map provider: ${config.provider}`);
    }
  }

  // Google Maps initialization
  private async initializeGoogleMaps(apiKey: string) {
    if (typeof window === 'undefined') return;

    // Load Google Maps API
    if (!window.google) {
      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places,geometry`;
      script.async = true;
      document.head.appendChild(script);
      
      return new Promise((resolve) => {
        script.onload = () => resolve(window.google);
      });
    }
    
    return window.google;
  }

  // Mapbox initialization
  private async initializeMapbox(apiKey: string, style?: string) {
    if (typeof window === 'undefined') return;

    // Load Mapbox GL JS
    if (!window.mapboxgl) {
      const script = document.createElement('script');
      script.src = 'https://api.mapbox.com/mapbox-gl-js/v2.15.0/mapbox-gl.js';
      document.head.appendChild(script);

      const link = document.createElement('link');
      link.href = 'https://api.mapbox.com/mapbox-gl-js/v2.15.0/mapbox-gl.css';
      link.rel = 'stylesheet';
      document.head.appendChild(link);

      return new Promise((resolve) => {
        script.onload = () => {
          window.mapboxgl.accessToken = apiKey;
          resolve(window.mapboxgl);
        };
      });
    }

    window.mapboxgl.accessToken = apiKey;
    return window.mapboxgl;
  }

  // Leaflet initialization (free alternative)
  private async initializeLeaflet() {
    if (typeof window === 'undefined') return;

    if (!window.L) {
      const script = document.createElement('script');
      script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
      document.head.appendChild(script);

      const link = document.createElement('link');
      link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      link.rel = 'stylesheet';
      document.head.appendChild(link);

      return new Promise((resolve) => {
        script.onload = () => resolve(window.L);
      });
    }

    return window.L;
  }

  // Create map instance
  createMap(containerId: string, center: { lat: number; lng: number }, zoom: number = 12) {
    if (!this.config) {
      throw new Error('Map service not initialized');
    }

    switch (this.config.provider) {
      case 'google':
        return this.createGoogleMap(containerId, center, zoom);
      case 'mapbox':
        return this.createMapboxMap(containerId, center, zoom);
      case 'leaflet':
        return this.createLeafletMap(containerId, center, zoom);
    }
  }

  // Add property markers to map
  addPropertyMarkers(markers: MapMarker[]) {
    if (!this.mapInstance) return;

    markers.forEach(marker => {
      this.addMarker(marker);
    });
  }

  // Add single marker
  private addMarker(marker: MapMarker) {
    if (!this.config || !this.mapInstance) return;

    const markerColor = this.getMarkerColor(marker.price);
    
    switch (this.config.provider) {
      case 'google':
        this.addGoogleMarker(marker, markerColor);
        break;
      case 'mapbox':
        this.addMapboxMarker(marker, markerColor);
        break;
      case 'leaflet':
        this.addLeafletMarker(marker, markerColor);
        break;
    }
  }

  // Get marker color based on price
  private getMarkerColor(price: number): string {
    if (price < 500000) return '#10B981'; // Green
    if (price < 1000000) return '#3B82F6'; // Blue
    if (price < 2000000) return '#F59E0B'; // Orange
    return '#EF4444'; // Red
  }

  // Google Maps specific methods
  private createGoogleMap(containerId: string, center: { lat: number; lng: number }, zoom: number) {
    const mapElement = document.getElementById(containerId);
    if (!mapElement || !window.google) return null;

    this.mapInstance = new window.google.maps.Map(mapElement, {
      center,
      zoom,
      styles: [
        {
          featureType: 'poi',
          elementType: 'labels',
          stylers: [{ visibility: 'off' }]
        }
      ]
    });

    return this.mapInstance;
  }

  private addGoogleMarker(marker: MapMarker, color: string) {
    if (!window.google || !this.mapInstance) return;

    const mapMarker = new window.google.maps.Marker({
      position: marker.position,
      map: this.mapInstance,
      title: marker.title,
      icon: {
        path: window.google.maps.SymbolPath.CIRCLE,
        fillColor: color,
        fillOpacity: 1,
        strokeColor: '#ffffff',
        strokeWeight: 2,
        scale: 8
      }
    });

    const infoWindow = new window.google.maps.InfoWindow({
      content: this.createInfoWindowContent(marker)
    });

    mapMarker.addListener('click', () => {
      infoWindow.open(this.mapInstance, mapMarker);
    });
  }

  // Mapbox specific methods
  private createMapboxMap(containerId: string, center: { lat: number; lng: number }, zoom: number) {
    if (!window.mapboxgl) return null;

    this.mapInstance = new window.mapboxgl.Map({
      container: containerId,
      style: this.config?.style || 'mapbox://styles/mapbox/streets-v11',
      center: [center.lng, center.lat],
      zoom
    });

    return this.mapInstance;
  }

  private addMapboxMarker(marker: MapMarker, color: string) {
    if (!window.mapboxgl || !this.mapInstance) return;

    const el = document.createElement('div');
    el.className = 'marker';
    el.style.backgroundColor = color;
    el.style.width = '20px';
    el.style.height = '20px';
    el.style.borderRadius = '50%';
    el.style.border = '2px solid white';
    el.style.cursor = 'pointer';

    const popup = new window.mapboxgl.Popup({ offset: 25 })
      .setHTML(this.createInfoWindowContent(marker));

    new window.mapboxgl.Marker(el)
      .setLngLat([marker.position.lng, marker.position.lat])
      .setPopup(popup)
      .addTo(this.mapInstance);
  }

  // Leaflet specific methods
  private createLeafletMap(containerId: string, center: { lat: number; lng: number }, zoom: number) {
    if (!window.L) return null;

    this.mapInstance = window.L.map(containerId).setView([center.lat, center.lng], zoom);

    window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(this.mapInstance);

    return this.mapInstance;
  }

  private addLeafletMarker(marker: MapMarker, color: string) {
    if (!window.L || !this.mapInstance) return;

    const leafletMarker = window.L.circleMarker([marker.position.lat, marker.position.lng], {
      color: '#ffffff',
      fillColor: color,
      fillOpacity: 1,
      weight: 2,
      radius: 8
    }).addTo(this.mapInstance);

    leafletMarker.bindPopup(this.createInfoWindowContent(marker));
  }

  // Create info window content
  private createInfoWindowContent(marker: MapMarker): string {
    const formatPrice = (price: number) => {
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
      }).format(price);
    };

    return `
      <div class="property-popup" style="min-width: 200px;">
        <img src="${marker.image}" alt="${marker.title}" style="width: 100%; height: 120px; object-fit: cover; border-radius: 8px; margin-bottom: 8px;">
        <h4 style="margin: 0 0 8px 0; font-size: 14px; font-weight: 600;">${marker.title}</h4>
        <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 12px; color: #666;">
          <span>${marker.bedrooms} bed</span>
          <span>${marker.bathrooms} bath</span>
          <span>${marker.squareFeet.toLocaleString()} sqft</span>
        </div>
        <div style="font-size: 16px; font-weight: 700; color: #1f2937;">${formatPrice(marker.price)}</div>
        <div style="margin-top: 8px;">
          <span style="display: inline-block; padding: 2px 8px; background: ${marker.status === 'active' ? '#10B981' : marker.status === 'pending' ? '#F59E0B' : '#6B7280'}; color: white; border-radius: 12px; font-size: 10px; text-transform: uppercase;">${marker.status}</span>
        </div>
      </div>
    `;
  }

  // Get properties within map bounds
  getPropertiesInBounds(bounds: MapBounds): Promise<MapMarker[]> {
    // This would typically make an API call to get properties within the specified bounds
    // For now, return a promise that resolves with filtered properties
    return Promise.resolve([]);
  }

  // Geocoding service
  async geocodeAddress(address: string): Promise<{ lat: number; lng: number } | null> {
    if (!this.config) return null;

    try {
      switch (this.config.provider) {
        case 'google':
          return this.googleGeocode(address);
        case 'mapbox':
          return this.mapboxGeocode(address);
        default:
          return this.openStreetMapGeocode(address);
      }
    } catch (error) {
      console.error('Geocoding error:', error);
      return null;
    }
  }

  private async googleGeocode(address: string) {
    if (!window.google) return null;

    const geocoder = new window.google.maps.Geocoder();
    const result = await geocoder.geocode({ address });
    
    if (result.results && result.results.length > 0) {
      const location = result.results[0].geometry.location;
      return { lat: location.lat(), lng: location.lng() };
    }
    
    return null;
  }

  private async mapboxGeocode(address: string) {
    const response = await fetch(
      `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(address)}.json?access_token=${this.config?.apiKey}`
    );
    
    const data = await response.json();
    
    if (data.features && data.features.length > 0) {
      const [lng, lat] = data.features[0].center;
      return { lat, lng };
    }
    
    return null;
  }

  private async openStreetMapGeocode(address: string) {
    const response = await fetch(
      `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(address)}`
    );
    
    const data = await response.json();
    
    if (data && data.length > 0) {
      return { lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon) };
    }
    
    return null;
  }
}

export const mapService = new MapService();

// Map provider configurations
export const MAP_PROVIDERS = {
  google: {
    name: 'Google Maps',
    pricing: 'Pay per use',
    features: ['Street View', 'Places API', 'Directions'],
    setup: 'Requires Google Cloud Platform account and API key'
  },
  mapbox: {
    name: 'Mapbox',
    pricing: 'Free tier available',
    features: ['Custom styling', 'Vector tiles', 'Navigation'],
    setup: 'Requires Mapbox account and access token'
  },
  leaflet: {
    name: 'Leaflet + OpenStreetMap',
    pricing: 'Free',
    features: ['Open source', 'Lightweight', 'Plugin ecosystem'],
    setup: 'No API key required'
  }
};