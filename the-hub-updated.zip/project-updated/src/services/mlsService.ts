// MLS Integration Service
// This service handles integration with Multiple Listing Services

import { getApiConfig, getAvailableServices } from '../config/apiKeys';

export interface MLSConfig {
  apiKey: string;
  baseUrl: string;
  region: string;
}

export interface MLSProperty {
  mlsNumber: string;
  listPrice: number;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  bedrooms: number;
  bathrooms: number;
  squareFeet: number;
  lotSize?: number;
  yearBuilt: number;
  propertyType: string;
  listingDate: string;
  daysOnMarket: number;
  status: 'Active' | 'Pending' | 'Sold' | 'Withdrawn';
  photos: string[];
  description: string;
  features: string[];
  listingAgent: {
    name: string;
    phone: string;
    email: string;
    brokerage: string;
    mlsId: string;
  };
  coordinates: {
    latitude: number;
    longitude: number;
  };
  virtualTour?: string;
  openHouse?: {
    date: string;
    startTime: string;
    endTime: string;
  }[];
}

class MLSService {
  private configs: Map<string, MLSConfig> = new Map();

  constructor() {
    this.initializeFromEnv();
  }

  // Initialize MLS configurations from environment variables
  private initializeFromEnv() {
    const config = getApiConfig();
    
    if (config.mls.crmls) {
      this.addMLSConfig('california', {
        apiKey: config.mls.crmls.apiKey,
        baseUrl: config.mls.crmls.baseUrl,
        region: 'southern-california'
      });
    }
    
    if (config.mls.bear) {
      this.addMLSConfig('bay-area', {
        apiKey: config.mls.bear.apiKey,
        baseUrl: config.mls.bear.baseUrl,
        region: 'san-francisco-bay-area'
      });
    }
    
    if (config.mls.har) {
      this.addMLSConfig('houston', {
        apiKey: config.mls.har.apiKey,
        baseUrl: config.mls.har.baseUrl,
        region: 'houston-texas'
      });
    }
  }

  // Add MLS configuration for different regions
  addMLSConfig(region: string, config: MLSConfig) {
    this.configs.set(region, config);
  }

  // Fetch properties from MLS
  async fetchProperties(region: string, filters?: {
    minPrice?: number;
    maxPrice?: number;
    bedrooms?: number;
    bathrooms?: number;
    propertyType?: string;
    city?: string;
    zipCode?: string;
    status?: string;
    limit?: number;
    offset?: number;
  }): Promise<MLSProperty[]> {
    const config = this.configs.get(region);
    if (!config) {
      throw new Error(`MLS configuration not found for region: ${region}`);
    }

    try {
      console.log(`Fetching properties from ${region} MLS...`);
      
      // This would be the actual MLS API call
      const response = await fetch(`${config.baseUrl}/properties`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          filters,
          region: config.region
        })
      });

      if (!response.ok) {
        throw new Error(`MLS API error: ${response.statusText}`);
      }

      const data = await response.json();
      return data.properties || [];
    } catch (error) {
      console.error('Error fetching MLS properties:', error);
      console.log('Falling back to mock data for development');
      // Return mock data for development
      return this.getMockMLSData();
    }
  }

  // Search properties by MLS number
  async getPropertyByMLS(mlsNumber: string, region: string): Promise<MLSProperty | null> {
    const config = this.configs.get(region);
    if (!config) {
      throw new Error(`MLS configuration not found for region: ${region}`);
    }

    try {
      console.log(`Fetching property ${mlsNumber} from ${region} MLS...`);
      
      const response = await fetch(`${config.baseUrl}/property/${mlsNumber}`, {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
        }
      });

      if (!response.ok) {
        return null;
      }

      return await response.json();
    } catch (error) {
      console.error('Error fetching MLS property:', error);
      return null;
    }
  }

  // Get market statistics
  async getMarketStats(region: string, area?: string): Promise<{
    medianPrice: number;
    averageDaysOnMarket: number;
    totalListings: number;
    soldLastMonth: number;
    priceChange: number;
  }> {
    const config = this.configs.get(region);
    if (!config) {
      throw new Error(`MLS configuration not found for region: ${region}`);
    }

    try {
      console.log(`Fetching market stats for ${region}${area ? ` - ${area}` : ''}...`);
      
      const response = await fetch(`${config.baseUrl}/market-stats`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ region: config.region, area })
      });

      if (!response.ok) {
        throw new Error(`MLS API error: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error fetching market stats:', error);
      console.log('Returning mock market data');
      // Return mock data
      return {
        medianPrice: 750000,
        averageDaysOnMarket: 25,
        totalListings: 1250,
        soldLastMonth: 180,
        priceChange: 3.2
      };
    }
  }

  // Get available MLS regions
  getAvailableRegions(): string[] {
    return Array.from(this.configs.keys());
  }

  // Check if MLS service is configured
  isConfigured(): boolean {
    return this.configs.size > 0;
  }

  // Mock data for development/demo
  private getMockMLSData(): MLSProperty[] {
    return [
      {
        mlsNumber: 'MLS123456',
        listPrice: 850000,
        address: '456 Elm Street',
        city: 'San Francisco',
        state: 'CA',
        zipCode: '94102',
        bedrooms: 3,
        bathrooms: 2,
        squareFeet: 1800,
        lotSize: 6000,
        yearBuilt: 2015,
        propertyType: 'Single Family',
        listingDate: '2024-01-10',
        daysOnMarket: 12,
        status: 'Active',
        photos: [
          'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg',
          'https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg'
        ],
        description: 'Beautiful updated home with modern amenities',
        features: ['Updated Kitchen', 'Hardwood Floors', 'Garden'],
        listingAgent: {
          name: 'John Smith',
          phone: '(555) 123-4567',
          email: 'john@realty.com',
          brokerage: 'Bay Area Realty',
          mlsId: 'AGT001'
        },
        coordinates: {
          latitude: 37.7849,
          longitude: -122.4094
        }
      }
    ];
  }
}

export const mlsService = new MLSService();

// Common MLS providers and their typical integration requirements
export const MLS_PROVIDERS = {
  'California Regional MLS': {
    name: 'CRMLS',
    website: 'https://crmls.org',
    apiDocs: 'https://crmls.org/developer',
    regions: ['Southern California'],
    requirements: ['MLS Membership', 'RETS/Web API Access']
  },
  'Bay East Association of Realtors': {
    name: 'BEAR',
    website: 'https://bayeast.org',
    regions: ['Bay Area'],
    requirements: ['MLS Membership', 'Data License']
  },
  'Houston Association of Realtors': {
    name: 'HAR',
    website: 'https://har.com',
    regions: ['Houston, TX'],
    requirements: ['MLS Membership', 'API Access']
  },
  'Miami Association of Realtors': {
    name: 'MIAMI',
    website: 'https://miamire.com',
    regions: ['Miami-Dade'],
    requirements: ['MLS Membership', 'RETS Access']
  }
};