import React, { useState } from 'react';
import { 
  Home, 
  User, 
  Phone, 
  Mail, 
  MapPin, 
  DollarSign, 
  Calendar,
  CheckCircle,
  Users,
  MessageCircle,
  Clock,
  Star,
  ArrowRight,
  Heart,
  Search,
  Shield
} from 'lucide-react';

interface BuyerForm {
  fullName: string;
  email: string;
  phone: string;
  preferredLocation: string;
  priceRange: string;
  bedrooms: string;
  bathrooms: string;
  propertyType: string;
  timeline: string;
  preApproved: string;
  additionalInfo: string;
}

export const BuyWithUs: React.FC = () => {
  const [formData, setFormData] = useState<BuyerForm>({
    fullName: '',
    email: '',
    phone: '',
    preferredLocation: '',
    priceRange: '',
    bedrooms: '',
    bathrooms: '',
    propertyType: '',
    timeline: '',
    preApproved: '',
    additionalInfo: ''
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (field: keyof BuyerForm, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real app, this would submit to backend
    setIsSubmitted(true);
    
    // Show success message
    alert(`🎉 Welcome to The Hub Buyer Program!

✅ Your buyer profile has been created
✅ Transaction coordinator assigned to your home search
✅ Welcome email sent with coordinator contact details

📞 Your Transaction Coordinator Will Contact You Within 2 Hours To:
• Understand your specific home buying needs
• Set up your personalized property search
• Schedule property viewings that match your criteria
• Guide you through the entire buying process
• Connect you with trusted lenders (if needed)
• Coordinate with sellers, agents, and all parties
• Keep you updated from search to closing

🏠 What's Next:
• Check your email for coordinator contact details
• Prepare your wish list and must-haves
• Get ready to find your dream home with expert guidance!

💬 Your dedicated transaction chat will be set up within 24 hours where you can communicate with your coordinator and all parties involved in your home purchase.`);
  };

  const isFormValid = () => {
    return formData.fullName && formData.email && formData.phone && 
           formData.preferredLocation && formData.priceRange && formData.timeline;
  };

  const benefits = [
    {
      icon: <Users className="h-8 w-8 text-slate-500" />,
      title: 'Dedicated Coordinator',
      description: 'Get a personal transaction coordinator who manages your entire home buying journey from start to finish.'
    },
    {
      icon: <Search className="h-8 w-8 text-green-500" />,
      title: 'Personalized Search',
      description: 'We find properties that match your exact criteria and schedule viewings that fit your schedule.'
    },
    {
      icon: <MessageCircle className="h-8 w-8 text-slate-500" />,
      title: 'Transaction Chat',
      description: 'Stay connected with all parties through our dedicated chat system - no more email chains or missed calls.'
    },
    {
      icon: <Shield className="h-8 w-8 text-orange-500" />,
      title: 'Expert Guidance',
      description: 'Navigate inspections, negotiations, financing, and closing with professional support every step of the way.'
    }
  ];

  const process = [
    {
      step: 1,
      title: 'Submit Your Preferences',
      description: 'Tell us what you\'re looking for in your dream home',
      icon: <Home className="h-6 w-6" />
    },
    {
      step: 2,
      title: 'Get Assigned a Coordinator',
      description: 'Within 2 hours, your dedicated coordinator contacts you',
      icon: <Users className="h-6 w-6" />
    },
    {
      step: 3,
      title: 'Personalized Property Search',
      description: 'We find and show you homes that match your criteria',
      icon: <Search className="h-6 w-6" />
    },
    {
      step: 4,
      title: 'Transaction Chat Setup',
      description: 'Communicate with all parties in one organized place',
      icon: <MessageCircle className="h-6 w-6" />
    },
    {
      step: 5,
      title: 'Guided to Closing',
      description: 'Professional support through offers, inspections, and closing',
      icon: <CheckCircle className="h-6 w-6" />
    }
  ];

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center">
        <div className="max-w-2xl mx-auto px-4 text-center">
          <div className="bg-white rounded-2xl shadow-2xl p-8">
            <div className="mb-6">
              <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome to The Hub!</h1>
              <p className="text-xl text-gray-600">Your home buying journey starts now</p>
            </div>
            
            <div className="bg-green-50 border border-green-200 rounded-lg p-6 mb-6">
              <h3 className="font-semibold text-green-900 mb-2">🎯 Your Transaction Coordinator</h3>
              <p className="text-green-800 text-sm">
                Within the next 2 hours, your dedicated coordinator will contact you to discuss your home buying needs and set up your personalized search.
              </p>
            </div>

            <div className="space-y-4 text-left">
              <div className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                <span className="text-gray-700">Buyer profile created</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                <span className="text-gray-700">Transaction coordinator assigned</span>
              </div>
              <div className="flex items-center">
                <Clock className="h-5 w-5 text-blue-500 mr-3" />
                <span className="text-gray-700">Coordinator will contact you within 2 hours</span>
              </div>
              <div className="flex items-center">
                <MessageCircle className="h-5 w-5 text-purple-500 mr-3" />
                <span className="text-gray-700">Transaction chat setup within 24 hours</span>
              </div>
            </div>

            <button
              onClick={() => setIsSubmitted(false)}
              className="mt-8 px-8 py-3 bg-slate-600 text-white rounded-lg hover:bg-slate-700 transition-colors"
            >
              Submit Another Request
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Buy Your Dream Home with The Hub</h1>
          <p className="text-xl text-gray-600 mb-6">
            Get assigned a dedicated transaction coordinator who will guide you through every step of your home buying journey
          </p>
          <div className="flex items-center justify-center space-x-2 text-blue-600">
            <Star className="h-5 w-5 fill-current" />
            <span className="font-semibold">Personalized Service • Expert Guidance • Stress-Free Process</span>
            <Star className="h-5 w-5 fill-current" />
          </div>
        </div>

        {/* Benefits Section */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-8">Why Buy with The Hub?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow">
                <div className="mb-4">{benefit.icon}</div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{benefit.title}</h3>
                <p className="text-gray-600 text-sm">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Process Section */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-8">How It Works</h2>
          <div className="max-w-4xl mx-auto">
            {process.map((item, index) => (
              <div key={index} className="flex items-start mb-8 last:mb-0">
                <div className="flex-shrink-0 mr-6">
                  <div className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">
                    {item.step}
                  </div>
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{item.title}</h3>
                  <p className="text-gray-600">{item.description}</p>
                </div>
                <div className="flex-shrink-0 ml-4 text-blue-600">
                  {item.icon}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Form Section */}
        <div className="max-w-3xl mx-auto">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Get Started Today</h2>
              <p className="text-gray-600">Tell us about your dream home and we'll assign you a coordinator</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Personal Information */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Personal Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Full Name *
                    </label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                      <input
                        type="text"
                        value={formData.fullName}
                        onChange={(e) => handleInputChange('fullName', e.target.value)}
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="John Smith"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Phone Number *
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => handleInputChange('phone', e.target.value)}
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="(555) 123-4567"
                        required
                      />
                    </div>
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email Address *
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="john@example.com"
                        required
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Home Preferences */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Home Preferences</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Preferred Location *
                    </label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                      <input
                        type="text"
                        value={formData.preferredLocation}
                        onChange={(e) => handleInputChange('preferredLocation', e.target.value)}
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="San Francisco, CA or specific neighborhoods"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Price Range *
                    </label>
                    <select
                      value={formData.priceRange}
                      onChange={(e) => handleInputChange('priceRange', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    >
                      <option value="">Select price range</option>
                      <option value="under-300k">Under $300K</option>
                      <option value="300k-500k">$300K - $500K</option>
                      <option value="500k-750k">$500K - $750K</option>
                      <option value="750k-1m">$750K - $1M</option>
                      <option value="1m-1.5m">$1M - $1.5M</option>
                      <option value="1.5m-2m">$1.5M - $2M</option>
                      <option value="over-2m">Over $2M</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Property Type
                    </label>
                    <select
                      value={formData.propertyType}
                      onChange={(e) => handleInputChange('propertyType', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="">Any type</option>
                      <option value="house">House</option>
                      <option value="condo">Condo</option>
                      <option value="townhouse">Townhouse</option>
                      <option value="apartment">Apartment</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Bedrooms
                    </label>
                    <select
                      value={formData.bedrooms}
                      onChange={(e) => handleInputChange('bedrooms', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="">Any</option>
                      <option value="1">1+</option>
                      <option value="2">2+</option>
                      <option value="3">3+</option>
                      <option value="4">4+</option>
                      <option value="5">5+</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Bathrooms
                    </label>
                    <select
                      value={formData.bathrooms}
                      onChange={(e) => handleInputChange('bathrooms', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="">Any</option>
                      <option value="1">1+</option>
                      <option value="2">2+</option>
                      <option value="3">3+</option>
                      <option value="4">4+</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Timeline and Financing */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Timeline & Financing</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Timeline to Purchase *
                    </label>
                    <select
                      value={formData.timeline}
                      onChange={(e) => handleInputChange('timeline', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    >
                      <option value="">Select timeline</option>
                      <option value="asap">ASAP (within 30 days)</option>
                      <option value="1-3-months">1-3 months</option>
                      <option value="3-6-months">3-6 months</option>
                      <option value="6-12-months">6-12 months</option>
                      <option value="over-1-year">Over 1 year</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Pre-approved for Financing?
                    </label>
                    <select
                      value={formData.preApproved}
                      onChange={(e) => handleInputChange('preApproved', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="">Select status</option>
                      <option value="yes">Yes, already pre-approved</option>
                      <option value="no">No, need help with financing</option>
                      <option value="cash">Paying cash</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Additional Information */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Additional Information
                </label>
                <textarea
                  rows={4}
                  value={formData.additionalInfo}
                  onChange={(e) => handleInputChange('additionalInfo', e.target.value)}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Tell us about any specific requirements, must-haves, or questions you have..."
                />
              </div>

              {/* Submit Button */}
              <div className="text-center">
                <button
                  type="submit"
                  disabled={!isFormValid()}
                  className={`px-12 py-4 rounded-xl font-semibold text-lg transition-all flex items-center mx-auto ${
                    isFormValid()
                      ? 'bg-gradient-to-r from-slate-700 to-slate-600 text-white hover:from-slate-800 hover:to-slate-700 shadow-lg hover:shadow-slate-500/25'
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  Get My Transaction Coordinator
                  <ArrowRight className="h-5 w-5 ml-2" />
                </button>
                <p className="text-sm text-gray-500 mt-3">
                  Free service • Your coordinator will contact you within 2 hours
                </p>
              </div>
            </form>
          </div>
        </div>

        {/* Trust Indicators */}
        <div className="mt-16 text-center">
          <div className="bg-white rounded-xl shadow-lg p-8 max-w-4xl mx-auto">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Why Buyers Choose The Hub</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 mb-2">500+</div>
                <div className="text-gray-600">Successful Home Purchases</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-2">4.9★</div>
                <div className="text-gray-600">Average Client Rating</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600 mb-2">15+</div>
                <div className="text-gray-600">Years of Experience</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};