import React from 'react';
import { Heart, Trash2, Bell, BellOff, MapPin, Bed, Bath, Square, Calendar, TrendingDown } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { mockProperties } from '../data/mockData';

interface SavedPropertiesProps {
  onNavigate: (page: string) => void;
}

export const SavedProperties: React.FC<SavedPropertiesProps> = ({ onNavigate }) => {
  const { savedProperties, toggleSaved, priceAlerts, removePriceAlert } = useApp();

  const saved = mockProperties.filter(p => savedProperties.includes(p.id));

  const formatPrice = (price: number) =>
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0 }).format(price);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="mb-10">
          <div className="flex items-center gap-3 mb-2">
            <Heart className="h-8 w-8 text-red-500 fill-current" />
            <h1 className="text-4xl font-bold text-slate-800">Saved Homes</h1>
          </div>
          <p className="text-slate-600 text-lg">
            {saved.length === 0 ? 'No saved homes yet' : `${saved.length} home${saved.length !== 1 ? 's' : ''} saved`}
          </p>
        </div>

        {saved.length === 0 ? (
          <div className="text-center py-24 bg-white rounded-3xl border border-slate-200 shadow-sm">
            <Heart className="h-16 w-16 text-slate-300 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-slate-700 mb-2">No saved homes yet</h2>
            <p className="text-slate-500 mb-8">Browse properties and click the heart icon to save them here.</p>
            <button
              onClick={() => onNavigate('listings')}
              className="px-8 py-3 bg-slate-700 text-white rounded-2xl hover:bg-slate-800 transition-colors font-semibold"
            >
              Browse Properties
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {saved.map(property => {
              const alert = priceAlerts.find(a => a.propertyId === property.id);
              return (
                <div key={property.id} className="bg-white rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden border border-slate-100">
                  <div className="relative">
                    <img
                      src={property.images[0]}
                      alt={property.title}
                      className="w-full h-48 object-cover cursor-pointer"
                      onClick={() => onNavigate('listings')}
                    />
                    <button
                      onClick={() => toggleSaved(property.id)}
                      className="absolute top-3 right-3 p-2 bg-white rounded-full shadow-md hover:bg-red-50 transition-colors"
                    >
                      <Heart className="h-5 w-5 text-red-500 fill-current" />
                    </button>
                    {alert && (
                      <div className="absolute bottom-3 left-3 bg-amber-500 text-white px-2 py-1 rounded-lg text-xs font-semibold flex items-center gap-1">
                        <Bell className="h-3 w-3" /> Alert Active
                      </div>
                    )}
                  </div>
                  <div className="p-5">
                    <div className="text-2xl font-bold text-slate-800 mb-1">{formatPrice(property.price)}</div>
                    <h3 className="font-semibold text-slate-700 mb-1 line-clamp-1">{property.title}</h3>
                    <div className="flex items-center text-slate-500 text-sm mb-3">
                      <MapPin className="h-3 w-3 mr-1" />
                      {property.address}, {property.city}, {property.state}
                    </div>
                    <div className="flex items-center gap-4 text-slate-600 text-sm mb-4">
                      <span className="flex items-center gap-1"><Bed className="h-4 w-4" />{property.bedrooms}bd</span>
                      <span className="flex items-center gap-1"><Bath className="h-4 w-4" />{property.bathrooms}ba</span>
                      <span className="flex items-center gap-1"><Square className="h-4 w-4" />{property.squareFeet.toLocaleString()} sqft</span>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => onNavigate('listings')}
                        className="flex-1 py-2 bg-slate-700 text-white rounded-xl text-sm font-medium hover:bg-slate-800 transition-colors"
                      >
                        View Details
                      </button>
                      {alert ? (
                        <button
                          onClick={() => removePriceAlert(alert.id)}
                          className="px-3 py-2 bg-amber-100 text-amber-700 rounded-xl text-sm hover:bg-amber-200 transition-colors"
                          title="Remove price alert"
                        >
                          <BellOff className="h-4 w-4" />
                        </button>
                      ) : null}
                      <button
                        onClick={() => toggleSaved(property.id)}
                        className="px-3 py-2 bg-red-100 text-red-600 rounded-xl text-sm hover:bg-red-200 transition-colors"
                        title="Remove from saved"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Price Alerts Section */}
        {priceAlerts.length > 0 && (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-8">
            <div className="flex items-center gap-3 mb-6">
              <TrendingDown className="h-6 w-6 text-amber-500" />
              <h2 className="text-2xl font-bold text-slate-800">Price Drop Alerts</h2>
            </div>
            <div className="space-y-4">
              {priceAlerts.map(alert => (
                <div key={alert.id} className="flex items-center justify-between p-4 bg-amber-50 rounded-2xl border border-amber-100">
                  <div>
                    <div className="font-semibold text-slate-800">{alert.propertyTitle}</div>
                    <div className="text-sm text-slate-600">{alert.propertyAddress}</div>
                    <div className="text-sm text-amber-700 mt-1">
                      Alert at: {formatPrice(alert.targetPrice)} · Notifying: {alert.email}
                    </div>
                  </div>
                  <button
                    onClick={() => removePriceAlert(alert.id)}
                    className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
