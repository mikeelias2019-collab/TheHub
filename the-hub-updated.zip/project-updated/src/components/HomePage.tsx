import React, { useState } from 'react';
import { Search, MapPin, Filter, Star, Zap, TrendingUp, Heart, ChevronDown } from 'lucide-react';
import { InteractiveMap } from './InteractiveMap';
import { mockProperties } from '../data/mockData';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [addressSuggestions, setAddressSuggestions] = useState<string[]>([]);
  const [showMap, setShowMap] = useState(false);

  // Mock address database - in real app this would be an API call to address service
  const mockAddresses = [
    '123 Oak Street, Pleasant Valley, CA 94102',
    '123 Oak Avenue, Pleasant Valley, CA 94102',
    '123 Oak Drive, San Francisco, CA 94103',
    '456 High Street, Metro City, NY 10001',
    '456 High Avenue, Metro City, NY 10001',
    '789 Maple Avenue, Green Hills, TX 75201',
    '789 Maple Street, Green Hills, TX 75201',
    '321 Pine Road, Sunset Valley, FL 33101',
    '321 Pine Street, Sunset Valley, FL 33101',
    '555 Broadway, New York, NY 10012',
    '777 Market Street, San Francisco, CA 94103',
    '888 Fifth Avenue, New York, NY 10022',
    '999 Sunset Boulevard, Los Angeles, CA 90028',
    '111 Main Street, Boston, MA 02101',
    '222 State Street, Chicago, IL 60601',
    '333 King Street, Seattle, WA 98101',
    '444 Queen Street, Portland, OR 97201',
    '555 First Street, Austin, TX 78701',
    '666 Second Avenue, Denver, CO 80202',
    '777 Third Street, Phoenix, AZ 85001'
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setShowSuggestions(false);
    onNavigate('listings');
  };

  const handleSearchInputChange = (value: string) => {
    setSearchQuery(value);
    
    if (value.length >= 2) {
      // Simulate AI-powered address matching
      const suggestions = mockAddresses
        .filter(address => 
          address.toLowerCase().includes(value.toLowerCase())
        )
        .slice(0, 6); // Show max 6 suggestions
      
      setAddressSuggestions(suggestions);
      setShowSuggestions(suggestions.length > 0);
    } else {
      setShowSuggestions(false);
      setAddressSuggestions([]);
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setSearchQuery(suggestion);
    setShowSuggestions(false);
  };

  const handleSearchFocus = () => {
    if (searchQuery.length >= 2 && addressSuggestions.length > 0) {
      setShowSuggestions(true);
    }
  };

  const handleSearchBlur = () => {
    // Delay hiding suggestions to allow for clicks
    setTimeout(() => {
      setShowSuggestions(false);
    }, 200);
  };
  const stats = [
    { label: 'Homes Sold', value: '2.4K+', icon: '🏠' },
    { label: 'Happy Families', value: '1.8K+', icon: '❤️' },
    { label: 'Years Experience', value: '15+', icon: '⭐' },
    { label: 'Cities', value: '50+', icon: '🌟' }
  ];

  const features = [
    {
      icon: <Search className="h-8 w-8 text-slate-600" />,
      title: 'AI-Powered Search',
      description: 'Advanced search with price predictions, market insights, and personalized recommendations.',
    },
    {
      icon: <TrendingUp className="h-8 w-8 text-slate-500" />,
      title: 'Market Intelligence',
      description: 'Real-time market data, price history, and neighborhood insights to make informed decisions.',
    },
    {
      icon: <MapPin className="h-8 w-8 text-slate-700" />,
      title: 'Neighborhood Intel',
      description: 'Walk scores, school ratings, local amenities, and community insights all in one place.',
    },
    {
      icon: <Heart className="h-8 w-8 text-slate-600" />,
      title: 'Save & Track',
      description: 'Save properties, create alerts, and track price changes on your favorite homes.',
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 text-slate-800 relative overflow-hidden">
      {/* Subtle Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Animated gradient orbs */}
        <div className="absolute top-20 left-10 w-72 h-72 bg-gradient-to-r from-blue-200/20 to-slate-200/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute top-40 right-20 w-96 h-96 bg-gradient-to-r from-slate-300/15 to-blue-300/15 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute bottom-40 left-1/4 w-80 h-80 bg-gradient-to-r from-blue-100/25 to-slate-200/25 rounded-full blur-3xl animate-pulse delay-2000"></div>
        <div className="absolute bottom-20 right-1/3 w-64 h-64 bg-gradient-to-r from-slate-200/20 to-blue-200/20 rounded-full blur-3xl animate-pulse delay-500"></div>
        
        {/* Geometric patterns */}
        <div className="absolute top-1/3 left-1/2 transform -translate-x-1/2 w-px h-32 bg-gradient-to-b from-transparent via-blue-400/30 to-transparent"></div>
        <div className="absolute top-1/2 left-1/4 w-32 h-px bg-gradient-to-r from-transparent via-slate-400/30 to-transparent"></div>
        <div className="absolute bottom-1/3 right-1/4 w-px h-24 bg-gradient-to-b from-transparent via-blue-300/30 to-transparent"></div>
      </div>

      {/* Hero Section */}
      <div className="relative">
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-8 bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent">
              <span className="text-black">
                The Future of Real Estate
              </span>
            </h1>
            <div className="max-w-4xl mx-auto mb-12">
              <p className="text-xl md:text-2xl text-slate-600 font-light mb-6">
                Advanced search, market intelligence, and seamless transactions - all in one platform.
              </p>
              <p className="text-xl md:text-2xl text-slate-700 font-medium mb-8">
                Whether you're buying, selling, or just exploring - we make real estate simple and transparent.
              </p>
            </div>

            {/* Search Form */}
            <form onSubmit={handleSearch} className="max-w-4xl mx-auto">
              <div className="flex flex-col md:flex-row gap-4 bg-white/90 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-slate-200 hover:border-blue-300 transition-all duration-300">
                <div className="flex-1 relative">
                  <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-500 h-6 w-6" />
                  <input
                    type="text"
                    placeholder="Search by address, city, or neighborhood..."
                    value={searchQuery}
                    onChange={(e) => handleSearchInputChange(e.target.value)}
                    onFocus={handleSearchFocus}
                    onBlur={handleSearchBlur}
                    className="w-full pl-12 pr-4 py-4 bg-slate-50 text-slate-800 rounded-2xl border border-slate-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-400/50 transition-all placeholder-slate-500 backdrop-blur-sm hover:bg-white"
                  />
                  
                  {/* Address Suggestions Dropdown */}
                  {showSuggestions && (
                    <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-2xl border border-slate-200 z-50 max-h-80 overflow-y-auto">
                      <div className="p-3 border-b border-slate-100">
                        <div className="flex items-center text-sm text-slate-600">
                          <MapPin className="h-4 w-4 mr-2 text-slate-500" />
                          <span className="font-medium">Address Suggestions</span>
                        </div>
                      </div>
                      {addressSuggestions.map((suggestion, index) => (
                        <button
                          key={index}
                          type="button"
                          onMouseDown={(e) => e.preventDefault()} // Prevent blur from firing
                          onClick={() => handleSuggestionClick(suggestion)}
                          className="w-full text-left px-4 py-3 hover:bg-slate-50 transition-colors border-b border-slate-50 last:border-b-0 flex items-center"
                        >
                          <MapPin className="h-4 w-4 mr-3 text-slate-400 flex-shrink-0" />
                          <div>
                            <div className="text-slate-800 font-medium">
                              {suggestion.split(',')[0]}
                            </div>
                            <div className="text-sm text-slate-500">
                              {suggestion.split(',').slice(1).join(',').trim()}
                            </div>
                          </div>
                        </button>
                      ))}
                      <div className="p-3 bg-slate-50 text-center">
                        <div className="text-xs text-slate-500">
                          🤖 Powered by AI Smart Address Engine
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => setShowFilters(!showFilters)}
                  className="flex items-center justify-center px-6 py-4 bg-slate-100 text-slate-700 rounded-2xl hover:bg-slate-200 transition-all border border-slate-200 hover:border-slate-300 hover:scale-105"
                >
                  <Filter className="h-5 w-5 mr-2" />
                  Filters
                </button>
                <button
                  type="submit"
                  className="px-8 py-4 bg-gradient-to-r from-slate-600 to-slate-500 text-white rounded-2xl hover:from-slate-700 hover:to-slate-600 transition-all font-semibold shadow-lg hover:shadow-slate-500/30 hover:scale-105"
                >
                  Search Homes
                </button>
              </div>

              {/* Filter Options */}
              {showFilters && (
                <div className="mt-6 bg-white/90 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-slate-200 animate-in slide-in-from-top-4 duration-300">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2 text-slate-700">Property Type</label>
                      <select className="w-full p-3 bg-slate-50 border border-slate-200 rounded-2xl text-slate-800 focus:border-slate-400 transition-all backdrop-blur-sm hover:bg-white">
                        <option className="bg-white">All Types</option>
                        <option className="bg-white">House</option>
                        <option className="bg-white">Condo</option>
                        <option className="bg-white">Townhouse</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2 text-slate-700">Price Range</label>
                      <select className="w-full p-3 bg-slate-50 border border-slate-200 rounded-2xl text-slate-800 focus:border-slate-400 transition-all backdrop-blur-sm hover:bg-white">
                        <option className="bg-white">Any Price</option>
                        <option className="bg-white">Under $500K</option>
                        <option className="bg-white">$500K - $1M</option>
                        <option className="bg-white">Over $1M</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2 text-slate-700">Bedrooms</label>
                      <select className="w-full p-3 bg-slate-50 border border-slate-200 rounded-2xl text-slate-800 focus:border-slate-400 transition-all backdrop-blur-sm hover:bg-white">
                        <option className="bg-white">Any</option>
                        <option className="bg-white">1+</option>
                        <option className="bg-white">2+</option>
                        <option className="bg-white">3+</option>
                        <option className="bg-white">4+</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2 text-slate-700">Bathrooms</label>
                      <select className="w-full p-3 bg-slate-50 border border-slate-200 rounded-2xl text-slate-800 focus:border-slate-400 transition-all backdrop-blur-sm hover:bg-white">
                        <option className="bg-white">Any</option>
                        <option className="bg-white">1+</option>
                        <option className="bg-white">2+</option>
                        <option className="bg-white">3+</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}
            </form>
          </div>
        </div>
      </div>

      {/* Overlay to close suggestions when clicking outside */}
      {showSuggestions && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setShowSuggestions(false)}
        />
      )}

      {/* Interactive Map Section */}
      <div className="py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-slate-800 mb-4">
              Explore Neighborhoods
            </h2>
            <p className="text-xl text-slate-600">
              Discover communities and find where you belong
            </p>
          </div>

          {/* Map Placeholder */}
          <div className="relative bg-gradient-to-br from-white to-slate-50 rounded-3xl overflow-hidden shadow-2xl border border-slate-200 backdrop-blur-xl">
            <div className="flex items-center justify-between p-6 border-b border-slate-200">
              <h3 className="text-2xl font-bold text-slate-800">Explore Properties on Map</h3>
              <div className="flex space-x-2">
                <button
                  onClick={() => setShowMap(!showMap)}
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    showMap ? 'bg-slate-600 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {showMap ? 'Hide Map' : 'Show Map'}
                </button>
                <button
                  onClick={() => onNavigate('listings')}
                  className="px-4 py-2 bg-slate-600 text-white rounded-lg hover:bg-slate-700 transition-colors"
                >
                  View All Properties
                </button>
              </div>
            </div>
            
            {showMap ? (
              <div className="h-96">
                <InteractiveMap
                  properties={mockProperties}
                  onPropertySelect={(property) => {
                    console.log('Selected property:', property);
                    onNavigate('listings');
                  }}
                />
              </div>
            ) : (
              <div className="h-96 flex items-center justify-center relative">
                <div className="text-center z-10">
                  <div className="mb-6">
                    <MapPin className="h-16 w-16 text-slate-500 mx-auto animate-bounce" />
                  </div>
                  <h3 className="text-2xl font-bold text-slate-800 mb-4">Interactive Property Map</h3>
                  <p className="text-slate-600 mb-6">Click "Show Map" to explore properties and neighborhoods visually</p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl mx-auto text-sm">
                    <div className="bg-white/80 p-4 rounded-lg">
                      <div className="text-slate-700 font-semibold mb-1">🗺️ Live MLS Data</div>
                      <div className="text-slate-600">Real-time property listings</div>
                    </div>
                    <div className="bg-white/80 p-4 rounded-lg">
                      <div className="text-slate-700 font-semibold mb-1">📍 Smart Markers</div>
                      <div className="text-slate-600">Color-coded by price range</div>
                    </div>
                    <div className="bg-white/80 p-4 rounded-lg">
                      <div className="text-slate-700 font-semibold mb-1">🔍 Advanced Filters</div>
                      <div className="text-slate-600">Filter by price, type, features</div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Subtle Map Markers */}
            {!showMap && (
              <>
                <div className="absolute top-1/4 left-1/3 w-4 h-4 bg-slate-400 rounded-full opacity-70 animate-ping"></div>
                <div className="absolute top-1/2 right-1/4 w-4 h-4 bg-slate-500 rounded-full opacity-70 animate-ping delay-300"></div>
                <div className="absolute bottom-1/3 left-1/2 w-4 h-4 bg-slate-400 rounded-full opacity-70 animate-ping delay-700"></div>
                <div className="absolute top-3/4 right-1/3 w-4 h-4 bg-slate-600 rounded-full opacity-70 animate-ping delay-1000"></div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-slate-800 mb-4">
              Why We Built The Hub
            </h2>
            <p className="text-xl text-slate-600">
              Born from real experience, built to solve real problems
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="bg-gradient-to-br from-white to-slate-50 backdrop-blur-xl p-6 rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-500 border border-slate-200 hover:border-slate-300 group hover:scale-105 hover:-translate-y-2"
              >
                <div className="mb-4 transform group-hover:scale-110 transition-transform">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-3">
                  {feature.title}
                </h3>
                <p className="text-slate-600 leading-relaxed text-sm">{feature.description}</p>
                <div className="h-1 w-full bg-gradient-to-r from-slate-400 to-slate-500 rounded-full mt-4 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500"></div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="py-20 bg-gradient-to-r from-slate-100 via-slate-50 to-slate-100 relative backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center group hover:scale-110 transition-transform duration-300">
                <div className="text-4xl mb-3 transform group-hover:scale-110 transition-transform">
                  {stat.icon}
                </div>
                <div className="text-4xl font-bold mb-2 text-slate-800">
                  {stat.value}
                </div>
                <div className="text-slate-600 font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-slate-800 mb-6">
            Help Us Be Better
          </h2>
          <p className="text-xl text-slate-600 mb-10">
            We're constantly improving The Hub to serve you better. Send us a message and let us know how we can enhance your experience.
          </p>
          <div className="bg-white/90 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-slate-200 max-w-2xl mx-auto">
            <form className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Your Name
                </label>
                <input
                  type="text"
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-2xl text-slate-800 focus:border-slate-400 focus:ring-2 focus:ring-slate-400/50 transition-all backdrop-blur-sm hover:bg-white"
                  placeholder="Enter your name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-2xl text-slate-800 focus:border-slate-400 focus:ring-2 focus:ring-slate-400/50 transition-all backdrop-blur-sm hover:bg-white"
                  placeholder="Enter your email"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  How can we improve The Hub?
                </label>
                <textarea
                  rows={4}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-2xl text-slate-800 focus:border-slate-400 focus:ring-2 focus:ring-slate-400/50 transition-all backdrop-blur-sm hover:bg-white resize-none"
                  placeholder="Share your suggestions, feedback, or ideas to help us make The Hub better for everyone..."
                />
              </div>
              <button
                type="submit"
                className="w-full px-8 py-4 bg-gradient-to-r from-slate-700 to-slate-600 text-white rounded-2xl hover:from-slate-800 hover:to-slate-700 transition-all font-semibold text-lg shadow-lg hover:shadow-slate-500/30 hover:scale-105"
              >
                Send Feedback
              </button>
            </form>
            <p className="text-sm text-slate-500 mt-4">
              Your feedback helps us build a better experience for everyone in the real estate community.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};