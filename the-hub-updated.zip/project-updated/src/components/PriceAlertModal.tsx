import React, { useState } from 'react';
import { Bell, DollarSign, Mail, X, CheckCircle, TrendingDown } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Property } from '../types';

interface PriceAlertModalProps {
  property: Property;
  onClose: () => void;
}

export const PriceAlertModal: React.FC<PriceAlertModalProps> = ({ property, onClose }) => {
  const { addPriceAlert, priceAlerts } = useApp();
  const [targetPrice, setTargetPrice] = useState(Math.round(property.price * 0.95));
  const [email, setEmail] = useState('');
  const [alertType, setAlertType] = useState<'drop' | 'any_change'>('drop');
  const [submitted, setSubmitted] = useState(false);

  const existing = priceAlerts.find(a => a.propertyId === property.id);

  const fmt = (n: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0 }).format(n);
  const pctOff = Math.round(((property.price - targetPrice) / property.price) * 100);

  const handleSubmit = () => {
    if (!email) return;
    addPriceAlert({
      propertyId: property.id,
      propertyTitle: property.title,
      propertyAddress: `${property.address}, ${property.city}`,
      originalPrice: property.price,
      targetPrice,
      alertType,
      email,
    });
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between p-6 border-b border-slate-100 bg-gradient-to-r from-amber-500 to-orange-500">
          <div className="flex items-center gap-2">
            <Bell className="h-6 w-6 text-white" />
            <h2 className="text-xl font-bold text-white">Price Drop Alert</h2>
          </div>
          <button onClick={onClose} className="p-2 text-white/70 hover:text-white hover:bg-white/10 rounded-full transition-colors">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-6">
          {submitted || existing ? (
            <div className="text-center py-6">
              <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-3" />
              <h3 className="text-xl font-bold text-slate-800 mb-2">Alert Set!</h3>
              <p className="text-slate-600 text-sm mb-1">
                We'll notify you when this property drops {existing ? 'in price' : `to ${fmt(targetPrice)}`}.
              </p>
              <p className="text-slate-500 text-sm mb-6">{existing ? existing.email : email}</p>
              <button onClick={onClose} className="px-6 py-2 bg-slate-700 text-white rounded-xl font-medium hover:bg-slate-800 transition-colors">
                Done
              </button>
            </div>
          ) : (
            <>
              <div className="bg-slate-50 rounded-2xl p-4 mb-5">
                <div className="font-semibold text-slate-800 mb-0.5 line-clamp-1">{property.title}</div>
                <div className="text-slate-600 text-sm">{property.address}, {property.city}</div>
                <div className="text-slate-800 font-bold mt-2">{fmt(property.price)}</div>
              </div>

              <div className="space-y-5">
                {/* Alert type */}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Alert me when</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setAlertType('drop')}
                      className={`py-3 px-4 rounded-xl text-sm font-medium border-2 transition-all ${
                        alertType === 'drop' ? 'border-amber-500 bg-amber-50 text-amber-700' : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      <TrendingDown className="h-4 w-4 mx-auto mb-1" />
                      Drops to target
                    </button>
                    <button
                      onClick={() => setAlertType('any_change')}
                      className={`py-3 px-4 rounded-xl text-sm font-medium border-2 transition-all ${
                        alertType === 'any_change' ? 'border-amber-500 bg-amber-50 text-amber-700' : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      <Bell className="h-4 w-4 mx-auto mb-1" />
                      Any price change
                    </button>
                  </div>
                </div>

                {alertType === 'drop' && (
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Target Price: {fmt(targetPrice)} <span className="text-green-600">({pctOff}% below asking)</span>
                    </label>
                    <input
                      type="range"
                      min={Math.round(property.price * 0.7)}
                      max={property.price}
                      step={1000}
                      value={targetPrice}
                      onChange={e => setTargetPrice(Number(e.target.value))}
                      className="w-full accent-amber-500"
                    />
                    <div className="flex justify-between text-xs text-slate-400 mt-1">
                      <span>{fmt(Math.round(property.price * 0.7))} (30% off)</span>
                      <span>{fmt(property.price)} (asking)</span>
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Notify me at</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <input
                      type="email"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      placeholder="your@email.com"
                      className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl bg-slate-50 focus:ring-2 focus:ring-amber-400 focus:border-transparent"
                    />
                  </div>
                </div>

                <button
                  onClick={handleSubmit}
                  disabled={!email}
                  className="w-full py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-2xl font-semibold hover:from-amber-600 hover:to-orange-600 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  Set Alert
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
