import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Bot, User, Sparkles, RotateCcw } from 'lucide-react';
import { Property } from '../types';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface AIPropertyChatProps {
  property?: Property;
  onClose?: () => void;
  floating?: boolean;
}

const QUICK_QUESTIONS = [
  'What are the monthly costs?',
  'Tell me about the neighborhood',
  'How does the price compare to similar homes?',
  'What are the top pros and cons?',
  'Is this a good investment?',
];

export const AIPropertyChat: React.FC<AIPropertyChatProps> = ({ property, onClose, floating = false }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '0',
      role: 'assistant',
      content: property
        ? `Hi! I'm your AI real estate assistant. I'm here to help you learn about **${property.title}** at ${property.address}, ${property.city}. What would you like to know?`
        : `Hi! I'm your AI real estate assistant. Ask me anything about buying, selling, mortgages, neighborhoods, or any property on this platform. How can I help?`,
      timestamp: new Date(),
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const buildSystemPrompt = () => {
    let sys = `You are a knowledgeable, friendly real estate AI assistant called "Hub AI". You help users understand properties, the buying/selling process, mortgages, and neighborhoods. Keep responses concise (2-4 sentences) and conversational. Use markdown for clarity when needed.`;
    if (property) {
      sys += `\n\nCurrent property context:\n`;
      sys += `- Title: ${property.title}\n`;
      sys += `- Price: $${property.price.toLocaleString()}\n`;
      sys += `- Address: ${property.address}, ${property.city}, ${property.state} ${property.zipCode}\n`;
      sys += `- Bedrooms: ${property.bedrooms}, Bathrooms: ${property.bathrooms}, Sqft: ${property.squareFeet.toLocaleString()}\n`;
      sys += `- Year Built: ${property.yearBuilt || 'Unknown'}\n`;
      sys += `- Type: ${property.propertyType}\n`;
      sys += `- Features: ${property.features?.join(', ') || 'Not specified'}\n`;
      sys += `- Days on Market: ${property.daysOnMarket || 0}\n`;
      if (property.walkScore) sys += `- Walk Score: ${property.walkScore}\n`;
      if (property.schoolRatings?.length) sys += `- School Ratings: ${property.schoolRatings.map(s => `${s.name} (${s.rating}/10)`).join(', ')}\n`;
      if (property.marketTrends) sys += `- Market Trend: ${property.marketTrends.priceChange > 0 ? '+' : ''}${property.marketTrends.priceChange}% price change, ${property.marketTrends.daysOnMarket} avg days on market\n`;
      if (property.propertyTax) sys += `- Property Tax: ~$${property.propertyTax.toLocaleString()}/year\n`;
      sys += `\nAnswer questions specifically about this property using the data above. For monthly cost estimates, use ~6.8% interest rate and 20% down by default.`;
    }
    return sys;
  };

  const send = async (text: string) => {
    if (!text.trim() || loading) return;
    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: text, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          system: buildSystemPrompt(),
          messages: [...messages, userMsg]
            .filter(m => m.role === 'user' || m.role === 'assistant')
            .map(m => ({ role: m.role, content: m.content })),
        }),
      });
      const data = await res.json();
      const reply = data.content?.[0]?.text || 'Sorry, I had trouble responding. Please try again.';
      setMessages(prev => [...prev, { id: Date.now().toString() + 'a', role: 'assistant', content: reply, timestamp: new Date() }]);
    } catch {
      setMessages(prev => [...prev, { id: Date.now().toString() + 'e', role: 'assistant', content: 'Sorry, I ran into an error. Please try again.', timestamp: new Date() }]);
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setMessages([{
      id: '0r',
      role: 'assistant',
      content: property
        ? `Hi again! Ask me anything about **${property.title}**.`
        : `Hi! I'm your AI real estate assistant. How can I help?`,
      timestamp: new Date(),
    }]);
  };

  const renderContent = (content: string) => {
    // Simple markdown: bold and line breaks
    return content
      .split('\n')
      .map((line, i) => (
        <span key={i}>
          {line.split(/\*\*(.*?)\*\*/g).map((part, j) =>
            j % 2 === 1 ? <strong key={j}>{part}</strong> : part
          )}
          {i < content.split('\n').length - 1 && <br />}
        </span>
      ));
  };

  const chatUI = (
    <div className={`flex flex-col ${floating ? 'h-full' : 'h-[600px]'}`}>
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map(msg => (
          <div key={msg.id} className={`flex gap-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            {msg.role === 'assistant' && (
              <div className="w-7 h-7 bg-gradient-to-br from-slate-600 to-slate-700 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <Bot className="h-4 w-4 text-white" />
              </div>
            )}
            <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
              msg.role === 'user'
                ? 'bg-slate-700 text-white rounded-br-sm'
                : 'bg-slate-100 text-slate-800 rounded-bl-sm'
            }`}>
              {renderContent(msg.content)}
            </div>
            {msg.role === 'user' && (
              <div className="w-7 h-7 bg-slate-200 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <User className="h-4 w-4 text-slate-600" />
              </div>
            )}
          </div>
        ))}
        {loading && (
          <div className="flex gap-2 justify-start">
            <div className="w-7 h-7 bg-gradient-to-br from-slate-600 to-slate-700 rounded-full flex items-center justify-center flex-shrink-0">
              <Bot className="h-4 w-4 text-white" />
            </div>
            <div className="bg-slate-100 rounded-2xl rounded-bl-sm px-4 py-3">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}
        <div ref={endRef} />
      </div>

      {/* Quick questions */}
      {messages.length <= 1 && (
        <div className="px-4 pb-2">
          <div className="flex flex-wrap gap-2">
            {QUICK_QUESTIONS.map(q => (
              <button
                key={q}
                onClick={() => send(q)}
                className="text-xs px-3 py-1.5 bg-slate-100 text-slate-600 rounded-full hover:bg-slate-200 transition-colors border border-slate-200"
              >
                {q}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="p-4 border-t border-slate-100">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send(input)}
            placeholder="Ask anything about this property..."
            className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm focus:ring-2 focus:ring-slate-400 focus:border-transparent"
          />
          <button
            onClick={() => send(input)}
            disabled={!input.trim() || loading}
            className="p-3 bg-slate-700 text-white rounded-2xl hover:bg-slate-800 transition-colors disabled:opacity-40"
          >
            <Send className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );

  if (floating) {
    return (
      <div className="fixed bottom-6 right-6 z-50 w-96 bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col" style={{ height: '520px' }}>
        <div className="flex items-center justify-between p-4 bg-gradient-to-r from-slate-700 to-slate-600">
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-amber-400" />
            <span className="font-semibold text-white text-sm">Hub AI Assistant</span>
          </div>
          <div className="flex items-center gap-1">
            <button onClick={reset} className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors" title="Reset chat">
              <RotateCcw className="h-4 w-4" />
            </button>
            {onClose && (
              <button onClick={onClose} className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors">
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
        {chatUI}
      </div>
    );
  }

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="flex items-center justify-between p-5 border-b border-slate-100 bg-gradient-to-r from-slate-700 to-slate-600">
        <div className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-amber-400" />
          <span className="font-semibold text-white">Hub AI Assistant</span>
        </div>
        <button onClick={reset} className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors" title="Reset">
          <RotateCcw className="h-4 w-4" />
        </button>
      </div>
      {chatUI}
    </div>
  );
};

// Floating chat button + panel
export const FloatingChat: React.FC<{ property?: Property }> = ({ property }) => {
  const [open, setOpen] = useState(false);
  return (
    <>
      {open && <AIPropertyChat property={property} onClose={() => setOpen(false)} floating />}
      <button
        onClick={() => setOpen(prev => !prev)}
        className="fixed bottom-6 right-6 z-40 w-14 h-14 bg-gradient-to-br from-slate-700 to-slate-600 text-white rounded-full shadow-lg hover:shadow-xl hover:scale-110 transition-all flex items-center justify-center"
        style={{ display: open ? 'none' : 'flex' }}
      >
        <MessageCircle className="h-6 w-6" />
      </button>
    </>
  );
};
