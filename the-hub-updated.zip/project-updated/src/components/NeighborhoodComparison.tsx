import React, { useState } from 'react';
import { MapPin, Star, TrendingUp, TrendingDown, School, ShoppingBag, TreePine, Train, X, Plus, BarChart2 } from 'lucide-react';

interface Neighborhood {
  id: string;
  name: string;
  city: string;
  state: string;
  medianPrice: number;
  priceChange: number;
  walkScore: number;
  transitScore: number;
  schoolRating: number;
  crimeIndex: number; // lower = safer
  avgDaysOnMarket: number;
  restaurants: number;
  parks: number;
  groceryStores: number;
  description: string;
}

const NEIGHBORHOODS: Neighborhood[] = [
  {
    id: '1', name: 'Pleasant Valley', city: 'San Francisco', state: 'CA',
    medianPrice: 1250000, priceChange: 5.2, walkScore: 92, transitScore: 88,
    schoolRating: 9.1, crimeIndex: 18, avgDaysOnMarket: 14,
    restaurants: 142, parks: 23, groceryStores: 8,
    description: 'Vibrant urban neighborhood with excellent transit and walkability.'
  },
  {
    id: '2', name: 'Green Hills', city: 'Austin', state: 'TX',
    medianPrice: 545000, priceChange: 8.1, walkScore: 62, transitScore: 41,
    schoolRating: 8.4, crimeIndex: 24, avgDaysOnMarket: 22,
    restaurants: 78, parks: 31, groceryStores: 5,
    description: 'Growing suburb with top-rated schools and family-friendly amenities.'
  },
  {
    id: '3', name: 'Metro City', city: 'New York', state: 'NY',
    medianPrice: 1800000, priceChange: 2.1, walkScore: 98, transitScore: 100,
    schoolRating: 7.8, crimeIndex: 32, avgDaysOnMarket: 31,
    restaurants: 412, parks: 8, groceryStores: 15,
    description: 'World-class urban living with unbeatable access to everything.'
  },
  {
    id: '4', name: 'Sunset Valley', city: 'Miami', state: 'FL',
    medianPrice: 425000, priceChange: 11.3, walkScore: 51, transitScore: 33,
    schoolRating: 7.2, crimeIndex: 41, avgDaysOnMarket: 19,
    restaurants: 56, parks: 14, groceryStores: 4,
    description: 'Sun-soaked community with strong appreciation and beach access.'
  },
  {
    id: '5', name: 'Oak Park', city: 'Chicago', state: 'IL',
    medianPrice: 380000, priceChange: 3.8, walkScore: 85, transitScore: 76,
    schoolRating: 8.9, crimeIndex: 21, avgDaysOnMarket: 27,
    restaurants: 94, parks: 19, groceryStores: 7,
    description: 'Historic neighborhood known for architecture and excellent schools.'
  },
];

const ScoreBar: React.FC<{ value: number; max?: number; color: string; reverse?: boolean }> = ({ value, max = 100, color, reverse = false }) => {
  const pct = Math.min((value / max) * 100, 100);
  const displayPct = reverse ? 100 - pct : pct;
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 bg-slate-100 rounded-full h-2 overflow-hidden">
        <div className={`h-2 rounded-full transition-all duration-700 ${color}`} style={{ width: `${displayPct}%` }} />
      </div>
      <span className="text-xs font-medium text-slate-600 w-8 text-right">{value}</span>
    </div>
  );
};

export const NeighborhoodComparison: React.FC = () => {
  const [selected, setSelected] = useState<string[]>(['1', '2']);
  const [adding, setAdding] = useState(false);

  const fmt = (n: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0 }).format(n);

  const comparisons = NEIGHBORHOODS.filter(n => selected.includes(n.id));
  const available = NEIGHBORHOODS.filter(n => !selected.includes(n.id));

  const metrics = [
    { label: 'Median Home Price', key: 'medianPrice', format: (v: number) => fmt(v), icon: '💰', color: 'bg-blue-400' },
    { label: 'Price Trend (1yr)', key: 'priceChange', format: (v: number) => `${v > 0 ? '+' : ''}${v}%`, icon: '📈', color: 'bg-emerald-400' },
    { label: 'Walk Score', key: 'walkScore', format: (v: number) => `${v}/100`, icon: '🚶', color: 'bg-slate-500', bar: true },
    { label: 'Transit Score', key: 'transitScore', format: (v: number) => `${v}/100`, icon: '🚇', color: 'bg-purple-400', bar: true },
    { label: 'School Rating', key: 'schoolRating', format: (v: number) => `${v}/10`, icon: '🏫', color: 'bg-amber-400', barMax: 10, bar: true },
    { label: 'Safety Index', key: 'crimeIndex', format: (v: number) => `${v}/100`, icon: '🛡️', color: 'bg-green-400', reverse: true, bar: true },
    { label: 'Avg Days on Market', key: 'avgDaysOnMarket', format: (v: number) => `${v} days`, icon: '📅', color: 'bg-rose-400', barMax: 60, reverse: true, bar: true },
    { label: 'Restaurants', key: 'restaurants', format: (v: number) => `${v}+`, icon: '🍽️', color: 'bg-orange-400', barMax: 500, bar: true },
    { label: 'Parks & Green Space', key: 'parks', format: (v: number) => `${v}+`, icon: '🌳', color: 'bg-green-500', barMax: 40, bar: true },
    { label: 'Grocery Stores', key: 'groceryStores', format: (v: number) => `${v}+`, icon: '🛒', color: 'bg-teal-400', barMax: 20, bar: true },
  ];

  const getBest = (key: string, reverse = false) => {
    if (comparisons.length < 2) return null;
    const vals = comparisons.map(n => ({ id: n.id, val: (n as any)[key] }));
    return reverse ? vals.reduce((a, b) => a.val < b.val ? a : b).id : vals.reduce((a, b) => a.val > b.val ? a : b).id;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <BarChart2 className="h-8 w-8 text-slate-600" />
            <h1 className="text-4xl font-bold text-slate-800">Neighborhood Comparison</h1>
          </div>
          <p className="text-slate-600 text-lg">Compare neighborhoods side-by-side to find your perfect community</p>
        </div>

        {/* Selected neighborhoods header */}
        <div className="grid gap-4 mb-6" style={{ gridTemplateColumns: `200px repeat(${comparisons.length}, 1fr)${available.length > 0 && selected.length < 4 ? ' 160px' : ''}` }}>
          <div />
          {comparisons.map(n => (
            <div key={n.id} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm relative">
              <button
                onClick={() => setSelected(prev => prev.filter(id => id !== n.id))}
                className="absolute top-3 right-3 p-1 text-slate-300 hover:text-red-400 hover:bg-red-50 rounded-lg transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
              <div className="font-bold text-slate-800 text-lg">{n.name}</div>
              <div className="text-slate-500 text-sm flex items-center gap-1 mb-2">
                <MapPin className="h-3 w-3" />{n.city}, {n.state}
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">{n.description}</p>
            </div>
          ))}
          {selected.length < 4 && available.length > 0 && (
            <div className="relative">
              {adding ? (
                <div className="bg-white rounded-2xl border-2 border-dashed border-slate-300 p-4 space-y-2">
                  <div className="text-sm font-medium text-slate-600 mb-2">Add neighborhood</div>
                  {available.map(n => (
                    <button
                      key={n.id}
                      onClick={() => { setSelected(prev => [...prev, n.id]); setAdding(false); }}
                      className="w-full text-left p-2 hover:bg-slate-50 rounded-lg transition-colors text-sm text-slate-700"
                    >
                      <div className="font-medium">{n.name}</div>
                      <div className="text-xs text-slate-400">{n.city}, {n.state}</div>
                    </button>
                  ))}
                  <button onClick={() => setAdding(false)} className="text-xs text-slate-400 hover:text-slate-600 w-full text-center pt-1">Cancel</button>
                </div>
              ) : (
                <button
                  onClick={() => setAdding(true)}
                  className="w-full h-full min-h-32 bg-white rounded-2xl border-2 border-dashed border-slate-300 hover:border-slate-400 flex flex-col items-center justify-center gap-2 text-slate-400 hover:text-slate-600 transition-all"
                >
                  <Plus className="h-6 w-6" />
                  <span className="text-sm font-medium">Add Area</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Comparison rows */}
        <div className="space-y-2">
          {metrics.map(metric => {
            const bestId = getBest(metric.key, metric.reverse);
            return (
              <div
                key={metric.key}
                className="grid gap-4 bg-white rounded-2xl border border-slate-100 px-4 py-3 hover:border-slate-200 transition-colors"
                style={{ gridTemplateColumns: `200px repeat(${comparisons.length}, 1fr)` }}
              >
                <div className="flex items-center gap-2 text-sm font-medium text-slate-600">
                  <span>{metric.icon}</span>
                  {metric.label}
                </div>
                {comparisons.map(n => {
                  const val = (n as any)[metric.key];
                  const isBest = bestId === n.id;
                  return (
                    <div key={n.id} className={`rounded-xl p-3 transition-colors ${isBest ? 'bg-emerald-50 border border-emerald-100' : ''}`}>
                      <div className={`font-bold text-base mb-1 ${isBest ? 'text-emerald-700' : 'text-slate-800'}`}>
                        {metric.format(val)}
                        {isBest && <span className="ml-1 text-xs font-normal text-emerald-500">★ best</span>}
                      </div>
                      {metric.bar && (
                        <ScoreBar value={val} max={metric.barMax || 100} color={metric.color} reverse={metric.reverse} />
                      )}
                    </div>
                  );
                })}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
