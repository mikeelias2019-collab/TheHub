import React, { useState } from 'react';
import { 
  MapPin, 
  Database, 
  Key, 
  CheckCircle, 
  ExternalLink, 
  Copy, 
  AlertCircle,
  Code,
  Globe,
  Settings
} from 'lucide-react';

export const SetupGuide: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'mls' | 'maps' | 'deployment'>('overview');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const mlsProviders = [
    {
      name: 'California Regional MLS (CRMLS)',
      region: 'Southern California',
      website: 'https://crmls.org',
      apiDocs: 'https://crmls.org/developer',
      requirements: [
        'Active MLS membership',
        'RETS or Web API access agreement',
        'Data licensing fee (~$500-2000/month)',
        'Compliance with data display rules'
      ],
      setup: [
        'Contact CRMLS for developer access',
        'Complete data licensing agreement',
        'Obtain API credentials',
        'Implement RETS or REST API integration'
      ]
    },
    {
      name: 'Bay East Association of Realtors (BEAR)',
      region: 'San Francisco Bay Area',
      website: 'https://bayeast.org',
      requirements: [
        'MLS membership in Bay Area',
        'Data license agreement',
        'Monthly data fees',
        'Display compliance'
      ],
      setup: [
        'Apply for MLS data access',
        'Sign licensing agreements',
        'Get API credentials',
        'Integrate with their data feed'
      ]
    },
    {
      name: 'Houston Association of Realtors (HAR)',
      region: 'Houston, Texas',
      website: 'https://har.com',
      requirements: [
        'HAR MLS membership',
        'API access approval',
        'Data usage compliance',
        'Monthly subscription fees'
      ],
      setup: [
        'Contact HAR for API access',
        'Complete application process',
        'Receive API documentation',
        'Implement data integration'
      ]
    }
  ];

  const mapProviders = [
    {
      name: 'Google Maps Platform',
      pricing: '$7 per 1,000 map loads',
      features: ['Street View', 'Places API', 'Geocoding', 'Directions'],
      setup: [
        'Create Google Cloud Platform account',
        'Enable Maps JavaScript API',
        'Generate API key',
        'Set up billing account',
        'Configure API restrictions'
      ],
      code: `// Google Maps Integration
import { mapService } from './services/mapService';

// Initialize Google Maps
mapService.initialize({
  provider: 'google',
  apiKey: 'YOUR_GOOGLE_MAPS_API_KEY'
});

// Create map
const map = mapService.createMap('map-container', {
  lat: 37.7749,
  lng: -122.4194
}, 12);`
    },
    {
      name: 'Mapbox',
      pricing: 'Free up to 50,000 loads/month',
      features: ['Custom styling', 'Vector tiles', 'Navigation', 'Geocoding'],
      setup: [
        'Create Mapbox account',
        'Get access token',
        'Choose map style',
        'Configure usage limits'
      ],
      code: `// Mapbox Integration
import { mapService } from './services/mapService';

// Initialize Mapbox
mapService.initialize({
  provider: 'mapbox',
  apiKey: 'YOUR_MAPBOX_ACCESS_TOKEN',
  style: 'mapbox://styles/mapbox/streets-v11'
});`
    },
    {
      name: 'Leaflet + OpenStreetMap',
      pricing: 'Free',
      features: ['Open source', 'Lightweight', 'Plugin ecosystem'],
      setup: [
        'No API key required',
        'Include Leaflet library',
        'Choose tile provider',
        'Customize as needed'
      ],
      code: `// Leaflet Integration
import { mapService } from './services/mapService';

// Initialize Leaflet (no API key needed)
mapService.initialize({
  provider: 'leaflet'
});`
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Setup Guide</h1>
          <p className="text-gray-600">
            Complete guide to integrate live MLS data and interactive maps into The Hub
          </p>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-xl shadow-md mb-8">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              <button
                onClick={() => setActiveTab('overview')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'overview'
                    ? 'border-slate-500 text-slate-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Settings className="h-5 w-5 inline mr-2" />
                Platform Overview
              </button>
              <button
                onClick={() => setActiveTab('mls')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'mls'
                    ? 'border-slate-500 text-slate-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Database className="h-5 w-5 inline mr-2" />
                MLS Integration
              </button>
              <button
                onClick={() => setActiveTab('maps')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'maps'
                    ? 'border-slate-500 text-slate-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <MapPin className="h-5 w-5 inline mr-2" />
                Map Integration
              </button>
              <button
                onClick={() => setActiveTab('deployment')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'deployment'
                    ? 'border-slate-500 text-slate-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Globe className="h-5 w-5 inline mr-2" />
                Go Live
              </button>
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'overview' && (
              <div>
                <div className="mb-6">
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">The Hub Platform Overview</h2>
                  <p className="text-gray-600">
                    Complete real estate platform architecture and business model
                  </p>
                </div>

                {/* Business Model */}
                <div className="bg-gradient-to-r from-blue-50 to-slate-50 border border-blue-200 rounded-lg p-6 mb-6">
                  <h3 className="text-xl font-semibold text-blue-900 mb-4">💼 Business Model & Revenue Streams</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold text-blue-800 mb-2">Primary Revenue</h4>
                      <ul className="space-y-2 text-blue-700 text-sm">
                        <li className="flex items-start">
                          <span className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                          <span><strong>Transaction Fees:</strong> 2.5-3% per successful transaction</span>
                        </li>
                        <li className="flex items-start">
                          <span className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                          <span><strong>Listing Fees:</strong> $299-499 per property listing</span>
                        </li>
                        <li className="flex items-start">
                          <span className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                          <span><strong>Premium Services:</strong> Professional photography, staging, marketing</span>
                        </li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold text-blue-800 mb-2">Secondary Revenue</h4>
                      <ul className="space-y-2 text-blue-700 text-sm">
                        <li className="flex items-start">
                          <span className="w-2 h-2 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                          <span><strong>Lead Generation:</strong> Qualified buyer/seller leads to agents</span>
                        </li>
                        <li className="flex items-start">
                          <span className="w-2 h-2 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                          <span><strong>Data Analytics:</strong> Market insights and reports</span>
                        </li>
                        <li className="flex items-start">
                          <span className="w-2 h-2 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                          <span><strong>Partner Referrals:</strong> Mortgage, insurance, title companies</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Market Opportunity */}
                <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-lg p-6 mb-6">
                  <h3 className="text-xl font-semibold text-green-900 mb-4">📈 Market Opportunity</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-green-700 mb-2">$2.1T</div>
                      <div className="text-green-600 text-sm">US Real Estate Market Size</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-green-700 mb-2">6M+</div>
                      <div className="text-green-600 text-sm">Home Sales Annually</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-green-700 mb-2">$60B</div>
                      <div className="text-green-600 text-sm">Real Estate Commissions</div>
                    </div>
                  </div>
                </div>

                {/* Competitive Advantages */}
                <div className="bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-200 rounded-lg p-6 mb-6">
                  <h3 className="text-xl font-semibold text-purple-900 mb-4">🚀 Competitive Advantages</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold text-purple-800 mb-3">vs. Zillow</h4>
                      <ul className="space-y-2 text-purple-700 text-sm">
                        <li>✅ Direct transaction management (not just lead gen)</li>
                        <li>✅ Built-in coordination system</li>
                        <li>✅ No iBuying risk or inventory costs</li>
                        <li>✅ Transparent pricing and process</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold text-purple-800 mb-3">vs. Redfin</h4>
                      <ul className="space-y-2 text-purple-700 text-sm">
                        <li>✅ No agent employment costs</li>
                        <li>✅ Works with any brokerage</li>
                        <li>✅ Simpler user experience</li>
                        <li>✅ Technology-first approach</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Technical Architecture */}
                <div className="border border-gray-200 rounded-lg p-6 mb-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">🏗️ Technical Architecture</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-2">Frontend</h4>
                      <ul className="text-sm text-gray-600 space-y-1">
                        <li>• React + TypeScript</li>
                        <li>• Tailwind CSS</li>
                        <li>• Responsive design</li>
                        <li>• PWA capabilities</li>
                      </ul>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-2">Backend</h4>
                      <ul className="text-sm text-gray-600 space-y-1">
                        <li>• Node.js APIs</li>
                        <li>• PostgreSQL database</li>
                        <li>• Real-time messaging</li>
                        <li>• File storage</li>
                      </ul>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-2">Integrations</h4>
                      <ul className="text-sm text-gray-600 space-y-1">
                        <li>• MLS data feeds</li>
                        <li>• Google/Mapbox maps</li>
                        <li>• Payment processing</li>
                        <li>• Document management</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Implementation Roadmap */}
                <div className="border border-gray-200 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">🗓️ Implementation Roadmap</h3>
                  <div className="space-y-4">
                    <div className="flex items-start space-x-4">
                      <div className="bg-blue-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold">1</div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Phase 1: MVP Launch (Month 1-2)</h4>
                        <p className="text-gray-600 text-sm">Basic property listings, search, and contact forms</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-4">
                      <div className="bg-green-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold">2</div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Phase 2: Live Data (Month 2-3)</h4>
                        <p className="text-gray-600 text-sm">MLS integration, interactive maps, real-time updates</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-4">
                      <div className="bg-purple-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold">3</div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Phase 3: Transactions (Month 3-4)</h4>
                        <p className="text-gray-600 text-sm">Transaction chat, coordination system, payments</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-4">
                      <div className="bg-orange-600 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold">4</div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Phase 4: Scale (Month 4-6)</h4>
                        <p className="text-gray-600 text-sm">Multi-market expansion, advanced analytics, mobile app</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'mls' && (
              <div>
                <div className="mb-6">
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">MLS Data Integration</h2>
                  <p className="text-gray-600">
                    Connect to Multiple Listing Services to get real-time property data
                  </p>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                  <div className="flex items-start">
                    <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5 mr-3" />
                    <div>
                      <h3 className="font-semibold text-blue-900">Important Requirements</h3>
                      <p className="text-blue-800 text-sm mt-1">
                        MLS access requires active real estate licensing and membership. Each MLS has different requirements and fees.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="space-y-6">
                  {mlsProviders.map((provider, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">{provider.name}</h3>
                          <p className="text-gray-600">{provider.region}</p>
                        </div>
                        <div className="flex space-x-2">
                          <a
                            href={provider.website}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm"
                          >
                            <ExternalLink className="h-4 w-4 mr-1" />
                            Website
                          </a>
                          {provider.apiDocs && (
                            <a
                              href={provider.apiDocs}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center px-3 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors text-sm"
                            >
                              <Code className="h-4 w-4 mr-1" />
                              API Docs
                            </a>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <h4 className="font-medium text-gray-900 mb-2">Requirements</h4>
                          <ul className="space-y-1">
                            {provider.requirements.map((req, reqIndex) => (
                              <li key={reqIndex} className="flex items-start text-sm text-gray-600">
                                <CheckCircle className="h-4 w-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                                {req}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div>
                          <h4 className="font-medium text-gray-900 mb-2">Setup Steps</h4>
                          <ol className="space-y-1">
                            {provider.setup.map((step, stepIndex) => (
                              <li key={stepIndex} className="flex items-start text-sm text-gray-600">
                                <span className="bg-slate-100 text-slate-700 rounded-full w-5 h-5 flex items-center justify-center text-xs font-medium mr-2 mt-0.5 flex-shrink-0">
                                  {stepIndex + 1}
                                </span>
                                {step}
                              </li>
                            ))}
                          </ol>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-8 bg-gray-50 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Integration Code Example</h3>
                  <div className="bg-gray-900 rounded-lg p-4 relative">
                    <button
                      onClick={() => copyToClipboard(`// MLS Service Integration
import { mlsService } from './services/mlsService';

// Configure MLS provider
mlsService.addMLSConfig('california', {
  apiKey: 'YOUR_MLS_API_KEY',
  baseUrl: 'https://api.crmls.org',
  region: 'southern-california'
});

// Fetch properties
const properties = await mlsService.fetchProperties('california', {
  minPrice: 500000,
  maxPrice: 1000000,
  bedrooms: 3,
  city: 'Los Angeles'
});`, 'MLS Integration Code')}
                      className="absolute top-2 right-2 p-2 text-gray-400 hover:text-white"
                    >
                      <Copy className="h-4 w-4" />
                    </button>
                    <pre className="text-green-400 text-sm overflow-x-auto">
{`// MLS Service Integration
import { mlsService } from './services/mlsService';

// Configure MLS provider
mlsService.addMLSConfig('california', {
  apiKey: 'YOUR_MLS_API_KEY',
  baseUrl: 'https://api.crmls.org',
  region: 'southern-california'
});

// Fetch properties
const properties = await mlsService.fetchProperties('california', {
  minPrice: 500000,
  maxPrice: 1000000,
  bedrooms: 3,
  city: 'Los Angeles'
});`}
                    </pre>
                  </div>
                  {copiedText === 'MLS Integration Code' && (
                    <div className="mt-2 text-sm text-green-600">Code copied to clipboard!</div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'maps' && (
              <div>
                <div className="mb-6">
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">Interactive Map Integration</h2>
                  <p className="text-gray-600">
                    Choose and integrate a mapping provider for property visualization
                  </p>
                </div>

                <div className="space-y-6">
                  {mapProviders.map((provider, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">{provider.name}</h3>
                          <p className="text-gray-600">{provider.pricing}</p>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {provider.features.map((feature, featureIndex) => (
                            <span
                              key={featureIndex}
                              className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs"
                            >
                              {feature}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="mb-4">
                        <h4 className="font-medium text-gray-900 mb-2">Setup Steps</h4>
                        <ol className="space-y-1">
                          {provider.setup.map((step, stepIndex) => (
                            <li key={stepIndex} className="flex items-start text-sm text-gray-600">
                              <span className="bg-slate-100 text-slate-700 rounded-full w-5 h-5 flex items-center justify-center text-xs font-medium mr-2 mt-0.5 flex-shrink-0">
                                {stepIndex + 1}
                              </span>
                              {step}
                            </li>
                          ))}
                        </ol>
                      </div>

                      <div className="bg-gray-900 rounded-lg p-4 relative">
                        <button
                          onClick={() => copyToClipboard(provider.code, `${provider.name} Code`)}
                          className="absolute top-2 right-2 p-2 text-gray-400 hover:text-white"
                        >
                          <Copy className="h-4 w-4" />
                        </button>
                        <pre className="text-green-400 text-sm overflow-x-auto">
                          {provider.code}
                        </pre>
                      </div>
                      {copiedText === `${provider.name} Code` && (
                        <div className="mt-2 text-sm text-green-600">Code copied to clipboard!</div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'deployment' && (
              <div>
                <div className="mb-6">
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">Going Live</h2>
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
                    <h3 className="font-semibold text-green-900 mb-2">🚀 Quick Start Guide</h3>
                    <p className="text-green-800 text-sm">
                      Follow these steps to activate live maps and MLS data in your platform.
                    </p>
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="border border-gray-200 rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Step 1: Create Your .env File</h3>
                    <p className="text-gray-600 mb-4">Create a <code className="bg-gray-100 px-2 py-1 rounded">.env</code> file in your project root and add your API keys:</p>
                    
                    <div className="bg-gray-900 rounded-lg p-4 relative">
                      <button
                        onClick={() => copyToClipboard(`# Copy .env.example to .env and add your API keys

# For Google Maps (Recommended)
VITE_GOOGLE_MAPS_API_KEY=your_google_maps_api_key_here

# OR for Mapbox (Free tier available)
VITE_MAPBOX_ACCESS_TOKEN=your_mapbox_access_token_here

# MLS API Keys (contact MLS providers)
VITE_CRMLS_API_KEY=your_crmls_api_key_here
VITE_BEAR_API_KEY=your_bear_api_key_here
VITE_HAR_API_KEY=your_har_api_key_here`, 'Environment Setup')}
                        className="absolute top-2 right-2 p-2 text-gray-400 hover:text-white"
                      >
                        <Copy className="h-4 w-4" />
                      </button>
                      <pre className="text-green-400 text-sm overflow-x-auto">
{`# Copy .env.example to .env and add your API keys

# For Google Maps (Recommended)
VITE_GOOGLE_MAPS_API_KEY=your_google_maps_api_key_here

# OR for Mapbox (Free tier available)
VITE_MAPBOX_ACCESS_TOKEN=your_mapbox_access_token_here

# MLS API Keys (contact MLS providers)
VITE_CRMLS_API_KEY=your_crmls_api_key_here
VITE_BEAR_API_KEY=your_bear_api_key_here
VITE_HAR_API_KEY=your_har_api_key_here`}
                      </pre>
                    </div>
                    {copiedText === 'Environment Setup' && (
                      <div className="mt-2 text-sm text-green-600">Environment setup copied!</div>
                    )}
                  </div>

                  <div className="border border-gray-200 rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Step 2: Get API Keys</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <h4 className="font-semibold text-blue-900 mb-2">🗺️ Google Maps (Recommended)</h4>
                        <ol className="text-blue-800 text-sm space-y-1">
                          <li>1. Go to <a href="https://console.cloud.google.com" target="_blank" className="underline">Google Cloud Console</a></li>
                          <li>2. Create new project or select existing</li>
                          <li>3. Enable "Maps JavaScript API"</li>
                          <li>4. Create credentials → API Key</li>
                          <li>5. Restrict key to your domain</li>
                        </ol>
                        <div className="mt-2 text-xs text-blue-600">
                          💰 Pricing: $7 per 1,000 map loads
                        </div>
                      </div>
                      <div className="bg-green-50 p-4 rounded-lg">
                        <h4 className="font-semibold text-green-900 mb-2">🗺️ Mapbox (Free Option)</h4>
                        <ol className="text-green-800 text-sm space-y-1">
                          <li>1. Go to <a href="https://account.mapbox.com" target="_blank" className="underline">Mapbox Account</a></li>
                          <li>2. Sign up for free account</li>
                          <li>3. Go to Access Tokens</li>
                          <li>4. Copy your default public token</li>
                          <li>5. Add to VITE_MAPBOX_ACCESS_TOKEN</li>
                        </ol>
                        <div className="mt-2 text-xs text-green-600">
                          💰 Free: Up to 50,000 loads/month
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Step 3: Test Locally</h3>
                    <p className="text-gray-600 mb-4">After adding API keys, restart your development server:</p>
                    
                    <div className="bg-gray-900 rounded-lg p-4 relative">
                      <button
                        onClick={() => copyToClipboard(`# Stop the development server (Ctrl+C)
# Then restart it
npm run dev

# Check browser console for API status
# You should see: "🏠 The Hub - API Services Status"`, 'Local Testing')}
                        className="absolute top-2 right-2 p-2 text-gray-400 hover:text-white"
                      >
                        <Copy className="h-4 w-4" />
                      </button>
                      <pre className="text-green-400 text-sm overflow-x-auto">
{`# Stop the development server (Ctrl+C)
# Then restart it
npm run dev

# Check browser console for API status
# You should see: "🏠 The Hub - API Services Status"`}
                      </pre>
                    </div>
                    {copiedText === 'Local Testing' && (
                      <div className="mt-2 text-sm text-green-600">Testing commands copied!</div>
                    )}
                    
                    <div className="mt-4 bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                      <p className="text-yellow-800 text-sm">
                        <strong>💡 Pro Tip:</strong> Open browser console (F12) to see which services are active. 
                        The app will show "Live Map Active\" when API keys are working!
                      </p>
                    </div>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Step 4: Deploy to Production</h3>
                    <p className="text-gray-600 mb-4">Add your environment variables to your hosting platform:</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h4 className="font-semibold text-gray-900 mb-2">Netlify</h4>
                        <p className="text-sm text-gray-600 mb-2">Site settings → Environment variables</p>
                        <div className="text-xs text-gray-500">
                          ✅ Current platform<br/>
                          ❌ Frontend only (no MLS backend)
                        </div>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h4 className="font-semibold text-gray-900 mb-2">Vercel</h4>
                        <p className="text-sm text-gray-600 mb-2">Project settings → Environment Variables</p>
                        <div className="text-xs text-gray-500">
                          ✅ Frontend + API routes<br/>
                          ✅ Perfect for MLS integration
                        </div>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h4 className="font-semibold text-gray-900 mb-2">Railway/Render</h4>
                        <p className="text-sm text-gray-600 mb-2">Environment tab</p>
                        <div className="text-xs text-gray-500">
                          ✅ Full backend support<br/>
                          ✅ Database included
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Step 5: Database Setup (Optional)</h3>
                    <p className="text-gray-600 mb-4">Your app needs a database to store:</p>
                    <ul className="space-y-2 mb-4">
                      <li className="flex items-center text-sm text-gray-600">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        User accounts and preferences
                      </li>
                      <li className="flex items-center text-sm text-gray-600">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        Saved properties and searches
                      </li>
                      <li className="flex items-center text-sm text-gray-600">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        Transaction chat messages
                      </li>
                      <li className="flex items-center text-sm text-gray-600">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        Property listings (if not using live MLS)
                      </li>
                    </ul>
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <p className="text-blue-800 text-sm">
                        <strong>Recommendation:</strong> Use Supabase for easy setup with built-in authentication, real-time features, and PostgreSQL database.
                      </p>
                    </div>
                  </div>

                  <div className="border border-gray-200 rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Step 6: Legal Considerations</h3>
                    <div className="space-y-3">
                      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                        <h4 className="font-semibold text-yellow-900 mb-2">MLS Data Usage</h4>
                        <ul className="text-yellow-800 text-sm space-y-1">
                          <li>• Must comply with MLS data display rules</li>
                          <li>• Include required disclaimers and attribution</li>
                          <li>• Respect data refresh requirements</li>
                          <li>• Maintain active MLS membership</li>
                        </ul>
                      </div>
                      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                        <h4 className="font-semibold text-red-900 mb-2">Real Estate Licensing</h4>
                        <ul className="text-red-800 text-sm space-y-1">
                          <li>• May need real estate license to access MLS</li>
                          <li>• Consider partnering with licensed brokers</li>
                          <li>• Understand state-specific regulations</li>
                          <li>• Consult with real estate attorney</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};