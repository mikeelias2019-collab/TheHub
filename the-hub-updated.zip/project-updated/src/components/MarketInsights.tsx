import React from 'react';
import { TrendingUp, TrendingDown, Home, DollarSign, Calendar, MapPin } from 'lucide-react';

interface MarketData {
  location: string;
  medianPrice: number;
  priceChange: number;
  daysOnMarket: number;
  inventory: number;
  soldLastMonth: number;
}

const mockMarketData: MarketData[] = [
  {
    location: 'Pleasant Valley, CA',
    medianPrice: 725000,
    priceChange: 5.2,
    daysOnMarket: 18,
    inventory: 45,
    soldLastMonth: 23
  },
  {
    location: 'Metro City, NY',
    medianPrice: 1200000,
    priceChange: -2.1,
    daysOnMarket: 32,
    inventory: 78,
    soldLastMonth: 41
  },
  {
    location: 'Green Hills, TX',
    medianPrice: 545000,
    priceChange: 8.7,
    daysOnMarket: 12,
    inventory: 67,
    soldLastMonth: 56
  }
];

export const MarketInsights: React.FC = () => {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Market Insights</h1>
          <p className="text-gray-600">
            Real-time market data and trends to help you make informed decisions
          </p>
        </div>

        {/* Market Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {mockMarketData.map((market, index) => (
            <div key={index} className="bg-white rounded-xl shadow-md p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">{market.location}</h3>
                <MapPin className="h-5 w-5 text-gray-400" />
              </div>
              
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Median Price</span>
                    <span className="text-xl font-bold text-gray-900">
                      {formatPrice(market.medianPrice)}
                    </span>
                  </div>
                  <div className="flex items-center mt-1">
                    {market.priceChange > 0 ? (
                      <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                    ) : (
                      <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                    )}
                    <span className={`text-sm ${
                      market.priceChange > 0 ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {market.priceChange > 0 ? '+' : ''}{market.priceChange}% vs last month
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 text-gray-400 mr-2" />
                      <span className="text-sm text-gray-600">Days on Market</span>
                    </div>
                    <span className="text-lg font-semibold text-gray-900">{market.daysOnMarket}</span>
                  </div>
                  <div>
                    <div className="flex items-center">
                      <Home className="h-4 w-4 text-gray-400 mr-2" />
                      <span className="text-sm text-gray-600">Inventory</span>
                    </div>
                    <span className="text-lg font-semibold text-gray-900">{market.inventory}</span>
                  </div>
                </div>

                <div className="pt-4 border-t border-gray-100">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Sold Last Month</span>
                    <span className="text-lg font-semibold text-blue-600">{market.soldLastMonth}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Market Trends Chart Placeholder */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">Price Trends</h3>
          <div className="h-64 bg-gray-100 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <TrendingUp className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">Interactive price trend charts coming soon</p>
            </div>
          </div>
        </div>

        {/* Market Analysis */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Market Analysis</h3>
            <div className="space-y-4">
              <div className="p-4 bg-green-50 rounded-lg">
                <h4 className="font-semibold text-green-900 mb-2">🔥 Hot Markets</h4>
                <p className="text-green-800 text-sm">
                  Green Hills, TX showing strong growth with 8.7% price increase and only 12 days on market.
                </p>
              </div>
              <div className="p-4 bg-blue-50 rounded-lg">
                <h4 className="font-semibold text-blue-900 mb-2">📊 Market Insights</h4>
                <p className="text-blue-800 text-sm">
                  Pleasant Valley maintains steady growth while Metro City shows cooling with slight price decline.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Investment Opportunities</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h4 className="font-semibold text-gray-900">First-Time Buyers</h4>
                  <p className="text-sm text-gray-600">Best markets for entry-level homes</p>
                </div>
                <DollarSign className="h-8 w-8 text-green-500" />
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h4 className="font-semibold text-gray-900">Investment Properties</h4>
                  <p className="text-sm text-gray-600">High rental yield opportunities</p>
                </div>
                <TrendingUp className="h-8 w-8 text-blue-500" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};