import React, { useState, useMemo } from 'react';
import { PropertyCard } from './PropertyCard';
import { mockProperties } from '../data/mockData';
import { Property, SearchFilters } from '../types';
import { getAvailableServices } from '../config/apiKeys';
import { mlsService } from '../services/mlsService';
import { Search, Filter, SlidersHorizontal, Grid3X3, List, MapPin, Heart, Bell, TrendingUp, Star, Calendar, DollarSign } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ScheduleShowing } from './ScheduleShowing';
import { PriceAlertModal } from './PriceAlertModal';
import { MortgageCalculator } from './MortgageCalculator';
import { AIPropertyChat } from './AIPropertyChat';

export const PropertyListings: React.FC = () => {
  const { toggleSaved, isSaved } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [showingProperty, setShowingProperty] = useState<Property | null>(null);
  const [alertProperty, setAlertProperty] = useState<Property | null>(null);
  const [mortgageProperty, setMortgageProperty] = useState<Property | null>(null);
  const [chatProperty, setChatProperty] = useState<Property | null>(null);
  const [showChatPanel, setShowChatPanel] = useState(false);
  const [isLoadingMLS, setIsLoadingMLS] = useState(false);
  const [mlsProperties, setMlsProperties] = useState<Property[]>([]);
  
  const [filters, setFilters] = useState<SearchFilters>({
    location: '',
    minPrice: 0,
    maxPrice: 2000000,
    bedrooms: 0,
    bathrooms: 0,
    propertyType: 'all',
    listingType: 'sale',
    keywords: '',
    openHouse: false,
    newListings: false,
    priceReduced: false,
    hasVirtualTour: false,
    hasPhotos: false,
    sortBy: 'newest'
  });

  // Check available services
  const services = getAvailableServices();

  // Load MLS properties if available
  useEffect(() => {
    const loadMLSProperties = async () => {
      if (services.mls.hasAnyMLS && mlsService.isConfigured()) {
        setIsLoadingMLS(true);
        try {
          const regions = mlsService.getAvailableRegions();
          const allProperties: Property[] = [];
          
          for (const region of regions) {
            const mlsData = await mlsService.fetchProperties(region, {
              limit: 50 // Limit per region
            });
            
            // Convert MLS data to Property format (simplified conversion)
            const convertedProperties = mlsData.map(mls => ({
              id: mls.mlsNumber,
              title: `${mls.bedrooms} bed, ${mls.bathrooms} bath ${mls.propertyType}`,
              price: mls.listPrice,
              address: mls.address,
              city: mls.city,
              state: mls.state,
              zipCode: mls.zipCode,
              bedrooms: mls.bedrooms,
              bathrooms: mls.bathrooms,
              squareFeet: mls.squareFeet,
              propertyType: mls.propertyType.toLowerCase().replace(' ', '') as any,
              listingType: 'sale' as const,
              images: mls.photos.length > 0 ? mls.photos : [mockProperties[0].images[0]],
              description: mls.description,
              yearBuilt: mls.yearBuilt,
              lotSize: mls.lotSize,
              features: mls.features,
              listingDate: mls.listingDate,
              daysOnMarket: mls.daysOnMarket,
              status: mls.status.toLowerCase() as any,
              virtualTour: mls.virtualTour,
              agent: {
                name: mls.listingAgent.name,
                phone: mls.listingAgent.phone,
                email: mls.listingAgent.email,
                brokerage: mls.listingAgent.brokerage,
                licenseNumber: mls.listingAgent.mlsId,
                photo: mockProperties[0].agent.photo, // Fallback
                rating: 4.5, // Default
                reviewCount: 25 // Default
              },
              coordinates: {
                lat: mls.coordinates.latitude,
                lng: mls.coordinates.longitude
              },
              viewCount: Math.floor(Math.random() * 200) + 50,
              nearbyAmenities: [],
              marketTrends: mockProperties[0].marketTrends,
              propertyTax: Math.floor(mls.listPrice * 0.0125),
              heating: 'Central',
              cooling: 'Central Air',
              appliances: ['Dishwasher', 'Refrigerator']
            }));
            
            allProperties.push(...convertedProperties);
          }
          
          setMlsProperties(allProperties);
        } catch (error) {
          console.error('Error loading MLS properties:', error);
        } finally {
          setIsLoadingMLS(false);
        }
      }
    };

    loadMLSProperties();
  }, [services.mls.hasAnyMLS]);

  // Combine mock and MLS properties
  const allProperties = [...mockProperties, ...mlsProperties];

  const filteredProperties = useMemo(() => {
    let filtered = allProperties.filter(property => {
      const matchesSearch = !searchQuery || 
        property.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        property.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
        property.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
        property.state.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesLocation = !filters.location || 
        property.city.toLowerCase().includes(filters.location.toLowerCase()) ||
        property.state.toLowerCase().includes(filters.location.toLowerCase());

      const matchesPrice = property.price >= filters.minPrice && property.price <= filters.maxPrice;
      const matchesBedrooms = filters.bedrooms === 0 || property.bedrooms >= filters.bedrooms;
      const matchesBathrooms = filters.bathrooms === 0 || property.bathrooms >= filters.bathrooms;
      const matchesType = filters.propertyType === 'all' || property.propertyType === filters.propertyType;
      const matchesListingType = property.listingType === filters.listingType;
      const matchesKeywords = !filters.keywords || 
        property.description.toLowerCase().includes(filters.keywords.toLowerCase()) ||
        property.features.some(feature => feature.toLowerCase().includes(filters.keywords.toLowerCase()));
      const matchesVirtualTour = !filters.hasVirtualTour || property.virtualTour;
      const matchesPhotos = !filters.hasPhotos || property.images.length > 0;
      const matchesNewListings = !filters.newListings || property.daysOnMarket <= 7;
      const matchesPriceReduced = !filters.priceReduced || (property.priceHistory && property.priceHistory.length > 1);

      return matchesSearch && matchesLocation && matchesPrice && 
             matchesBedrooms && matchesBathrooms && matchesType && matchesListingType &&
             matchesKeywords && matchesVirtualTour && matchesPhotos && matchesNewListings && matchesPriceReduced;
    });
    
    // Sort properties
    filtered.sort((a, b) => {
      switch (filters.sortBy) {
        case 'price_low':
          return a.price - b.price;
        case 'price_high':
          return b.price - a.price;
        case 'beds':
          return b.bedrooms - a.bedrooms;
        case 'baths':
          return b.bathrooms - a.bathrooms;
        case 'sqft':
          return b.squareFeet - a.squareFeet;
        case 'lot_size':
          return (b.lotSize || 0) - (a.lotSize || 0);
        case 'newest':
        default:
          return new Date(b.listingDate).getTime() - new Date(a.listingDate).getTime();
      }
    });
    
    return filtered;
  }, [searchQuery, filters, allProperties]);

  const handlePropertyClick = (property: Property) => {
    setSelectedProperty(property);
  };

  const handleSaveProperty = (propertyId: string) => {
    toggleSaved(propertyId);
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  if (selectedProperty) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <button
            onClick={() => setSelectedProperty(null)}
            className="mb-6 px-4 py-2 bg-slate-600 text-white rounded-lg hover:bg-slate-700 transition-colors"
          >
            ← Back to Listings
          </button>
          
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Images */}
              <div className="space-y-4">
                <img
                  src={selectedProperty.images[0]}
                  alt={selectedProperty.title}
                  className="w-full h-96 object-cover rounded-lg"
                />
                <div className="grid grid-cols-2 gap-2">
                  {selectedProperty.images.slice(1).map((image, index) => (
                    <img
                      key={index}
                      src={image}
                      alt={`Property ${index + 2}`}
                      className="w-full h-32 object-cover rounded-lg"
                    />
                  ))}
                </div>
              </div>

              {/* Details */}
              <div className="p-8">
                <div className="mb-4">
                  <span className="text-3xl font-bold text-gray-900">
                    {formatPrice(selectedProperty.price)}
                  </span>
                  {selectedProperty.listingType === 'rent' && (
                    <span className="text-gray-600">/month</span>
                  )}
                </div>

                <h1 className="text-2xl font-bold text-gray-900 mb-4">
                  {selectedProperty.title}
                </h1>

                <p className="text-gray-600 mb-6">
                  {selectedProperty.address}, {selectedProperty.city}, {selectedProperty.state} {selectedProperty.zipCode}
                </p>

                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="text-2xl font-bold text-gray-900">{selectedProperty.bedrooms}</div>
                    <div className="text-gray-600">Bedrooms</div>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="text-2xl font-bold text-gray-900">{selectedProperty.bathrooms}</div>
                    <div className="text-gray-600">Bathrooms</div>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="text-2xl font-bold text-gray-900">{selectedProperty.squareFeet.toLocaleString()}</div>
                    <div className="text-gray-600">Square Feet</div>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="text-2xl font-bold text-gray-900">{selectedProperty.yearBuilt}</div>
                    <div className="text-gray-600">Year Built</div>
                  </div>
                </div>

                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Description</h3>
                  <p className="text-gray-700">{selectedProperty.description}</p>
                </div>

                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Features</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedProperty.features.map((feature, index) => (
                      <span
                        key={index}
                        className="bg-slate-100 text-slate-800 px-3 py-1 rounded-full text-sm"
                      >
                        {feature}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="border-t pt-6">
                  {/* Quick Action Buttons */}
                  <div className="grid grid-cols-2 gap-3 mb-6">
                    <button
                      onClick={() => { setSelectedProperty(null); setShowingProperty(selectedProperty); }}
                      className="flex items-center justify-center gap-2 py-3 bg-slate-700 text-white rounded-xl font-semibold hover:bg-slate-800 transition-colors"
                    >
                      <Calendar className="h-4 w-4" /> Schedule Showing
                    </button>
                    <button
                      onClick={() => { setSelectedProperty(null); setAlertProperty(selectedProperty); }}
                      className="flex items-center justify-center gap-2 py-3 bg-amber-500 text-white rounded-xl font-semibold hover:bg-amber-600 transition-colors"
                    >
                      <Bell className="h-4 w-4" /> Price Alert
                    </button>
                    <button
                      onClick={() => { setSelectedProperty(null); setMortgageProperty(selectedProperty); }}
                      className="flex items-center justify-center gap-2 py-3 bg-emerald-600 text-white rounded-xl font-semibold hover:bg-emerald-700 transition-colors"
                    >
                      <DollarSign className="h-4 w-4" /> Mortgage Calc
                    </button>
                    <button
                      onClick={() => toggleSaved(selectedProperty.id)}
                      className={`flex items-center justify-center gap-2 py-3 rounded-xl font-semibold transition-colors ${
                        isSaved(selectedProperty.id)
                          ? 'bg-red-500 text-white hover:bg-red-600'
                          : 'bg-red-50 text-red-600 border border-red-200 hover:bg-red-100'
                      }`}
                    >
                      <Heart className={`h-4 w-4 ${isSaved(selectedProperty.id) ? 'fill-current' : ''}`} />
                      {isSaved(selectedProperty.id) ? 'Saved' : 'Save Home'}
                    </button>
                  </div>

                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Contact Agent</h3>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="font-semibold text-gray-900">{selectedProperty.agent.name}</p>
                    <p className="text-gray-600">{selectedProperty.agent.phone}</p>
                    <p className="text-gray-600">{selectedProperty.agent.email}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Property Listings</h1>
              <div className="flex items-center space-x-4">
                <p className="text-gray-600">
                  Found {filteredProperties.length} properties
                </p>
                {services.mls.hasAnyMLS && (
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    <span className="text-sm text-green-600 font-medium">Live MLS Data</span>
                  </div>
                )}
                {isLoadingMLS && (
                  <div className="flex items-center">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600 mr-2"></div>
                    <span className="text-sm text-blue-600">Loading MLS...</span>
                  </div>
                )}
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                <Bell className="h-4 w-4 mr-2" />
                Save Search
              </button>
              <button className="flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
                <Heart className="h-4 w-4 mr-2" />
                Saved ({savedProperties.length})
              </button>
            </div>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="bg-white p-6 rounded-xl shadow-md mb-8">
          <div className="flex flex-col lg:flex-row gap-4 mb-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Search by location, property type, or keywords..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center px-4 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
              >
                <Filter className="h-5 w-5 mr-2" />
                Filters
              </button>
              <div className="flex bg-gray-100 rounded-lg">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-3 rounded-lg transition-colors ${
                   viewMode === 'grid' ? 'bg-slate-600 text-white' : 'text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  <Grid3X3 className="h-5 w-5" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-3 rounded-lg transition-colors ${
                   viewMode === 'list' ? 'bg-slate-600 text-white' : 'text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  <List className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Advanced Filters */}
          {showFilters && (
            <div className="border-t pt-4">
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Listing Type</label>
                  <select
                    value={filters.listingType}
                    onChange={(e) => setFilters({...filters, listingType: e.target.value as 'sale' | 'rent'})}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  >
                    <option value="sale">For Sale</option>
                    <option value="rent">For Rent</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Property Type</label>
                  <select
                    value={filters.propertyType}
                    onChange={(e) => setFilters({...filters, propertyType: e.target.value})}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  >
                    <option value="all">All Types</option>
                    <option value="house">House</option>
                    <option value="condo">Condo</option>
                    <option value="townhouse">Townhouse</option>
                    <option value="apartment">Apartment</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Min Price</label>
                  <input
                    type="number"
                    value={filters.minPrice}
                    onChange={(e) => setFilters({...filters, minPrice: Number(e.target.value)})}
                    className="w-full p-2 border border-gray-300 rounded-md"
                    placeholder="0"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Max Price</label>
                  <input
                    type="number"
                    value={filters.maxPrice}
                    onChange={(e) => setFilters({...filters, maxPrice: Number(e.target.value)})}
                    className="w-full p-2 border border-gray-300 rounded-md"
                    placeholder="2000000"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Bedrooms</label>
                  <select
                    value={filters.bedrooms}
                    onChange={(e) => setFilters({...filters, bedrooms: Number(e.target.value)})}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  >
                    <option value={0}>Any</option>
                    <option value={1}>1+</option>
                    <option value={2}>2+</option>
                    <option value={3}>3+</option>
                    <option value={4}>4+</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Bathrooms</label>
                  <select
                    value={filters.bathrooms}
                    onChange={(e) => setFilters({...filters, bathrooms: Number(e.target.value)})}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  >
                    <option value={0}>Any</option>
                    <option value={1}>1+</option>
                    <option value={2}>2+</option>
                    <option value={3}>3+</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Keywords</label>
                  <input
                    type="text"
                    value={filters.keywords}
                    onChange={(e) => setFilters({...filters, keywords: e.target.value})}
                    className="w-full p-2 border border-gray-300 rounded-md"
                    placeholder="pool, garage, etc."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Sort By</label>
                  <select
                    value={filters.sortBy}
                    onChange={(e) => setFilters({...filters, sortBy: e.target.value as any})}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  >
                    <option value="newest">Newest</option>
                    <option value="price_low">Price: Low to High</option>
                    <option value="price_high">Price: High to Low</option>
                    <option value="beds">Most Bedrooms</option>
                    <option value="baths">Most Bathrooms</option>
                    <option value="sqft">Largest</option>
                  </select>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-4">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.newListings}
                    onChange={(e) => setFilters({...filters, newListings: e.target.checked})}
                    className="mr-2"
                  />
                  <span className="text-sm text-gray-700">New Listings (7 days)</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.priceReduced}
                    onChange={(e) => setFilters({...filters, priceReduced: e.target.checked})}
                    className="mr-2"
                  />
                  <span className="text-sm text-gray-700">Price Reduced</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.hasVirtualTour}
                    onChange={(e) => setFilters({...filters, hasVirtualTour: e.target.checked})}
                    className="mr-2"
                  />
                  <span className="text-sm text-gray-700">Virtual Tour</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.openHouse}
                    onChange={(e) => setFilters({...filters, openHouse: e.target.checked})}
                    className="mr-2"
                  />
                  <span className="text-sm text-gray-700">Open House</span>
                </label>
              </div>
            </div>
          )}
        </div>

        {/* Property Grid */}
        <div className={`grid gap-6 ${
          viewMode === 'grid' 
            ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' 
            : 'grid-cols-1'
        }`}>
          {filteredProperties.map((property) => (
            <PropertyCard
              key={property.id}
              property={property}
              onClick={() => handlePropertyClick(property)}
              onSave={handleSaveProperty}
              isSaved={isSaved(property.id)}
            />
          ))}
        </div>

        {filteredProperties.length === 0 && (
          <div className="text-center py-12">
            <SlidersHorizontal className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No properties found</h3>
            <p className="text-gray-600">Try adjusting your search criteria or filters</p>
          </div>
        )}
      </div>

      {/* Modals */}
      {showingProperty && <ScheduleShowing property={showingProperty} onClose={() => setShowingProperty(null)} />}
      {alertProperty && <PriceAlertModal property={alertProperty} onClose={() => setAlertProperty(null)} />}
      {mortgageProperty && <MortgageCalculator initialPrice={mortgageProperty.price} onClose={() => setMortgageProperty(null)} />}
    </div>
  );
};