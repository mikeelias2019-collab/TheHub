import React, { useState } from 'react';
import { Calendar, Clock, User, Mail, Phone, MessageSquare, X, CheckCircle, ChevronLeft, ChevronRight } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Property } from '../types';

interface ScheduleShowingProps {
  property: Property;
  onClose: () => void;
}

const TIME_SLOTS = [
  '9:00 AM', '9:30 AM', '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM',
  '12:00 PM', '12:30 PM', '1:00 PM', '1:30 PM', '2:00 PM', '2:30 PM',
  '3:00 PM', '3:30 PM', '4:00 PM', '4:30 PM', '5:00 PM', '5:30 PM',
];

export const ScheduleShowing: React.FC<ScheduleShowingProps> = ({ property, onClose }) => {
  const { addShowing } = useApp();
  const [step, setStep] = useState<'date' | 'form' | 'success'>('date');
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [form, setForm] = useState({ name: '', email: '', phone: '', message: '' });
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    return { firstDay, daysInMonth };
  };

  const { firstDay, daysInMonth } = getDaysInMonth(currentMonth);
  const monthName = currentMonth.toLocaleString('default', { month: 'long', year: 'numeric' });

  const handleDayClick = (day: number) => {
    const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
    if (date < today) return;
    const iso = date.toISOString().split('T')[0];
    setSelectedDate(iso);
    setSelectedTime('');
  };

  const formatSelectedDate = (iso: string) => {
    return new Date(iso + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
  };

  const handleSubmit = () => {
    addShowing({
      propertyId: property.id,
      propertyTitle: property.title,
      propertyAddress: `${property.address}, ${property.city}, ${property.state}`,
      date: formatSelectedDate(selectedDate),
      time: selectedTime,
      name: form.name,
      email: form.email,
      phone: form.phone,
      message: form.message,
    });
    setStep('success');
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-100 bg-gradient-to-r from-slate-700 to-slate-600">
          <div>
            <h2 className="text-xl font-bold text-white">Schedule a Showing</h2>
            <p className="text-slate-300 text-sm mt-0.5 line-clamp-1">{property.address}, {property.city}</p>
          </div>
          <button onClick={onClose} className="p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-full transition-colors">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-6 max-h-[75vh] overflow-y-auto">
          {step === 'date' && (
            <div>
              {/* Calendar */}
              <div className="mb-6">
                <div className="flex items-center justify-between mb-4">
                  <button
                    onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1))}
                    className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
                  >
                    <ChevronLeft className="h-4 w-4 text-slate-600" />
                  </button>
                  <span className="font-semibold text-slate-800">{monthName}</span>
                  <button
                    onClick={() => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1))}
                    className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
                  >
                    <ChevronRight className="h-4 w-4 text-slate-600" />
                  </button>
                </div>
                <div className="grid grid-cols-7 gap-1 mb-2">
                  {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map(d => (
                    <div key={d} className="text-center text-xs font-medium text-slate-400 py-1">{d}</div>
                  ))}
                </div>
                <div className="grid grid-cols-7 gap-1">
                  {Array.from({ length: firstDay }).map((_, i) => <div key={`e-${i}`} />)}
                  {Array.from({ length: daysInMonth }).map((_, i) => {
                    const day = i + 1;
                    const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
                    const iso = date.toISOString().split('T')[0];
                    const isPast = date < today;
                    const isSelected = selectedDate === iso;
                    const isWeekend = date.getDay() === 0 || date.getDay() === 6;
                    return (
                      <button
                        key={day}
                        onClick={() => handleDayClick(day)}
                        disabled={isPast}
                        className={`aspect-square flex items-center justify-center rounded-lg text-sm font-medium transition-all ${
                          isSelected ? 'bg-slate-700 text-white' :
                          isPast ? 'text-slate-300 cursor-not-allowed' :
                          isWeekend ? 'text-slate-400 hover:bg-slate-100' :
                          'text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        {day}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Time Slots */}
              {selectedDate && (
                <div>
                  <h3 className="font-semibold text-slate-800 mb-3">
                    Available times for {formatSelectedDate(selectedDate)}
                  </h3>
                  <div className="grid grid-cols-3 gap-2">
                    {TIME_SLOTS.map(time => (
                      <button
                        key={time}
                        onClick={() => setSelectedTime(time)}
                        className={`py-2 px-3 rounded-xl text-sm font-medium transition-all ${
                          selectedTime === time
                            ? 'bg-slate-700 text-white'
                            : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200'
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <button
                onClick={() => setStep('form')}
                disabled={!selectedDate || !selectedTime}
                className="w-full mt-6 py-3 bg-slate-700 text-white rounded-2xl font-semibold hover:bg-slate-800 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Continue
              </button>
            </div>
          )}

          {step === 'form' && (
            <div>
              <button onClick={() => setStep('date')} className="flex items-center text-slate-500 hover:text-slate-700 text-sm mb-4 gap-1">
                <ChevronLeft className="h-4 w-4" /> Change date/time
              </button>

              <div className="bg-slate-50 rounded-2xl p-4 mb-6 flex items-center gap-3">
                <Calendar className="h-5 w-5 text-slate-500" />
                <div>
                  <div className="font-semibold text-slate-800">{formatSelectedDate(selectedDate)}</div>
                  <div className="text-sm text-slate-600">{selectedTime}</div>
                </div>
              </div>

              <div className="space-y-4">
                {[
                  { label: 'Full Name', key: 'name', type: 'text', icon: <User className="h-4 w-4" />, placeholder: 'Jane Smith' },
                  { label: 'Email', key: 'email', type: 'email', icon: <Mail className="h-4 w-4" />, placeholder: 'jane@example.com' },
                  { label: 'Phone', key: 'phone', type: 'tel', icon: <Phone className="h-4 w-4" />, placeholder: '(555) 123-4567' },
                ].map(field => (
                  <div key={field.key}>
                    <label className="block text-sm font-medium text-slate-700 mb-1">{field.label}</label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">{field.icon}</span>
                      <input
                        type={field.type}
                        value={(form as any)[field.key]}
                        onChange={e => setForm(prev => ({ ...prev, [field.key]: e.target.value }))}
                        placeholder={field.placeholder}
                        className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl bg-slate-50 focus:ring-2 focus:ring-slate-400 focus:border-transparent"
                      />
                    </div>
                  </div>
                ))}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Message (optional)</label>
                  <textarea
                    rows={3}
                    value={form.message}
                    onChange={e => setForm(prev => ({ ...prev, message: e.target.value }))}
                    placeholder="Any questions or special requests?"
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl bg-slate-50 focus:ring-2 focus:ring-slate-400 focus:border-transparent resize-none"
                  />
                </div>
              </div>

              <button
                onClick={handleSubmit}
                disabled={!form.name || !form.email || !form.phone}
                className="w-full mt-6 py-3 bg-slate-700 text-white rounded-2xl font-semibold hover:bg-slate-800 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Confirm Showing
              </button>
            </div>
          )}

          {step === 'success' && (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-2xl font-bold text-slate-800 mb-2">Showing Confirmed!</h3>
              <p className="text-slate-600 mb-1">{formatSelectedDate(selectedDate)} at {selectedTime}</p>
              <p className="text-slate-500 text-sm mb-1">{property.address}, {property.city}</p>
              <p className="text-slate-500 text-sm mb-6">A confirmation will be sent to {form.email}</p>
              <button
                onClick={onClose}
                className="px-8 py-3 bg-slate-700 text-white rounded-2xl font-semibold hover:bg-slate-800 transition-colors"
              >
                Done
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
