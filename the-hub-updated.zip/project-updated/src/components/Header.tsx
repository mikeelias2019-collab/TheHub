import React, { useState } from 'react';
import { Home, Menu, X, ChevronDown, User, Lock, Mail, Phone, MapPin } from 'lucide-react';

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ currentPage, onNavigate }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showBuySellDropdown, setShowBuySellDropdown] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home' }
  ];

  const buySellOptions = [
    { id: 'listings', label: 'Browse Properties', description: 'Search and view available homes' },
    { id: 'buy-with-us', label: 'Buy with The Hub', description: 'Get assigned a coordinator to guide you' },
    { id: 'sell', label: 'Sell Your Home', description: 'List your property for sale' },
    { id: 'saved', label: '❤️ Saved Homes', description: 'View your saved properties' },
    { id: 'neighborhood-comparison', label: '🏘️ Compare Neighborhoods', description: 'Side-by-side neighborhood analysis' },
    { id: 'mortgage-calculator', label: '📊 Mortgage Calculator', description: 'Estimate your monthly payment' },
    { id: 'market-insights', label: '📈 Market Insights', description: 'Trends and market data' },
  ];

  const [showTransactionDropdown, setShowTransactionDropdown] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    fullName: '',
    phone: '',
    mlsListing: '',
    propertyAddress: ''
  });
  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (authMode === 'register') {
      // Validate required fields for registration
      if (!formData.email || !formData.password || !formData.confirmPassword || 
          !formData.fullName || !formData.phone || !formData.mlsListing || !formData.propertyAddress) {
        alert('Please fill in all required fields');
        return;
      }
      if (formData.password !== formData.confirmPassword) {
        alert('Passwords do not match');
        return;
      }
      // In a real app, this would create the account and assign the chat to the property
      alert('Account created successfully! Your transaction chat has been set up for ' + formData.propertyAddress);
    } else {
      // Login validation
      if (!formData.email || !formData.password) {
        alert('Please enter email and password');
        return;
      }
      // In a real app, this would authenticate the user
      alert('Login successful!');
    }
    setShowAuthModal(false);
    onNavigate('chat');
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const resetForm = () => {
    setFormData({
      email: '',
      password: '',
      confirmPassword: '',
      fullName: '',
      phone: '',
      mlsListing: '',
      propertyAddress: ''
    });
  };

  return (
    <>
    <header className="bg-white shadow-lg relative z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div 
            className="flex items-center cursor-pointer hover:opacity-80 transition-opacity"
            onClick={() => onNavigate('home')}
          >
            <Home className="h-8 w-8 text-slate-700 mr-2" />
            <span className="text-2xl font-bold text-gray-900">The Hub</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <button
              onClick={() => onNavigate('home')}
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                currentPage === 'home'
                  ? 'text-slate-700 bg-slate-100'
                  : 'text-gray-700 hover:text-slate-700 hover:bg-gray-50'
              }`}
            >
              Search Homes
            </button>

            {/* Buy or Sell Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowBuySellDropdown(!showBuySellDropdown)}
                className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  currentPage === 'listings' || currentPage === 'sell'
                    ? 'text-slate-700 bg-slate-100'
                    : 'text-gray-700 hover:text-slate-700 hover:bg-gray-50'
                }`}
              >
                Buy or Sell
                <ChevronDown className={`ml-1 h-4 w-4 transition-transform ${
                  showBuySellDropdown ? 'rotate-180' : ''
                }`} />
              </button>

              {/* Dropdown Menu */}
              {showBuySellDropdown && (
                <div className="absolute top-full left-0 mt-1 w-64 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50">
                  {buySellOptions.map((option) => (
                    <button
                      key={option.id}
                      onClick={() => {
                        onNavigate(option.id);
                        setShowBuySellDropdown(false);
                      }}
                      className="w-full text-left px-4 py-3 hover:bg-gray-50 transition-colors"
                    >
                      <div className="font-medium text-gray-900">{option.label}</div>
                      <div className="text-sm text-gray-500">{option.description}</div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <button
              onClick={() => onNavigate('cash-offer')}
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                currentPage === 'cash-offer'
                  ? 'text-slate-700 bg-slate-100'
                  : 'text-gray-700 hover:text-slate-700 hover:bg-gray-50'
              }`}
            >
              Get Cash Offer
            </button>

            <button
              onClick={() => onNavigate('market-insights')}
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                currentPage === 'market-insights'
                  ? 'text-slate-700 bg-slate-100'
                  : 'text-gray-700 hover:text-slate-700 hover:bg-gray-50'
              }`}
            >
              Market Data
            </button>

            <button
              onClick={() => onNavigate('setup-guide')}
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                currentPage === 'setup-guide'
                  ? 'text-slate-700 bg-slate-100'
                  : 'text-gray-700 hover:text-slate-700 hover:bg-gray-50'
              }`}
            >
              Setup Guide
            </button>

            {/* Transaction Chat Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowTransactionDropdown(!showTransactionDropdown)}
                className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  currentPage === 'chat'
                    ? 'text-slate-700 bg-slate-100'
                    : 'text-gray-700 hover:text-slate-700 hover:bg-gray-50'
                }`}
              >
                Transaction Chat
                <ChevronDown className={`ml-1 h-4 w-4 transition-transform ${
                  showTransactionDropdown ? 'rotate-180' : ''
                }`} />
              </button>

              {/* Transaction Chat Dropdown Menu */}
              {showTransactionDropdown && (
                <div className="absolute top-full left-0 mt-1 w-80 bg-white rounded-lg shadow-lg border border-gray-200 py-4 px-4 z-50">
                  <h4 className="font-semibold text-gray-900 mb-2">Transaction Chat</h4>
                  <p className="text-sm text-gray-600 mb-3">
                    Perfect for anyone with a home currently under contract or for sale. Track your entire process and stay organized.
                  </p>
                  <div className="mb-3">
                    <h5 className="font-medium text-gray-800 text-sm mb-1">Invite Key Parties:</h5>
                    <ul className="text-xs text-gray-600 space-y-1">
                      <li>• Loan Officer</li>
                      <li>• Buyer's Agent</li>
                      <li>• Buyers</li>
                      <li>• Title Company</li>
                      <li>• And more...</li>
                    </ul>
                  </div>
                  <p className="text-xs text-gray-500 mb-3">
                    Keep everyone informed and updated throughout the entire transaction process.
                  </p>
                  <button
                    onClick={() => {
                      setShowAuthModal(true);
                      setAuthMode('login');
                      setShowTransactionDropdown(false);
                      resetForm();
                    }}
                    className="w-full bg-slate-700 text-white py-2 px-4 rounded-lg hover:bg-slate-800 transition-colors text-sm"
                  >
                    Start Transaction Chat
                  </button>
                </div>
              )}
            </div>

            <button className="px-4 py-2 bg-slate-700 text-white rounded-md text-sm font-medium hover:bg-slate-800 transition-colors">
              Sign Up Free
            </button>
          </nav>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-700 hover:text-blue-700 transition-colors"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white border-t">
              <button
                onClick={() => {
                  onNavigate('home');
                  setIsMenuOpen(false);
                }}
                className={`block px-3 py-2 rounded-md text-base font-medium w-full text-left transition-colors ${
                  currentPage === 'home'
                    ? 'text-slate-700 bg-slate-100'
                    : 'text-gray-700 hover:text-slate-700 hover:bg-gray-50'
                }`}
              >
                Search Homes
              </button>

              {/* Mobile Buy or Sell Options */}
              <div className="pl-4">
                <div className="text-sm font-medium text-gray-500 px-3 py-1">Buy or Sell</div>
                {buySellOptions.map((option) => (
                  <button
                    key={option.id}
                    onClick={() => {
                      onNavigate(option.id);
                      setIsMenuOpen(false);
                    }}
                    className={`block px-3 py-2 rounded-md text-base font-medium w-full text-left transition-colors ${
                      currentPage === option.id
                        ? 'text-slate-700 bg-slate-100'
                        : 'text-gray-700 hover:text-slate-700 hover:bg-gray-50'
                    }`}
                  >
                    {option.label}
                  </button>
                ))}
              </div>

              <button
                onClick={() => {
                  onNavigate('cash-offer');
                  setIsMenuOpen(false);
                }}
                className={`block px-3 py-2 rounded-md text-base font-medium w-full text-left transition-colors ${
                  currentPage === 'cash-offer'
                    ? 'text-slate-700 bg-slate-100'
                    : 'text-gray-700 hover:text-slate-700 hover:bg-gray-50'
                }`}
              >
                Get Cash Offer
              </button>

              <button
                onClick={() => {
                  onNavigate('market-insights');
                  setIsMenuOpen(false);
                }}
                className={`block px-3 py-2 rounded-md text-base font-medium w-full text-left transition-colors ${
                  currentPage === 'market-insights'
                    ? 'text-slate-700 bg-slate-100'
                    : 'text-gray-700 hover:text-slate-700 hover:bg-gray-50'
                }`}
              >
                Market Data
              </button>

              <button
                onClick={() => {
                  setShowAuthModal(true);
                  setAuthMode('login');
                  setIsMenuOpen(false);
                  resetForm();
                }}
                className={`block px-3 py-2 rounded-md text-base font-medium w-full text-left transition-colors ${
                  currentPage === 'chat'
                    ? 'text-slate-700 bg-slate-100'
                    : 'text-gray-700 hover:text-slate-700 hover:bg-gray-50'
                }`}
              >
                Transaction Chat
              </button>

              <button
                onClick={() => {
                  onNavigate('setup-guide');
                  setIsMenuOpen(false);
                }}
                className={`block px-3 py-2 rounded-md text-base font-medium w-full text-left transition-colors ${
                  currentPage === 'setup-guide'
                    ? 'text-slate-700 bg-slate-100'
                    : 'text-gray-700 hover:text-slate-700 hover:bg-gray-50'
                }`}
              >
                Setup Guide
              </button>
            </div>
          </div>
        )}
      </div>
      {/* Overlay to close dropdown when clicking outside */}
      {showBuySellDropdown && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setShowBuySellDropdown(false)}
        />
      )}
      {showTransactionDropdown && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setShowTransactionDropdown(false)}
        />
      )}

      {/* Auth Modal */}
      {showAuthModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl w-full max-w-md mx-auto max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-gray-900">
                  {authMode === 'login' ? 'Login to Your Account' : 'Create New Account'}
                </h3>
                <button
                  onClick={() => setShowAuthModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>

              <form onSubmit={handleAuthSubmit} className="space-y-4">
                {authMode === 'register' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Full Name *
                      </label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                        <input
                          type="text"
                          value={formData.fullName}
                          onChange={(e) => handleInputChange('fullName', e.target.value)}
                          className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent"
                          placeholder="John Smith"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Phone Number *
                      </label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                        <input
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => handleInputChange('phone', e.target.value)}
                          className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent"
                          placeholder="(555) 123-4567"
                          required
                        />
                      </div>
                    </div>
                  </>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email Address *
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent"
                      placeholder="john@example.com"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Password *
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                    <input
                      type="password"
                      value={formData.password}
                      onChange={(e) => handleInputChange('password', e.target.value)}
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent"
                      placeholder="••••••••"
                      required
                    />
                  </div>
                </div>

                {authMode === 'register' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Confirm Password *
                      </label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                        <input
                          type="password"
                          value={formData.confirmPassword}
                          onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                          className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent"
                          placeholder="••••••••"
                          required
                        />
                      </div>
                    </div>

                    <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
                      <h4 className="font-semibold text-slate-800 mb-2">Property Information Required</h4>
                      <p className="text-sm text-slate-700 mb-3">
                        To set up your transaction chat, we need your current property listing information.
                      </p>
                      
                      <div className="space-y-3">
                        <div>
                          <label className="block text-sm font-medium text-slate-800 mb-1">
                            MLS Listing Number *
                          </label>
                          <input
                            type="text"
                            value={formData.mlsListing}
                            onChange={(e) => handleInputChange('mlsListing', e.target.value)}
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent bg-white"
                            placeholder="MLS123456789"
                            required
                          />
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-slate-800 mb-1">
                            Property Address *
                          </label>
                          <div className="relative">
                            <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-500 h-4 w-4" />
                            <input
                              type="text"
                              value={formData.propertyAddress}
                              onChange={(e) => handleInputChange('propertyAddress', e.target.value)}
                              className="w-full pl-10 pr-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent bg-white"
                              placeholder="123 Main St, City, State 12345"
                              required
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </>
                )}

                <button
                  type="submit"
                  className="w-full bg-slate-700 text-white py-3 px-4 rounded-lg hover:bg-slate-800 transition-colors font-semibold"
                >
                  {authMode === 'login' ? 'Login' : 'Create Account & Start Chat'}
                </button>
              </form>

              <div className="mt-6 text-center">
                <p className="text-gray-600">
                  {authMode === 'login' ? "Don't have an account?" : "Already have an account?"}
                  <button
                    onClick={() => {
                      setAuthMode(authMode === 'login' ? 'register' : 'login');
                      resetForm();
                    }}
                    className="ml-2 text-slate-700 hover:text-slate-800 font-semibold"
                  >
                    {authMode === 'login' ? 'Sign up' : 'Login'}
                  </button>
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
    </>
  );
};