import React, { useState, useEffect } from 'react';
import { MapPin, Home, DollarSign, Bed, Bath, Square, Filter, Layers, Search } from 'lucide-react';
import { Property } from '../types';
import { getApiConfig, getAvailableServices } from '../config/apiKeys';
import { mapService } from '../services/mapService';

interface InteractiveMapProps {
  properties: Property[];
  onPropertySelect: (property: Property) => void;
  center?: { lat: number; lng: number };
  zoom?: number;
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({ 
  properties, 
  onPropertySelect,
  center = { lat: 37.7749, lng: -122.4194 }, // Default to San Francisco
  zoom = 12 
}) => {
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [mapStyle, setMapStyle] = useState<'standard' | 'satellite' | 'hybrid'>('standard');
  const [showFilters, setShowFilters] = useState(false);
  const [priceRange, setPriceRange] = useState({ min: 0, max: 5000000 });
  const [mapInitialized, setMapInitialized] = useState(false);
  const [mapError, setMapError] = useState<string | null>(null);

  // Initialize map service on component mount
  useEffect(() => {
    const initializeMap = async () => {
      const config = getApiConfig();
      const services = getAvailableServices();
      
      try {
        if (services.maps.google && config.maps.google) {
          await mapService.initialize({
            provider: 'google',
            apiKey: config.maps.google
          });
          setMapInitialized(true);
        } else if (services.maps.mapbox && config.maps.mapbox) {
          await mapService.initialize({
            provider: 'mapbox',
            apiKey: config.maps.mapbox,
            style: 'mapbox://styles/mapbox/streets-v11'
          });
          setMapInitialized(true);
        } else {
          // Fallback to Leaflet (free)
          await mapService.initialize({
            provider: 'leaflet',
            apiKey: ''
          });
          setMapInitialized(true);
        }
      } catch (error) {
        console.error('Map initialization error:', error);
        setMapError('Failed to initialize map. Please check your API keys.');
      }
    };

    initializeMap();
  }, []);

  const formatPrice = (price: number) => {
    if (price >= 1000000) {
      return `$${(price / 1000000).toFixed(1)}M`;
    }
    return `$${(price / 1000).toFixed(0)}K`;
  };

  const getMarkerColor = (price: number) => {
    if (price < 500000) return 'bg-green-500';
    if (price < 1000000) return 'bg-blue-500';
    if (price < 2000000) return 'bg-orange-500';
    return 'bg-red-500';
  };

  // Filter properties by price range
  const filteredProperties = properties.filter(
    property => property.price >= priceRange.min && property.price <= priceRange.max
  );

  // Get service status for display
  const services = getAvailableServices();

  return (
    <div className="relative w-full h-full bg-gray-100 rounded-xl overflow-hidden">
      {/* Map Controls */}
      <div className="absolute top-4 left-4 z-10 flex flex-col space-y-2">
        <div className="bg-white rounded-lg shadow-lg p-2">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 rounded-lg"
          >
            <Filter className="h-4 w-4 mr-2" />
            Filters
          </button>
        </div>
        
        <div className="bg-white rounded-lg shadow-lg p-2">
          <div className="flex flex-col space-y-1">
            <button
              onClick={() => setMapStyle('standard')}
              className={`px-3 py-2 text-sm rounded ${
                mapStyle === 'standard' ? 'bg-blue-100 text-blue-700' : 'text-gray-700 hover:bg-gray-50'
              }`}
            >
              Standard
            </button>
            <button
              onClick={() => setMapStyle('satellite')}
              className={`px-3 py-2 text-sm rounded ${
                mapStyle === 'satellite' ? 'bg-blue-100 text-blue-700' : 'text-gray-700 hover:bg-gray-50'
              }`}
            >
              Satellite
            </button>
            <button
              onClick={() => setMapStyle('hybrid')}
              className={`px-3 py-2 text-sm rounded ${
                mapStyle === 'hybrid' ? 'bg-blue-100 text-blue-700' : 'text-gray-700 hover:bg-gray-50'
              }`}
            >
              Hybrid
            </button>
          </div>
        </div>
      </div>

      {/* Price Range Filter */}
      {showFilters && (
        <div className="absolute top-4 left-32 z-10 bg-white rounded-lg shadow-lg p-4 w-64">
          <h4 className="font-semibold text-gray-900 mb-3">Price Range</h4>
          <div className="space-y-3">
            <div>
              <label className="block text-sm text-gray-600 mb-1">Min Price</label>
              <input
                type="range"
                min="0"
                max="5000000"
                step="50000"
                value={priceRange.min}
                onChange={(e) => setPriceRange(prev => ({ ...prev, min: Number(e.target.value) }))}
                className="w-full"
              />
              <span className="text-sm text-gray-500">{formatPrice(priceRange.min)}</span>
            </div>
            <div>
              <label className="block text-sm text-gray-600 mb-1">Max Price</label>
              <input
                type="range"
                min="0"
                max="5000000"
                step="50000"
                value={priceRange.max}
                onChange={(e) => setPriceRange(prev => ({ ...prev, max: Number(e.target.value) }))}
                className="w-full"
              />
              <span className="text-sm text-gray-500">{formatPrice(priceRange.max)}</span>
            </div>
          </div>
          <div className="mt-3 text-sm text-gray-600">
            Showing {filteredProperties.length} properties
          </div>
        </div>
      )}

      {/* Map Container */}
      <div className="w-full h-full relative">
        {mapError ? (
          <div className="w-full h-full flex items-center justify-center bg-red-50">
            <div className="text-center">
              <div className="text-red-600 mb-4">⚠️ Map Error</div>
              <div className="text-red-800">{mapError}</div>
              <div className="text-sm text-red-600 mt-2">Check console for details</div>
            </div>
          </div>
        ) : !mapInitialized ? (
          <div className="w-full h-full flex items-center justify-center bg-blue-50">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <div className="text-blue-800">Loading Interactive Map...</div>
              <div className="text-sm text-blue-600 mt-2">
                {services.maps.google ? 'Google Maps' : services.maps.mapbox ? 'Mapbox' : 'OpenStreetMap'}
              </div>
            </div>
          </div>
        ) : (
          <div id="map-container" className="w-full h-full bg-gradient-to-br from-blue-50 to-green-50">
            {/* Fallback content while real map loads */}
            <div className="absolute inset-0 opacity-20">
              <div className="w-full h-full bg-gradient-to-br from-blue-200 via-green-100 to-blue-100"></div>
            </div>
          </div>
        )}

        {/* Property Markers */}
        {mapInitialized && filteredProperties.map((property, index) => {
          // Simulate random positions for demo
          const x = 20 + (index * 15) % 60;
          const y = 20 + (index * 12) % 60;
          
          return (
            <div
              key={property.id}
              className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer z-20"
              style={{ left: `${x}%`, top: `${y}%` }}
              onClick={() => {
                setSelectedProperty(property);
                onPropertySelect(property);
              }}
            >
              <div className={`${getMarkerColor(property.price)} text-white px-2 py-1 rounded-full text-xs font-bold shadow-lg hover:scale-110 transition-transform`}>
                {formatPrice(property.price)}
              </div>
              <div className="w-3 h-3 bg-white rounded-full border-2 border-gray-400 mx-auto -mt-1"></div>
            </div>
          );
        })}

        {/* Property Details Popup */}
        {selectedProperty && (
          <div className="absolute bottom-4 left-4 right-4 bg-white rounded-xl shadow-2xl p-4 z-30 max-w-sm">
            <div className="flex items-start space-x-3">
              <img
                src={selectedProperty.images[0]}
                alt={selectedProperty.title}
                className="w-20 h-20 object-cover rounded-lg"
              />
              <div className="flex-1">
                <h4 className="font-semibold text-gray-900 text-sm mb-1">
                  {selectedProperty.title}
                </h4>
                <p className="text-xs text-gray-600 mb-2">
                  {selectedProperty.address}, {selectedProperty.city}
                </p>
                <div className="flex items-center space-x-3 text-xs text-gray-600 mb-2">
                  <div className="flex items-center">
                    <Bed className="h-3 w-3 mr-1" />
                    {selectedProperty.bedrooms}
                  </div>
                  <div className="flex items-center">
                    <Bath className="h-3 w-3 mr-1" />
                    {selectedProperty.bathrooms}
                  </div>
                  <div className="flex items-center">
                    <Square className="h-3 w-3 mr-1" />
                    {selectedProperty.squareFeet.toLocaleString()}
                  </div>
                </div>
                <div className="text-lg font-bold text-gray-900">
                  ${selectedProperty.price.toLocaleString()}
                </div>
              </div>
              <button
                onClick={() => setSelectedProperty(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                ×
              </button>
            </div>
          </div>
        )}

        {/* Map Status Indicator */}
        <div className={`absolute bottom-4 right-4 px-4 py-2 rounded-lg text-sm ${
          services.maps.hasAnyMap 
            ? 'bg-green-600 text-white' 
            : 'bg-yellow-600 text-white'
        }`}>
          {services.maps.hasAnyMap ? '🗺️ Live Map Active' : '🗺️ Demo Mode - Add API Keys'}
        </div>
      </div>

      {/* Legend */}
      <div className="absolute top-4 right-4 bg-white rounded-lg shadow-lg p-3 z-10">
        <h4 className="font-semibold text-gray-900 text-sm mb-2">Price Legend</h4>
        <div className="space-y-1 text-xs">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
            <span>Under $500K</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
            <span>$500K - $1M</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-orange-500 rounded-full mr-2"></div>
            <span>$1M - $2M</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
            <span>$2M+</span>
          </div>
        </div>
      </div>
    </div>
  );
};