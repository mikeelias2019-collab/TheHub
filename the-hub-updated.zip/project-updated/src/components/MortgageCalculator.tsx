import React, { useState, useMemo } from 'react';
import { DollarSign, Percent, Calendar, TrendingUp, Info, X } from 'lucide-react';

interface MortgageCalculatorProps {
  initialPrice?: number;
  onClose?: () => void;
  embedded?: boolean;
}

export const MortgageCalculator: React.FC<MortgageCalculatorProps> = ({
  initialPrice = 750000,
  onClose,
  embedded = false,
}) => {
  const [homePrice, setHomePrice] = useState(initialPrice);
  const [downPaymentPct, setDownPaymentPct] = useState(20);
  const [interestRate, setInterestRate] = useState(6.8);
  const [loanTermYears, setLoanTermYears] = useState(30);
  const [propertyTaxRate, setPropertyTaxRate] = useState(1.25);
  const [homeInsurance, setHomeInsurance] = useState(1500);
  const [hoaMonthly, setHoaMonthly] = useState(0);

  const calc = useMemo(() => {
    const downPayment = homePrice * (downPaymentPct / 100);
    const loanAmount = homePrice - downPayment;
    const monthlyRate = interestRate / 100 / 12;
    const numPayments = loanTermYears * 12;

    const monthlyPrincipalInterest = monthlyRate === 0
      ? loanAmount / numPayments
      : (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, numPayments)) /
        (Math.pow(1 + monthlyRate, numPayments) - 1);

    const monthlyTax = (homePrice * propertyTaxRate / 100) / 12;
    const monthlyInsurance = homeInsurance / 12;
    const totalMonthly = monthlyPrincipalInterest + monthlyTax + monthlyInsurance + hoaMonthly;
    const totalPaid = monthlyPrincipalInterest * numPayments;
    const totalInterest = totalPaid - loanAmount;

    return { downPayment, loanAmount, monthlyPrincipalInterest, monthlyTax, monthlyInsurance, totalMonthly, totalPaid, totalInterest };
  }, [homePrice, downPaymentPct, interestRate, loanTermYears, propertyTaxRate, homeInsurance, hoaMonthly]);

  const fmt = (n: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0 }).format(n);
  const fmtDec = (n: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(n);

  const paidBreakdown = [
    { label: 'Principal & Interest', amount: calc.monthlyPrincipalInterest, color: 'bg-slate-600' },
    { label: 'Property Tax', amount: calc.monthlyTax, color: 'bg-blue-400' },
    { label: 'Home Insurance', amount: calc.monthlyInsurance, color: 'bg-emerald-400' },
    ...(hoaMonthly > 0 ? [{ label: 'HOA', amount: hoaMonthly, color: 'bg-amber-400' }] : []),
  ];

  const content = (
    <div className="space-y-6">
      {/* Monthly Payment Hero */}
      <div className="bg-gradient-to-r from-slate-700 to-slate-600 rounded-2xl p-6 text-white text-center">
        <div className="text-sm font-medium text-slate-300 mb-1">Estimated Monthly Payment</div>
        <div className="text-5xl font-bold mb-1">{fmtDec(calc.totalMonthly)}</div>
        <div className="text-slate-300 text-sm">/month</div>

        {/* Breakdown bars */}
        <div className="mt-4 flex rounded-full overflow-hidden h-2">
          {paidBreakdown.map((item, i) => (
            <div
              key={i}
              className={`${item.color} transition-all duration-500`}
              style={{ width: `${(item.amount / calc.totalMonthly) * 100}%` }}
            />
          ))}
        </div>
        <div className="mt-3 flex flex-wrap justify-center gap-3">
          {paidBreakdown.map((item, i) => (
            <div key={i} className="flex items-center gap-1 text-xs text-slate-300">
              <span className={`w-2 h-2 rounded-full ${item.color}`} />
              {item.label}: {fmtDec(item.amount)}
            </div>
          ))}
        </div>
      </div>

      {/* Inputs */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">Home Price</label>
          <div className="relative">
            <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="number"
              value={homePrice}
              onChange={e => setHomePrice(Number(e.target.value))}
              className="w-full pl-9 pr-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-slate-400 focus:border-transparent bg-slate-50"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Down Payment: {downPaymentPct}% ({fmt(calc.downPayment)})
          </label>
          <input
            type="range" min={3} max={50} value={downPaymentPct}
            onChange={e => setDownPaymentPct(Number(e.target.value))}
            className="w-full accent-slate-600"
          />
          <div className="flex justify-between text-xs text-slate-400 mt-1">
            <span>3%</span><span>50%</span>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Interest Rate: {interestRate}%
          </label>
          <input
            type="range" min={2} max={12} step={0.1} value={interestRate}
            onChange={e => setInterestRate(Number(e.target.value))}
            className="w-full accent-slate-600"
          />
          <div className="flex justify-between text-xs text-slate-400 mt-1">
            <span>2%</span><span>12%</span>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">Loan Term</label>
          <div className="flex gap-2">
            {[10, 15, 20, 30].map(yr => (
              <button
                key={yr}
                onClick={() => setLoanTermYears(yr)}
                className={`flex-1 py-3 rounded-xl text-sm font-medium transition-colors ${
                  loanTermYears === yr ? 'bg-slate-700 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {yr}yr
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Property Tax Rate: {propertyTaxRate}%
          </label>
          <input
            type="range" min={0.5} max={3} step={0.05} value={propertyTaxRate}
            onChange={e => setPropertyTaxRate(Number(e.target.value))}
            className="w-full accent-slate-600"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">HOA (monthly)</label>
          <div className="relative">
            <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="number"
              value={hoaMonthly}
              onChange={e => setHoaMonthly(Number(e.target.value))}
              className="w-full pl-9 pr-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-slate-400 focus:border-transparent bg-slate-50"
              placeholder="0"
            />
          </div>
        </div>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Loan Amount', value: fmt(calc.loanAmount) },
          { label: 'Total Interest', value: fmt(calc.totalInterest) },
          { label: 'Total Cost', value: fmt(calc.totalPaid + calc.downPayment) },
        ].map((item, i) => (
          <div key={i} className="bg-slate-50 rounded-xl p-4 text-center border border-slate-100">
            <div className="text-lg font-bold text-slate-800">{item.value}</div>
            <div className="text-xs text-slate-500 mt-1">{item.label}</div>
          </div>
        ))}
      </div>

      <p className="text-xs text-slate-400 flex items-start gap-1">
        <Info className="h-3 w-3 mt-0.5 flex-shrink-0" />
        Estimates only. Actual rates and payments may vary. Consult a lender for an official quote.
      </p>
    </div>
  );

  if (embedded) return <div>{content}</div>;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="flex items-center justify-between p-6 border-b border-slate-100">
          <h2 className="text-2xl font-bold text-slate-800">Mortgage Calculator</h2>
          {onClose && (
            <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-colors">
              <X className="h-5 w-5" />
            </button>
          )}
        </div>
        <div className="p-6">{content}</div>
      </div>
    </div>
  );
};
