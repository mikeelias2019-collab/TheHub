import React, { useState } from 'react';
import { 
  DollarSign, 
  Clock, 
  CheckCircle, 
  MapPin, 
  Home, 
  Calculator,
  TrendingUp,
  Users,
  Phone,
  Mail,
  Star,
  ArrowRight,
  Zap
} from 'lucide-react';

interface CashOfferForm {
  address: string;
  city: string;
  state: string;
  zipCode: string;
  bedrooms: number;
  bathrooms: number;
  squareFeet: number;
  yearBuilt: number;
  propertyCondition: 'excellent' | 'good' | 'fair' | 'needs-work';
  timeframe: 'asap' | '30-days' | '60-days' | 'flexible';
  contactName: string;
  contactPhone: string;
  contactEmail: string;
}

interface Investor {
  id: string;
  name: string;
  company: string;
  rating: number;
  reviewCount: number;
  specialties: string[];
  avgClosingTime: string;
  phone: string;
  email: string;
  avatar: string;
  totalPurchases: number;
  description: string;
}

const mockInvestors: Investor[] = [
  {
    id: '1',
    name: 'Sarah Martinez',
    company: 'Bay Area Property Solutions',
    rating: 4.9,
    reviewCount: 127,
    specialties: ['Single Family Homes', 'Fixer-Uppers', 'Quick Closings'],
    avgClosingTime: '7-10 days',
    phone: '(555) 123-4567',
    email: 'sarah@bayproperties.com',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg',
    totalPurchases: 89,
    description: 'Specializing in fast, fair cash offers with transparent pricing and quick closings.'
  },
  {
    id: '2',
    name: 'Michael Chen',
    company: 'Golden State Investors',
    rating: 4.8,
    reviewCount: 203,
    specialties: ['Luxury Homes', 'Investment Properties', 'As-Is Purchases'],
    avgClosingTime: '5-7 days',
    phone: '(555) 234-5678',
    email: 'michael@goldenstateinv.com',
    avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg',
    totalPurchases: 156,
    description: 'Top-rated investor with a track record of competitive offers and smooth transactions.'
  },
  {
    id: '3',
    name: 'Jennifer Rodriguez',
    company: 'Rapid Home Buyers',
    rating: 4.7,
    reviewCount: 94,
    specialties: ['Distressed Properties', 'Inherited Homes', 'Divorce Sales'],
    avgClosingTime: '10-14 days',
    phone: '(555) 345-6789',
    email: 'jennifer@rapidhomebuyers.com',
    avatar: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg',
    totalPurchases: 67,
    description: 'Compassionate investor helping families through difficult situations with fair cash offers.'
  }
];

export const InstantCashOffer: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<CashOfferForm>({
    address: '',
    city: '',
    state: '',
    zipCode: '',
    bedrooms: 1,
    bathrooms: 1,
    squareFeet: 0,
    yearBuilt: new Date().getFullYear(),
    propertyCondition: 'good',
    timeframe: '30-days',
    contactName: '',
    contactPhone: '',
    contactEmail: ''
  });
  const [showOffers, setShowOffers] = useState(false);
  const [selectedInvestor, setSelectedInvestor] = useState<string | null>(null);

  const handleInputChange = (field: keyof CashOfferForm, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = () => {
    setShowOffers(true);
  };

  const isFormValid = () => {
    return formData.address && formData.city && formData.state && formData.zipCode &&
           formData.squareFeet > 0 && formData.contactName && formData.contactPhone && formData.contactEmail;
  };

  const estimatedValue = Math.floor((formData.squareFeet * 250) + (formData.bedrooms * 15000) + (formData.bathrooms * 8000));
  const cashOfferRange = {
    low: Math.floor(estimatedValue * 0.75),
    high: Math.floor(estimatedValue * 0.85)
  };

  if (showOffers) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold mb-4">Your Cash Offers Are Ready!</h1>
            <p className="text-xl text-slate-300">
              Local investors are interested in your property at {formData.address}
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {mockInvestors.map((investor) => (
              <div
                key={investor.id}
                className={`bg-white/10 backdrop-blur-lg rounded-2xl p-6 border transition-all duration-300 hover:scale-105 cursor-pointer ${
                  selectedInvestor === investor.id 
                    ? 'border-blue-400 bg-blue-500/20' 
                    : 'border-white/20 hover:border-white/40'
                }`}
                onClick={() => setSelectedInvestor(investor.id)}
              >
                <div className="flex items-center mb-4">
                  <img
                    src={investor.avatar}
                    alt={investor.name}
                    className="w-16 h-16 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h3 className="text-xl font-bold text-white">{investor.name}</h3>
                    <p className="text-slate-300">{investor.company}</p>
                    <div className="flex items-center mt-1">
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <span className="text-sm text-slate-300 ml-1">
                        {investor.rating} ({investor.reviewCount} reviews)
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mb-4">
                  <div className="text-3xl font-bold text-green-400 mb-2">
                    ${cashOfferRange.low.toLocaleString()} - ${cashOfferRange.high.toLocaleString()}
                  </div>
                  <p className="text-sm text-slate-400">Estimated cash offer range</p>
                </div>

                <div className="space-y-3 mb-4">
                  <div className="flex items-center text-sm text-slate-300">
                    <Clock className="h-4 w-4 mr-2 text-blue-400" />
                    Closes in {investor.avgClosingTime}
                  </div>
                  <div className="flex items-center text-sm text-slate-300">
                    <Home className="h-4 w-4 mr-2 text-green-400" />
                    {investor.totalPurchases} homes purchased
                  </div>
                </div>

                <div className="mb-4">
                  <p className="text-sm text-slate-300">{investor.description}</p>
                </div>

                <div className="mb-4">
                  <h4 className="font-semibold text-white mb-2">Specialties:</h4>
                  <div className="flex flex-wrap gap-2">
                    {investor.specialties.map((specialty, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 bg-blue-500/20 text-blue-300 rounded-full text-xs"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex space-x-2">
                  <button className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center">
                    <Phone className="h-4 w-4 mr-2" />
                    Call Now
                  </button>
                  <button className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center">
                    <Mail className="h-4 w-4 mr-2" />
                    Email
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 max-w-4xl mx-auto">
              <h3 className="text-2xl font-bold text-white mb-4">What Happens Next?</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
                <div className="flex items-start space-x-3">
                  <div className="bg-blue-500 rounded-full p-2 flex-shrink-0">
                    <Phone className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white mb-2">1. Contact Investor</h4>
                    <p className="text-slate-300 text-sm">
                      Reach out to your preferred investor to discuss your property and timeline.
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="bg-green-500 rounded-full p-2 flex-shrink-0">
                    <Home className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white mb-2">2. Property Evaluation</h4>
                    <p className="text-slate-300 text-sm">
                      The investor will schedule a quick property walkthrough (usually within 24-48 hours).
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="bg-purple-500 rounded-full p-2 flex-shrink-0">
                    <CheckCircle className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white mb-2">3. Final Offer & Close</h4>
                    <p className="text-slate-300 text-sm">
                      Receive your final cash offer and close on your timeline - often within 7-14 days.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 text-center">
            <button
              onClick={() => setShowOffers(false)}
              className="px-8 py-3 bg-slate-700 text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              ← Back to Form
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-green-500 p-3 rounded-full mr-4">
              <Zap className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold">Get an Instant Cash Offer</h1>
          </div>
          <p className="text-xl text-slate-300 mb-6">
            Connect with local investors and get competitive cash offers in minutes
          </p>
          
          {/* Benefits */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-4 border border-white/20">
              <Clock className="h-8 w-8 text-slate-400 mx-auto mb-2" />
              <h3 className="font-semibold text-white mb-1">Fast Closing</h3>
              <p className="text-sm text-slate-300">Close in as little as 7 days</p>
            </div>
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-4 border border-white/20">
              <DollarSign className="h-8 w-8 text-green-400 mx-auto mb-2" />
              <h3 className="font-semibold text-white mb-1">Cash Offers</h3>
              <p className="text-sm text-slate-300">No financing contingencies</p>
            </div>
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-4 border border-white/20">
              <Home className="h-8 w-8 text-slate-400 mx-auto mb-2" />
              <h3 className="font-semibold text-white mb-1">Sell As-Is</h3>
              <p className="text-sm text-slate-300">No repairs or staging needed</p>
            </div>
          </div>
        </div>

        {/* Form */}
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
          <h2 className="text-2xl font-bold text-white mb-6">Tell Us About Your Property</h2>
          
          <div className="space-y-6">
            {/* Property Address */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-4">Property Location</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Street Address *
                  </label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={(e) => handleInputChange('address', e.target.value)}
                    className="w-full p-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-slate-400 focus:border-slate-400 focus:ring-2 focus:ring-slate-400/50 transition-all backdrop-blur-sm"
                    placeholder="123 Main Street"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    City *
                  </label>
                  <input
                    type="text"
                    value={formData.city}
                    onChange={(e) => handleInputChange('city', e.target.value)}
                    className="w-full p-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-slate-400 focus:border-slate-400 focus:ring-2 focus:ring-slate-400/50 transition-all backdrop-blur-sm"
                    placeholder="San Francisco"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    State *
                  </label>
                  <input
                    type="text"
                    value={formData.state}
                    onChange={(e) => handleInputChange('state', e.target.value)}
                    className="w-full p-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-slate-400 focus:border-blue-400 focus:ring-2 focus:ring-blue-400/50 transition-all backdrop-blur-sm"
                    placeholder="CA"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    ZIP Code *
                  </label>
                  <input
                    type="text"
                    value={formData.zipCode}
                    onChange={(e) => handleInputChange('zipCode', e.target.value)}
                    className="w-full p-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-slate-400 focus:border-blue-400 focus:ring-2 focus:ring-blue-400/50 transition-all backdrop-blur-sm"
                    placeholder="94102"
                  />
                </div>
              </div>
            </div>

            {/* Property Details */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-4">Property Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Bedrooms *
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={formData.bedrooms}
                    onChange={(e) => handleInputChange('bedrooms', Number(e.target.value))}
                    className="w-full p-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-slate-400 focus:border-blue-400 focus:ring-2 focus:ring-blue-400/50 transition-all backdrop-blur-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Bathrooms *
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="0.5"
                    value={formData.bathrooms}
                    onChange={(e) => handleInputChange('bathrooms', Number(e.target.value))}
                    className="w-full p-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-slate-400 focus:border-blue-400 focus:ring-2 focus:ring-blue-400/50 transition-all backdrop-blur-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Square Feet *
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={formData.squareFeet}
                    onChange={(e) => handleInputChange('squareFeet', Number(e.target.value))}
                    className="w-full p-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-slate-400 focus:border-blue-400 focus:ring-2 focus:ring-blue-400/50 transition-all backdrop-blur-sm"
                    placeholder="2000"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Year Built
                  </label>
                  <input
                    type="number"
                    min="1800"
                    max={new Date().getFullYear()}
                    value={formData.yearBuilt}
                    onChange={(e) => handleInputChange('yearBuilt', Number(e.target.value))}
                    className="w-full p-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-slate-400 focus:border-blue-400 focus:ring-2 focus:ring-blue-400/50 transition-all backdrop-blur-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Property Condition
                  </label>
                  <select
                    value={formData.propertyCondition}
                    onChange={(e) => handleInputChange('propertyCondition', e.target.value)}
                    className="w-full p-3 bg-white/20 border border-white/30 rounded-lg text-white focus:border-blue-400 focus:ring-2 focus:ring-blue-400/50 transition-all backdrop-blur-sm"
                  >
                    <option value="excellent" className="bg-slate-800">Excellent</option>
                    <option value="good" className="bg-slate-800">Good</option>
                    <option value="fair" className="bg-slate-800">Fair</option>
                    <option value="needs-work" className="bg-slate-800">Needs Work</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Timeframe to Sell
                  </label>
                  <select
                    value={formData.timeframe}
                    onChange={(e) => handleInputChange('timeframe', e.target.value)}
                    className="w-full p-3 bg-white/20 border border-white/30 rounded-lg text-white focus:border-blue-400 focus:ring-2 focus:ring-blue-400/50 transition-all backdrop-blur-sm"
                  >
                    <option value="asap" className="bg-slate-800">ASAP</option>
                    <option value="30-days" className="bg-slate-800">Within 30 days</option>
                    <option value="60-days" className="bg-slate-800">Within 60 days</option>
                    <option value="flexible" className="bg-slate-800">Flexible</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Contact Information */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-4">Contact Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    value={formData.contactName}
                    onChange={(e) => handleInputChange('contactName', e.target.value)}
                    className="w-full p-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-slate-400 focus:border-blue-400 focus:ring-2 focus:ring-blue-400/50 transition-all backdrop-blur-sm"
                    placeholder="John Smith"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    value={formData.contactPhone}
                    onChange={(e) => handleInputChange('contactPhone', e.target.value)}
                    className="w-full p-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-slate-400 focus:border-blue-400 focus:ring-2 focus:ring-blue-400/50 transition-all backdrop-blur-sm"
                    placeholder="(555) 123-4567"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    value={formData.contactEmail}
                    onChange={(e) => handleInputChange('contactEmail', e.target.value)}
                    className="w-full p-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-slate-400 focus:border-blue-400 focus:ring-2 focus:ring-blue-400/50 transition-all backdrop-blur-sm"
                    placeholder="john@example.com"
                  />
                </div>
              </div>
            </div>

            {/* Estimated Value Display */}
            {formData.squareFeet > 0 && (
              <div className="bg-green-500/20 border border-green-400/30 rounded-xl p-6">
                <div className="flex items-center mb-4">
                  <Calculator className="h-6 w-6 text-green-400 mr-3" />
                  <h3 className="text-lg font-semibold text-white">Estimated Cash Offer Range</h3>
                </div>
                <div className="text-3xl font-bold text-green-400 mb-2">
                  ${cashOfferRange.low.toLocaleString()} - ${cashOfferRange.high.toLocaleString()}
                </div>
                <p className="text-sm text-slate-300">
                  This is a preliminary estimate. Final offers will be based on property inspection and market conditions.
                </p>
              </div>
            )}

            {/* Submit Button */}
            <div className="text-center">
              <button
                onClick={handleSubmit}
                disabled={!isFormValid()}
                className={`px-12 py-4 rounded-xl font-semibold text-lg transition-all flex items-center mx-auto ${
                  isFormValid()
                    ? 'bg-gradient-to-r from-slate-700 to-slate-600 text-white hover:from-slate-800 hover:to-slate-700 shadow-lg hover:shadow-slate-500/25'
                    : 'bg-gray-600 text-gray-400 cursor-not-allowed'
                }`}
              >
                Get My Cash Offers
                <ArrowRight className="h-5 w-5 ml-2" />
              </button>
              <p className="text-sm text-slate-400 mt-3">
                Free service • No obligation • Get offers in minutes
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};