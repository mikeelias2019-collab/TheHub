import React from 'react';
import { Property } from '../types';
import { Bed, Bath, Square, MapPin, Calendar, Heart, Eye, TrendingUp, Star } from 'lucide-react';

interface PropertyCardProps {
  property: Property;
  onClick: () => void;
  onSave?: (propertyId: string) => void;
  isSaved?: boolean;
}

export const PropertyCard: React.FC<PropertyCardProps> = ({ property, onClick, onSave, isSaved = false }) => {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <div
      className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 relative group"
    >
      {/* Property Image */}
      <div className="relative overflow-hidden rounded-t-xl">
        <img
          src={property.images[0]}
          alt={property.title}
          className="w-full h-48 object-cover transition-transform duration-300 hover:scale-105 cursor-pointer"
          onClick={onClick}
        />
        
        {/* Status Badge */}
        <div className="absolute top-4 left-4">
          <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
            property.status === 'active' 
              ? 'bg-green-100 text-green-800' 
              : property.status === 'pending'
              ? 'bg-yellow-100 text-yellow-800'
              : 'bg-gray-100 text-gray-800'
          }`}>
            {property.status === 'active' ? 'Active' : property.status === 'pending' ? 'Pending' : 'Sold'}
          </span>
        </div>
        
        {/* Save Button */}
        <div className="absolute top-4 right-4 flex space-x-2">
          {property.virtualTour && (
            <div className="bg-blue-600 text-white px-2 py-1 rounded text-xs font-medium">
              Virtual Tour
            </div>
          )}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onSave?.(property.id);
            }}
            className={`p-2 rounded-full transition-colors ${
              isSaved 
                ? 'bg-red-500 text-white' 
                : 'bg-white bg-opacity-80 text-gray-600 hover:bg-red-500 hover:text-white'
            }`}
          >
            <Heart className={`h-4 w-4 ${isSaved ? 'fill-current' : ''}`} />
          </button>
        </div>
        
        {/* Days on Market */}
        <div className="absolute bottom-4 left-4">
          <span className="bg-black bg-opacity-70 text-white px-2 py-1 rounded text-xs">
            {property.daysOnMarket} days on market
          </span>
        </div>
      </div>

      {/* Property Details */}
      <div className="p-6 cursor-pointer" onClick={onClick}>
        {/* Price */}
        <div className="mb-2 flex items-center justify-between">
          <span className="text-2xl font-bold text-gray-900">
            {formatPrice(property.price)}
          </span>
          {property.listingType === 'rent' && (
            <span className="text-gray-600">/month</span>
          )}
          {property.priceHistory && property.priceHistory.length > 1 && (
            <div className="flex items-center text-green-600 text-sm">
              <TrendingUp className="h-4 w-4 mr-1" />
              <span>Price reduced</span>
            </div>
          )}
        </div>

        {/* Estimated Value */}
        {property.estimatedValue && (
          <div className="mb-2 text-sm text-gray-600">
            Est. value: {formatPrice(property.estimatedValue.low)} - {formatPrice(property.estimatedValue.high)}
          </div>
        )}

        {/* Title */}
        <h3 className="text-lg font-semibold text-gray-900 mb-2 line-clamp-2">
          {property.title}
        </h3>

        {/* Address */}
        <div className="flex items-center text-gray-600 mb-4">
          <MapPin className="h-4 w-4 mr-1" />
          <span className="text-sm">
            {property.address}, {property.city}, {property.state} {property.zipCode}
          </span>
        </div>

        {/* Property Stats */}
        <div className="flex items-center gap-4 text-gray-600 mb-4">
          <div className="flex items-center">
            <Bed className="h-4 w-4 mr-1" />
            <span className="text-sm">{property.bedrooms} beds</span>
          </div>
          <div className="flex items-center">
            <Bath className="h-4 w-4 mr-1" />
            <span className="text-sm">{property.bathrooms} baths</span>
          </div>
          <div className="flex items-center">
            <Square className="h-4 w-4 mr-1" />
            <span className="text-sm">{property.squareFeet.toLocaleString()} sqft</span>
          </div>
        </div>

        {/* Walk Score & Schools */}
        {(property.walkScore || property.schoolRatings) && (
          <div className="flex items-center gap-4 text-gray-600 mb-4 text-sm">
            {property.walkScore && (
              <div className="flex items-center">
                <span className="font-medium">Walk Score: {property.walkScore}</span>
              </div>
            )}
            {property.schoolRatings && property.schoolRatings.length > 0 && (
              <div className="flex items-center">
                <Star className="h-4 w-4 mr-1 text-yellow-500" />
                <span>Schools: {Math.round(property.schoolRatings.reduce((acc, school) => acc + school.rating, 0) / property.schoolRatings.length)}/10</span>
              </div>
            )}
          </div>
        )}

        {/* Property Type */}
        <div className="mb-4 flex items-center justify-between">
          <span className="inline-block bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm font-medium capitalize">
            {property.propertyType}
          </span>
          <div className="flex items-center text-gray-500 text-sm space-x-3">
            <div className="flex items-center">
              <Eye className="h-4 w-4 mr-1" />
              <span>{property.viewCount}</span>
            </div>
            {property.savedByUsers && (
              <div className="flex items-center">
                <Heart className="h-4 w-4 mr-1" />
                <span>{property.savedByUsers}</span>
              </div>
            )}
          </div>
        </div>

        {/* Agent Info */}
        <div className="pt-4 border-t border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <img
                src={property.agent.photo}
                alt={property.agent.name}
                className="w-8 h-8 rounded-full mr-3 object-cover"
              />
                <p className="text-xs text-gray-500">{property.agent.brokerage}</p>
              <p className="text-sm text-gray-500">{property.agent.phone}</p>
            </div>
            <div className="text-right">
              <div className="flex items-center text-xs text-gray-500">
                <Star className="h-3 w-3 mr-1 text-yellow-500 fill-current" />
                <span>{property.agent.rating} ({property.agent.reviewCount})</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};