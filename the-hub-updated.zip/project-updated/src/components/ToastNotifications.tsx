import React from 'react';
import { Heart, Bell, Calendar, X } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ToastNotifications: React.FC = () => {
  const { notifications, dismissNotification } = useApp();

  if (notifications.length === 0) return null;

  return (
    <div className="fixed top-20 right-4 z-[100] space-y-2 pointer-events-none">
      {notifications.map(n => (
        <div
          key={n.id}
          className="flex items-center gap-3 bg-white border border-slate-200 rounded-2xl px-4 py-3 shadow-lg pointer-events-auto animate-in slide-in-from-right-4 duration-300 min-w-64"
        >
          <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
            n.type === 'saved' ? 'bg-red-100' : n.type === 'alert' ? 'bg-amber-100' : 'bg-green-100'
          }`}>
            {n.type === 'saved' && <Heart className="h-4 w-4 text-red-500" />}
            {n.type === 'alert' && <Bell className="h-4 w-4 text-amber-500" />}
            {n.type === 'showing' && <Calendar className="h-4 w-4 text-green-500" />}
          </div>
          <span className="text-sm font-medium text-slate-700 flex-1">{n.message}</span>
          <button
            onClick={() => dismissNotification(n.id)}
            className="text-slate-300 hover:text-slate-500 transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      ))}
    </div>
  );
};
