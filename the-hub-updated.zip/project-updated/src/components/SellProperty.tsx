import React, { useState } from 'react';
import { ListingFormData } from '../types';
import { CheckCircle, Home, Users, MessageSquare, HandHeart, ArrowLeft, ArrowRight } from 'lucide-react';

export const SellProperty: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState<ListingFormData>({
    address: '',
    city: '',
    state: '',
    zipCode: '',
    propertyType: '',
    bedrooms: '',
    bathrooms: '',
    squareFootage: '',
    yearBuilt: '',
    lotSize: '',
    price: '',
    description: '',
    features: [],
    ownerName: '',
    ownerPhone: '',
    ownerEmail: '',
    coOwnerName: '',
    coOwnerPhone: '',
    coOwnerEmail: '',
    hasCoOwner: false,
    bestTimeToCall: '',
    photoSessionTime: ''
  });

  const steps = [
    { number: 1, title: 'Property Details', icon: Home },
    { number: 2, title: 'Owner & Co-Owner Info', icon: Users },
    { number: 3, title: 'Coordinator Assignment', icon: MessageSquare }
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFeatureToggle = (feature: string) => {
    setFormData(prev => ({
      ...prev,
      features: prev.features.includes(feature)
        ? prev.features.filter(f => f !== feature)
        : [...prev.features, feature]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  const nextStep = () => setCurrentStep(prev => Math.min(prev + 1, 3));
  const prevStep = () => setCurrentStep(prev => Math.max(prev - 1, 1));

  const handleCoOwnerToggle = (hasCoOwner: boolean) => {
    setFormData(prev => ({
      ...prev,
      hasCoOwner,
      // Clear co-owner fields if toggled off
      coOwnerName: hasCoOwner ? prev.coOwnerName : '',
      coOwnerPhone: hasCoOwner ? prev.coOwnerPhone : '',
      coOwnerEmail: hasCoOwner ? prev.coOwnerEmail : ''
    }));
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 py-12">
        <div className="max-w-2xl mx-auto px-4">
          <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
            <h2 className="text-3xl font-bold text-slate-800 mb-4">
              Listing Submitted Successfully!
            </h2>
            <div className="bg-slate-50 rounded-lg p-6 mb-6">
              <h3 className="text-lg font-semibold text-slate-700 mb-3">
                🎯 Transaction Coordinator Assigned
              </h3>
              <p className="text-slate-600 mb-4">
                A dedicated transaction coordinator has been automatically assigned to your deal and will contact you within 2 hours to guide you through the entire selling process.
              </p>
            </div>
            <div className="text-left space-y-4 mb-8">
              <h3 className="text-xl font-semibold text-slate-800 mb-4">What happens next:</h3>
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-slate-600 text-white rounded-full flex items-center justify-center text-sm font-bold">1</div>
                  <div>
                    <p className="font-medium text-slate-700">Coordinator Assignment</p>
                    <p className="text-slate-600 text-sm">Your transaction coordinator will contact you within 2 hours</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-slate-600 text-white rounded-full flex items-center justify-center text-sm font-bold">2</div>
                  <div>
                    <p className="font-medium text-slate-700">Listing Review</p>
                    <p className="text-slate-600 text-sm">Our team will review your listing within 24 hours</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-slate-600 text-white rounded-full flex items-center justify-center text-sm font-bold">3</div>
                  <div>
                    <p className="font-medium text-slate-700">Transaction Chat Setup</p>
                    <p className="text-slate-600 text-sm">Your coordinator will set up a dedicated communication hub</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-slate-600 text-white rounded-full flex items-center justify-center text-sm font-bold">4</div>
                  <div>
                    <p className="font-medium text-slate-700">Buyer Connection</p>
                    <p className="text-slate-600 text-sm">We'll connect you with qualified buyers</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-slate-600 text-white rounded-full flex items-center justify-center text-sm font-bold">5</div>
                  <div>
                    <p className="font-medium text-slate-700">Full Process Guidance</p>
                    <p className="text-slate-600 text-sm">Your coordinator guides you from listing to closing</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-slate-50 rounded-lg p-4 mb-6">
              <h4 className="font-semibold text-slate-700 mb-2">Your Transaction Coordinator Will:</h4>
              <ul className="text-sm text-slate-600 space-y-1">
                <li>• Provide dedicated support throughout your selling journey</li>
                <li>• Manage the entire transaction process from start to finish</li>
                <li>• Coordinate between all parties (buyers, agents, inspectors, etc.)</li>
                <li>• Keep you informed with regular updates and guidance</li>
              </ul>
            </div>
            <button
              onClick={() => window.location.reload()}
              className="bg-slate-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-slate-700 transition-colors"
            >
              List Another Property
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 py-12">
      <div className="max-w-4xl mx-auto px-4">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          {/* Header */}
          <div className="bg-slate-600 text-white p-6">
            <h1 className="text-3xl font-bold mb-2">List Your Property</h1>
            <p className="text-slate-200">Get your property in front of qualified buyers</p>
          </div>

          {/* Progress Steps */}
          <div className="p-6 border-b border-slate-200">
            <div className="flex items-center justify-between">
              {steps.map((step, index) => (
                <div key={step.number} className="flex items-center">
                  <div className={`flex items-center justify-center w-10 h-10 rounded-full ${
                    currentStep >= step.number ? 'bg-slate-600 text-white' : 'bg-slate-200 text-slate-600'
                  }`}>
                    <step.icon className="w-5 h-5" />
                  </div>
                  <div className="ml-3">
                    <p className={`text-sm font-medium ${
                      currentStep >= step.number ? 'text-slate-800' : 'text-slate-500'
                    }`}>
                      Step {step.number}
                    </p>
                    <p className={`text-xs ${
                      currentStep >= step.number ? 'text-slate-600' : 'text-slate-400'
                    }`}>
                      {step.title}
                    </p>
                  </div>
                  {index < steps.length - 1 && (
                    <div className={`w-16 h-0.5 mx-4 ${
                      currentStep > step.number ? 'bg-slate-600' : 'bg-slate-200'
                    }`} />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Form Content */}
          <form onSubmit={handleSubmit} className="p-6">
            {currentStep === 1 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-slate-800 mb-6">Property Details</h2>
                
                {/* Address Information */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Property Address *
                    </label>
                    <input
                      type="text"
                      name="address"
                      value={formData.address}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                      placeholder="123 Main Street"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      City *
                    </label>
                    <input
                      type="text"
                      name="city"
                      value={formData.city}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                      placeholder="City"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      State *
                    </label>
                    <select
                      name="state"
                      value={formData.state}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                      required
                    >
                      <option value="">Select State</option>
                      <option value="CA">California</option>
                      <option value="TX">Texas</option>
                      <option value="FL">Florida</option>
                      <option value="NY">New York</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      ZIP Code *
                    </label>
                    <input
                      type="text"
                      name="zipCode"
                      value={formData.zipCode}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                      placeholder="12345"
                      required
                    />
                  </div>
                </div>

                {/* Property Details */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Property Type *
                    </label>
                    <select
                      name="propertyType"
                      value={formData.propertyType}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                      required
                    >
                      <option value="">Select Type</option>
                      <option value="Single Family">Single Family</option>
                      <option value="Condo">Condo</option>
                      <option value="Townhouse">Townhouse</option>
                      <option value="Multi-Family">Multi-Family</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Bedrooms *
                    </label>
                    <select
                      name="bedrooms"
                      value={formData.bedrooms}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                      required
                    >
                      <option value="">Select</option>
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
                      <option value="4">4</option>
                      <option value="5+">5+</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Bathrooms *
                    </label>
                    <select
                      name="bathrooms"
                      value={formData.bathrooms}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                      required
                    >
                      <option value="">Select</option>
                      <option value="1">1</option>
                      <option value="1.5">1.5</option>
                      <option value="2">2</option>
                      <option value="2.5">2.5</option>
                      <option value="3">3</option>
                      <option value="3.5">3.5</option>
                      <option value="4+">4+</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Square Footage
                    </label>
                    <input
                      type="number"
                      name="squareFootage"
                      value={formData.squareFootage}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                      placeholder="2000"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Year Built
                    </label>
                    <input
                      type="number"
                      name="yearBuilt"
                      value={formData.yearBuilt}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                      placeholder="2020"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Lot Size (sq ft)
                    </label>
                    <input
                      type="number"
                      name="lotSize"
                      value={formData.lotSize}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                      placeholder="8000"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Asking Price *
                  </label>
                  <input
                    type="number"
                    name="price"
                    value={formData.price}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                    placeholder="500000"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Property Description
                  </label>
                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    rows={4}
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                    placeholder="Describe your property's best features..."
                  />
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-slate-800 mb-6">Owner & Co-Owner Information</h2>
                
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 mb-6">
                  <h3 className="text-lg font-semibold text-slate-800 mb-4">Primary Owner Information</h3>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      name="ownerName"
                      value={formData.ownerName}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                      placeholder="John Doe"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      name="ownerPhone"
                      value={formData.ownerPhone}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                      placeholder="(555) 123-4567"
                      required
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      name="ownerEmail"
                      value={formData.ownerEmail}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                      placeholder="john@example.com"
                      required
                    />
                  </div>
                </div>
                
                {/* Co-Owner Section */}
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-6">
                  <div className="mb-4">
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={formData.hasCoOwner}
                        onChange={(e) => handleCoOwnerToggle(e.target.checked)}
                        className="mr-3 h-4 w-4 text-slate-600 focus:ring-slate-500 border-slate-300 rounded"
                      />
                      <span className="text-lg font-semibold text-slate-800">
                        Add Co-Owner Information
                      </span>
                    </label>
                    <p className="text-sm text-slate-600 mt-1 ml-7">
                      Check this if there's another owner of this property
                    </p>
                  </div>

                  {formData.hasCoOwner && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">
                          Co-Owner Full Name *
                        </label>
                        <input
                          type="text"
                          name="coOwnerName"
                          value={formData.coOwnerName}
                          onChange={handleInputChange}
                          className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                          placeholder="Jane Doe"
                          required={formData.hasCoOwner}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">
                          Co-Owner Phone Number *
                        </label>
                        <input
                          type="tel"
                          name="coOwnerPhone"
                          value={formData.coOwnerPhone}
                          onChange={handleInputChange}
                          className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                          placeholder="(555) 987-6543"
                          required={formData.hasCoOwner}
                        />
                      </div>
                      <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-slate-700 mb-2">
                          Co-Owner Email Address *
                        </label>
                        <input
                          type="email"
                          name="coOwnerEmail"
                          value={formData.coOwnerEmail}
                          onChange={handleInputChange}
                          className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                          placeholder="jane@example.com"
                          required={formData.hasCoOwner}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-slate-800 mb-6">Assign Transaction Coordinator</h2>
                
                <div className="bg-slate-50 rounded-lg p-6 mb-6">
                  <h3 className="text-lg font-semibold text-slate-800 mb-4">🎯 Your Dedicated Support</h3>
                  <p className="text-slate-700 mb-4">
                    We'll assign a dedicated transaction coordinator to guide you through the entire selling process. 
                    They'll handle all the details from listing to closing, keeping you informed every step of the way.
                  </p>
                  <div className="bg-white rounded-lg p-4 border border-slate-200">
                    <h4 className="font-semibold text-slate-800 mb-2">Your coordinator will:</h4>
                    <ul className="text-sm text-slate-600 space-y-1">
                      <li>• Contact you within 2 hours to discuss your selling goals</li>
                      <li>• Send a professional photographer to your property for high-quality listing photos</li>
                      <li>• Create and manage your property listing</li>
                      <li>• Coordinate showings and handle buyer inquiries</li>
                      <li>• Guide you through offers, negotiations, and closing</li>
                    </ul>
                  </div>
                </div>

                {/* Professional Photography Confirmation */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
                  <h3 className="text-lg font-semibold text-blue-900 mb-4">📸 Professional Photography Included</h3>
                  <p className="text-blue-800 mb-4">
                    We will send a professional photographer to your property to capture high-quality photos for your listing. 
                    This service is included at no additional cost to help showcase your home in the best light.
                  </p>
                  <div className="bg-white rounded-lg p-4 border border-blue-200">
                    <h4 className="font-semibold text-blue-900 mb-2">What to expect:</h4>
                    <ul className="text-sm text-blue-800 space-y-1">
                      <li>• Professional photographer will contact you to schedule</li>
                      <li>• Photo session typically takes 1-2 hours</li>
                      <li>• High-resolution photos delivered within 24-48 hours</li>
                      <li>• Photos optimized for online listings and marketing</li>
                      <li>• No cost to you - included in our service</li>
                    </ul>
                  </div>
                </div>
                {/* Contact Preferences */}
                <div className="bg-white border border-slate-200 rounded-lg p-6 mb-6">
                  <h3 className="text-lg font-semibold text-slate-800 mb-4">Contact Preferences</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Confirm Phone Number *
                      </label>
                      <input
                        type="tel"
                        name="ownerPhone"
                        value={formData.ownerPhone}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                        placeholder="(555) 123-4567"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Confirm Email Address *
                      </label>
                      <input
                        type="email"
                        name="ownerEmail"
                        value={formData.ownerEmail}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                        placeholder="john@example.com"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Best Time to Reach You *
                      </label>
                      <select
                        name="bestTimeToCall"
                        value={formData.bestTimeToCall}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                        required
                      >
                        <option value="">Select best time</option>
                        <option value="morning">Morning (8 AM - 12 PM)</option>
                        <option value="afternoon">Afternoon (12 PM - 5 PM)</option>
                        <option value="evening">Evening (5 PM - 8 PM)</option>
                        <option value="anytime">Anytime during business hours</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        Best Time for Professional Photo Session *
                      </label>
                      <select
                        name="photoSessionTime"
                        value={formData.photoSessionTime}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-slate-500"
                        required
                      >
                        <option value="">Select preferred time for photographer visit</option>
                        <option value="weekday-morning">Weekday Morning</option>
                        <option value="weekday-afternoon">Weekday Afternoon</option>
                        <option value="weekend-morning">Weekend Morning</option>
                        <option value="weekend-afternoon">Weekend Afternoon</option>
                        <option value="flexible">I'm flexible with timing</option>
                      </select>
                      <p className="text-sm text-slate-600 mt-1">
                        Our professional photographer will contact you to schedule the photo session at your preferred time.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Property Summary */}
                <div className="bg-slate-50 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-slate-800 mb-4">Property Summary</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="font-medium text-slate-600">Address:</span>
                      <p className="text-slate-800">{formData.address}, {formData.city}, {formData.state} {formData.zipCode}</p>
                    </div>
                    <div>
                      <span className="font-medium text-slate-600">Type:</span>
                      <p className="text-slate-800">{formData.propertyType}</p>
                    </div>
                    <div>
                      <span className="font-medium text-slate-600">Bedrooms/Bathrooms:</span>
                      <p className="text-slate-800">{formData.bedrooms} bed / {formData.bathrooms} bath</p>
                    </div>
                    <div>
                      <span className="font-medium text-slate-600">Price:</span>
                      <p className="text-slate-800">${parseInt(formData.price).toLocaleString()}</p>
                    </div>
                    <div>
                      <span className="font-medium text-slate-600">Owner:</span>
                      <p className="text-slate-800">{formData.ownerName}</p>
                    </div>
                    <div>
                      <span className="font-medium text-slate-600">Contact:</span>
                      <p className="text-slate-800">{formData.ownerPhone}</p>
                    </div>
                    {formData.hasCoOwner && (
                      <>
                        <div>
                          <span className="font-medium text-slate-600">Co-Owner:</span>
                          <p className="text-slate-800">{formData.coOwnerName}</p>
                        </div>
                        <div>
                          <span className="font-medium text-slate-600">Co-Owner Contact:</span>
                          <p className="text-slate-800">{formData.coOwnerPhone}</p>
                        </div>
                      </>
                    )}
                    <div>
                      <span className="font-medium text-slate-600">Best Time to Call:</span>
                      <p className="text-slate-800">{formData.bestTimeToCall}</p>
                    </div>
                    <div>
                      <span className="font-medium text-slate-600">Photo Session Time:</span>
                      <p className="text-slate-800">{formData.photoSessionTime}</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-slate-50 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-slate-800 mb-4">Terms & Conditions</h3>
                  <div className="space-y-2 text-sm text-slate-600">
                    <label className="flex items-start space-x-3">
                      <input type="checkbox" className="mt-1" required />
                      <span>I confirm that I am the owner of this property and have the right to list it for sale.</span>
                    </label>
                    <label className="flex items-start space-x-3">
                      <input type="checkbox" className="mt-1" required />
                      <span>I agree to The Hub's terms of service and privacy policy.</span>
                    </label>
                    <label className="flex items-start space-x-3">
                      <input type="checkbox" className="mt-1" required />
                      <span>I understand that a transaction coordinator will be assigned and a professional photographer will be sent to take photos of my property.</span>
                    </label>
                    <label className="flex items-start space-x-3">
                      <input type="checkbox" className="mt-1" required />
                      <span>I authorize The Hub to contact me at the provided phone number and email address regarding my property listing.</span>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between pt-8 border-t border-slate-200">
              <button
                type="button"
                onClick={prevStep}
                disabled={currentStep === 1}
                className={`flex items-center px-6 py-3 rounded-lg font-semibold transition-colors ${
                  currentStep === 1
                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                    : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                }`}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Previous
              </button>
              
              {currentStep < 3 ? (
                <button
                  type="button"
                  onClick={nextStep}
                  className="flex items-center px-6 py-3 bg-slate-600 text-white rounded-lg font-semibold hover:bg-slate-700 transition-colors"
                >
                  Next
                  <ArrowRight className="w-4 h-4 ml-2" />
                </button>
              ) : (
                <button
                  type="submit"
                  className="flex items-center px-8 py-3 bg-slate-600 text-white rounded-lg font-semibold hover:bg-slate-700 transition-colors"
                >
                  <HandHeart className="w-4 h-4 mr-2" />
                  Submit Listing
                </button>
              )}
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};